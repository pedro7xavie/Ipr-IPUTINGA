// Serviço para gerenciar o armazenamento e persistência de dados no localStorage

// Tipos para os diferentes dados da aplicação
export interface Ministry {
  id: number
  name: string
  description: string
  leader: string
  members: number
  foundedYear: number
  active: boolean
  imageUrl: string
  icon?: string
  createdAt?: string
  updatedAt?: string
}

export interface Event {
  id: number
  title: string
  date: string
  time: string
  location: string
  description: string
  featured: boolean
  imageUrl: string
  createdAt?: string
  updatedAt?: string
}

export interface Sermon {
  id: number
  title: string
  pastor: string
  date: string
  category: string
  description?: string
  videoUrl: string
  imageUrl?: string
  createdAt?: string
  updatedAt?: string
}

export interface Testimony {
  id: number
  name: string
  testimony: string
  imageUrl: string
  active: boolean
  featured: boolean
  createdAt?: string
  updatedAt?: string
}

export interface QuizQuestion {
  id: number
  text: string
  options: string[]
  correctAnswer: number
  explanation?: string
  level: string
  category: string
  createdAt?: string
  updatedAt?: string
}

export interface LiveStreamSettings {
  isLive: boolean
  streamUrl: string
  embedCode: string
  nextStreamDate: string
  nextStreamTime: string
  nextStreamTitle: string
  showBanner: boolean
  bannerText: string
  updatedAt?: string
}

export interface BannerData {
  title: string
  subtitle: string
  backgroundImage: string
  buttonText1: string
  buttonLink1: string
  buttonText2: string
  buttonLink2: string
  nextServiceTitle: string
  nextServiceInfo: string
  nextServiceDescription: string
  lastUpdated?: string
}

// Chaves para o localStorage
const STORAGE_KEYS = {
  MINISTRIES: "ministries",
  EVENTS: "events",
  SERMONS: "sermons",
  TESTIMONIES: "testimonials",
  QUIZ_QUESTIONS: "quizQuestions",
  LIVE_STREAM: "liveStreamSettings",
  BANNER: "bannerData",
  AUTH_TOKEN: "authToken",
  AUTH_EXPIRATION: "authExpiration",
  ADMIN_LOGGED_IN: "adminLoggedIn",
  ADMIN_USERNAME: "adminUsername",
}

// Função genérica para salvar dados no localStorage
function saveData<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data))
  } catch (error) {
    console.error(`Erro ao salvar dados para ${key}:`, error)
  }
}

// Função genérica para carregar dados do localStorage
function loadData<T>(key: string, defaultValue: T): T {
  try {
    const data = localStorage.getItem(key)
    return data ? JSON.parse(data) : defaultValue
  } catch (error) {
    console.error(`Erro ao carregar dados de ${key}:`, error)
    return defaultValue
  }
}

// Funções específicas para cada tipo de dado

// Ministérios
export function saveMinistries(ministries: Ministry[]): void {
  saveData(STORAGE_KEYS.MINISTRIES, ministries)
}

export function loadMinistries(): Ministry[] {
  return loadData<Ministry[]>(STORAGE_KEYS.MINISTRIES, [])
}

export function getMinistryById(id: number): Ministry | undefined {
  const ministries = loadMinistries()
  return ministries.find((ministry) => ministry.id === id)
}

export function addMinistry(ministry: Omit<Ministry, "id" | "createdAt">): Ministry {
  const ministries = loadMinistries()
  const newMinistry: Ministry = {
    ...ministry,
    id: Date.now(),
    createdAt: new Date().toISOString(),
  }

  ministries.push(newMinistry)
  saveMinistries(ministries)
  return newMinistry
}

export function updateMinistry(id: number, ministryData: Partial<Ministry>): Ministry | null {
  const ministries = loadMinistries()
  const index = ministries.findIndex((ministry) => ministry.id === id)

  if (index === -1) return null

  const updatedMinistry: Ministry = {
    ...ministries[index],
    ...ministryData,
    updatedAt: new Date().toISOString(),
  }

  ministries[index] = updatedMinistry
  saveMinistries(ministries)
  return updatedMinistry
}

export function deleteMinistry(id: number): boolean {
  const ministries = loadMinistries()
  const filteredMinistries = ministries.filter((ministry) => ministry.id !== id)

  if (filteredMinistries.length === ministries.length) return false

  saveMinistries(filteredMinistries)
  return true
}

// Eventos
export function saveEvents(events: Event[]): void {
  saveData(STORAGE_KEYS.EVENTS, events)
}

export function loadEvents(): Event[] {
  return loadData<Event[]>(STORAGE_KEYS.EVENTS, [])
}

export function getEventById(id: number): Event | undefined {
  const events = loadEvents()
  return events.find((event) => event.id === id)
}

export function addEvent(event: Omit<Event, "id" | "createdAt">): Event {
  const events = loadEvents()
  const newEvent: Event = {
    ...event,
    id: Date.now(),
    createdAt: new Date().toISOString(),
  }

  events.push(newEvent)
  saveEvents(events)
  return newEvent
}

export function updateEvent(id: number, eventData: Partial<Event>): Event | null {
  const events = loadEvents()
  const index = events.findIndex((event) => event.id === id)

  if (index === -1) return null

  const updatedEvent: Event = {
    ...events[index],
    ...eventData,
    updatedAt: new Date().toISOString(),
  }

  events[index] = updatedEvent
  saveEvents(events)
  return updatedEvent
}

export function deleteEvent(id: number): boolean {
  const events = loadEvents()
  const filteredEvents = events.filter((event) => event.id !== id)

  if (filteredEvents.length === events.length) return false

  saveEvents(filteredEvents)
  return true
}

// Sermões
export function saveSermons(sermons: Sermon[]): void {
  saveData(STORAGE_KEYS.SERMONS, sermons)
}

export function loadSermons(): Sermon[] {
  return loadData<Sermon[]>(STORAGE_KEYS.SERMONS, [])
}

export function getSermonById(id: number): Sermon | undefined {
  const sermons = loadSermons()
  return sermons.find((sermon) => sermon.id === id)
}

export function addSermon(sermon: Omit<Sermon, "id" | "createdAt">): Sermon {
  const sermons = loadSermons()
  const newSermon: Sermon = {
    ...sermon,
    id: Date.now(),
    createdAt: new Date().toISOString(),
  }

  sermons.push(newSermon)
  saveSermons(sermons)
  return newSermon
}

export function updateSermon(id: number, sermonData: Partial<Sermon>): Sermon | null {
  const sermons = loadSermons()
  const index = sermons.findIndex((sermon) => sermon.id === id)

  if (index === -1) return null

  const updatedSermon: Sermon = {
    ...sermons[index],
    ...sermonData,
    updatedAt: new Date().toISOString(),
  }

  sermons[index] = updatedSermon
  saveSermons(sermons)
  return updatedSermon
}

export function deleteSermon(id: number): boolean {
  const sermons = loadSermons()
  const filteredSermons = sermons.filter((sermon) => sermon.id !== id)

  if (filteredSermons.length === sermons.length) return false

  saveSermons(filteredSermons)
  return true
}

// Testemunhos
export function saveTestimonies(testimonies: Testimony[]): void {
  saveData(STORAGE_KEYS.TESTIMONIES, testimonies)
}

export function loadTestimonies(): Testimony[] {
  return loadData<Testimony[]>(STORAGE_KEYS.TESTIMONIES, [])
}

export function getTestimonyById(id: number): Testimony | undefined {
  const testimonies = loadTestimonies()
  return testimonies.find((testimony) => testimony.id === id)
}

export function addTestimony(testimony: Omit<Testimony, "id" | "createdAt">): Testimony {
  const testimonies = loadTestimonies()
  const newTestimony: Testimony = {
    ...testimony,
    id: Date.now(),
    createdAt: new Date().toISOString(),
  }

  testimonies.push(newTestimony)
  saveTestimonies(testimonies)
  return newTestimony
}

export function updateTestimony(id: number, testimonyData: Partial<Testimony>): Testimony | null {
  const testimonies = loadTestimonies()
  const index = testimonies.findIndex((testimony) => testimony.id === id)

  if (index === -1) return null

  const updatedTestimony: Testimony = {
    ...testimonies[index],
    ...testimonyData,
    updatedAt: new Date().toISOString(),
  }

  testimonies[index] = updatedTestimony
  saveTestimonies(testimonies)
  return updatedTestimony
}

export function deleteTestimony(id: number): boolean {
  const testimonies = loadTestimonies()
  const filteredTestimonies = testimonies.filter((testimony) => testimony.id !== id)

  if (filteredTestimonies.length === testimonies.length) return false

  saveTestimonies(filteredTestimonies)
  return true
}

// Perguntas do Quiz
export function saveQuizQuestions(questions: QuizQuestion[]): void {
  saveData(STORAGE_KEYS.QUIZ_QUESTIONS, questions)
}

export function loadQuizQuestions(): QuizQuestion[] {
  return loadData<QuizQuestion[]>(STORAGE_KEYS.QUIZ_QUESTIONS, [])
}

export function getQuizQuestionById(id: number): QuizQuestion | undefined {
  const questions = loadQuizQuestions()
  return questions.find((question) => question.id === id)
}

export function addQuizQuestion(question: Omit<QuizQuestion, "id" | "createdAt">): QuizQuestion {
  const questions = loadQuizQuestions()
  const newQuestion: QuizQuestion = {
    ...question,
    id: Date.now(),
    createdAt: new Date().toISOString(),
  }

  questions.push(newQuestion)
  saveQuizQuestions(questions)
  return newQuestion
}

export function updateQuizQuestion(id: number, questionData: Partial<QuizQuestion>): QuizQuestion | null {
  const questions = loadQuizQuestions()
  const index = questions.findIndex((question) => question.id === id)

  if (index === -1) return null

  const updatedQuestion: QuizQuestion = {
    ...questions[index],
    ...questionData,
    updatedAt: new Date().toISOString(),
  }

  questions[index] = updatedQuestion
  saveQuizQuestions(questions)
  return updatedQuestion
}

export function deleteQuizQuestion(id: number): boolean {
  const questions = loadQuizQuestions()
  const filteredQuestions = questions.filter((question) => question.id !== id)

  if (filteredQuestions.length === questions.length) return false

  saveQuizQuestions(filteredQuestions)
  return true
}

// Configurações de Transmissão ao Vivo
export function saveLiveStreamSettings(settings: LiveStreamSettings): void {
  saveData(STORAGE_KEYS.LIVE_STREAM, settings)
}

export function loadLiveStreamSettings(): LiveStreamSettings {
  return loadData<LiveStreamSettings>(STORAGE_KEYS.LIVE_STREAM, {
    isLive: false,
    streamUrl: "",
    embedCode: "",
    nextStreamDate: "",
    nextStreamTime: "",
    nextStreamTitle: "",
    showBanner: false,
    bannerText: "Estamos ao vivo agora!",
  })
}

// Dados do Banner
export function saveBannerData(data: BannerData): void {
  saveData(STORAGE_KEYS.BANNER, data)
}

export function loadBannerData(): BannerData {
  return loadData<BannerData>(STORAGE_KEYS.BANNER, {
    title: "Igreja Presbiteriana Renovada da Iputinga",
    subtitle: '"Adorando a Deus, edificando vidas e alcançando os perdidos."',
    backgroundImage: "/placeholder.svg?height=800&width=1600",
    buttonText1: "Conheça-nos",
    buttonLink1: "/sobre",
    buttonText2: "Assista ao Vivo",
    buttonLink2: "/transmissao",
    nextServiceTitle: "Próximo Culto",
    nextServiceInfo: "Domingo, 18:00 - Culto de Adoração",
    nextServiceDescription: "Venha adorar ao Senhor conosco!",
  })
}

// Autenticação
export function saveAuthData(token: string, username: string): void {
  const expirationTime = new Date().getTime() + 24 * 60 * 60 * 1000 // 24 horas
  localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, token)
  localStorage.setItem(STORAGE_KEYS.AUTH_EXPIRATION, expirationTime.toString())
  localStorage.setItem(STORAGE_KEYS.ADMIN_LOGGED_IN, "true")
  localStorage.setItem(STORAGE_KEYS.ADMIN_USERNAME, username)
}

export function clearAuthData(): void {
  localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN)
  localStorage.removeItem(STORAGE_KEYS.AUTH_EXPIRATION)
  localStorage.removeItem(STORAGE_KEYS.ADMIN_LOGGED_IN)
  localStorage.removeItem(STORAGE_KEYS.ADMIN_USERNAME)
}

export function isAuthenticated(): boolean {
  const token = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN)
  const expiration = localStorage.getItem(STORAGE_KEYS.AUTH_EXPIRATION)

  if (!token || !expiration) return false

  const expirationTime = Number.parseInt(expiration, 10)
  const currentTime = new Date().getTime()

  return expirationTime > currentTime
}

export function getUsername(): string {
  return localStorage.getItem(STORAGE_KEYS.ADMIN_USERNAME) || "Admin"
}

// Inicialização de dados padrão
export function initializeDefaultData(): void {
  // Verificar se já existem dados no localStorage
  const hasMinistries = localStorage.getItem(STORAGE_KEYS.MINISTRIES) !== null
  const hasEvents = localStorage.getItem(STORAGE_KEYS.EVENTS) !== null
  const hasSermons = localStorage.getItem(STORAGE_KEYS.SERMONS) !== null
  const hasTestimonies = localStorage.getItem(STORAGE_KEYS.TESTIMONIES) !== null

  // Se não existirem, inicializar com dados padrão
  if (!hasMinistries) {
    const defaultMinistries: Ministry[] = [
      {
        id: 1,
        name: "Ministério de Louvor",
        description: "Adoração através da música e artes para glorificar a Deus nos cultos e eventos da igreja.",
        leader: "Carlos Mendes",
        members: 12,
        foundedYear: 2010,
        active: true,
        imageUrl: "/placeholder.svg?height=300&width=400",
        createdAt: new Date().toISOString(),
      },
      {
        id: 2,
        name: "Ministério de Jovens",
        description: "Discipulado, comunhão e evangelismo voltados para adolescentes e jovens adultos.",
        leader: "André Lima",
        members: 25,
        foundedYear: 2012,
        active: true,
        imageUrl: "/placeholder.svg?height=300&width=400",
        createdAt: new Date().toISOString(),
      },
      {
        id: 3,
        name: "Ministério de Crianças",
        description: "Ensino bíblico e atividades para crianças de todas as idades, formando a próxima geração.",
        leader: "Ana Beatriz",
        members: 8,
        foundedYear: 2008,
        active: true,
        imageUrl: "/placeholder.svg?height=300&width=400",
        createdAt: new Date().toISOString(),
      },
      {
        id: 4,
        name: "Ministério da Família",
        description:
          "Apoio, aconselhamento e eventos para fortalecer casamentos e famílias segundo princípios bíblicos.",
        leader: "Roberto e Marta Silva",
        members: 6,
        foundedYear: 2015,
        active: true,
        imageUrl: "/placeholder.svg?height=300&width=400",
        createdAt: new Date().toISOString(),
      },
      {
        id: 5,
        name: "Ministério de Missões",
        description: "Apoio a missionários e projetos de evangelização no Brasil e no exterior.",
        leader: "Paulo Santos",
        members: 10,
        foundedYear: 2013,
        active: false,
        imageUrl: "/placeholder.svg?height=300&width=400",
        createdAt: new Date().toISOString(),
      },
    ]
    saveMinistries(defaultMinistries)
  }

  if (!hasEvents) {
    const defaultEvents: Event[] = [
      {
        id: 1,
        title: "Culto de Adoração",
        date: "10 de Março, 2024",
        time: "18:00",
        location: "Templo Principal",
        description: "Venha adorar ao Senhor conosco em nosso culto dominical.",
        featured: true,
        imageUrl: "/placeholder.svg?height=300&width=500",
        createdAt: new Date().toISOString(),
      },
      {
        id: 2,
        title: "Estudo Bíblico",
        date: "13 de Março, 2024",
        time: "19:30",
        location: "Sala de Estudos",
        description: "Aprofunde seu conhecimento na Palavra de Deus.",
        featured: false,
        imageUrl: "/placeholder.svg?height=300&width=500",
        createdAt: new Date().toISOString(),
      },
      {
        id: 3,
        title: "Culto de Jovens",
        date: "16 de Março, 2024",
        time: "19:00",
        location: "Templo Principal",
        description: "Um momento especial para nossa juventude.",
        featured: false,
        imageUrl: "/placeholder.svg?height=300&width=500",
        createdAt: new Date().toISOString(),
      },
      {
        id: 4,
        title: "Encontro de Casais",
        date: "23 de Março, 2024",
        time: "19:00",
        location: "Salão Social",
        description: "Uma noite especial para fortalecer os casamentos.",
        featured: true,
        imageUrl: "/placeholder.svg?height=300&width=500",
        createdAt: new Date().toISOString(),
      },
    ]
    saveEvents(defaultEvents)
  }

  if (!hasSermons) {
    const defaultSermons: Sermon[] = [
      {
        id: 1,
        title: "O Poder da Oração",
        pastor: "Pr. João Silva",
        date: "05/03/2024",
        category: "Vida Cristã",
        description:
          "Neste sermão, exploramos o poder transformador da oração na vida do cristão e como desenvolver uma vida de oração eficaz.",
        videoUrl: "#",
        imageUrl: "/placeholder.svg?height=200&width=300",
        createdAt: new Date().toISOString(),
      },
      {
        id: 2,
        title: "Vivendo pela Fé",
        pastor: "Pr. João Silva",
        date: "28/02/2024",
        category: "Fé",
        description: "Uma mensagem sobre como viver pela fé em um mundo de incertezas, baseada em Hebreus 11.",
        videoUrl: "#",
        imageUrl: "/placeholder.svg?height=200&width=300",
        createdAt: new Date().toISOString(),
      },
      {
        id: 3,
        title: "A Graça de Deus",
        pastor: "Pr. João Silva",
        date: "21/02/2024",
        category: "Doutrina",
        description: "Um estudo profundo sobre a graça de Deus e como ela opera em nossas vidas.",
        videoUrl: "#",
        imageUrl: "/placeholder.svg?height=200&width=300",
        createdAt: new Date().toISOString(),
      },
      {
        id: 4,
        title: "Família Segundo o Coração de Deus",
        pastor: "Pr. Pedro Oliveira",
        date: "14/02/2024",
        category: "Família",
        description:
          "Princípios bíblicos para construir uma família saudável e centrada em Deus, abordando o papel de cada membro.",
        videoUrl: "#",
        imageUrl: "/placeholder.svg?height=200&width=300",
        createdAt: new Date().toISOString(),
      },
    ]
    saveSermons(defaultSermons)
  }

  if (!hasTestimonies) {
    const defaultTestimonies: Testimony[] = [
      {
        id: 1,
        name: "Maria Santos",
        testimony:
          "Deus transformou minha vida através do ministério desta igreja. Sou muito grata por fazer parte desta família.",
        imageUrl: "/placeholder.svg?height=100&width=100",
        active: true,
        featured: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 2,
        name: "Pedro Oliveira",
        testimony: "Encontrei acolhimento e direção espiritual nesta comunidade. Minha família tem sido abençoada.",
        imageUrl: "/placeholder.svg?height=100&width=100",
        active: true,
        featured: false,
        createdAt: new Date().toISOString(),
      },
    ]
    saveTestimonies(defaultTestimonies)
  }
}

