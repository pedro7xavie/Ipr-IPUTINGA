// Arquivo simplificado sem funcionalidades de autenticação
// Mantido apenas para evitar erros de importação em outros arquivos

import { type NextRequest, NextResponse } from "next/server"

// Função simulada que sempre retorna sucesso
export async function checkAuth() {
  return {
    authenticated: true,
    user: {
      id: 1,
      role: "guest",
      name: "Visitante",
    },
  }
}

// Middleware simplificado que não bloqueia nenhuma rota
export async function adminAuthMiddleware(request: NextRequest) {
  return NextResponse.next()
}

// Middleware simplificado que não bloqueia nenhuma rota
export async function userAuthMiddleware(request: NextRequest) {
  return NextResponse.next()
}

// Função simplificada que retorna um usuário visitante
export async function getCurrentUser() {
  return {
    id: 1,
    role: "guest",
    name: "Visitante",
  }
}

