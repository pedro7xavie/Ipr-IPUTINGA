// Arquivo simplificado sem funcionalidades de banco de dados
// Configuração básica do aplicativo

export interface AppConfig {
  appName: string
  version: string
}

// Configuração do aplicativo
const appConfig: AppConfig = {
  appName: "Quiz Bíblico IPR",
  version: "1.0.0",
}

export { appConfig }

// Função para obter informações sobre o aplicativo
export const getAppInfo = () => {
  return {
    name: appConfig.appName,
    version: appConfig.version,
  }
}

