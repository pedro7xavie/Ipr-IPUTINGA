import { type NextRequest, NextResponse } from "next/server"

// Middleware simplificado que não bloqueia nenhuma rota
export async function middleware(request: NextRequest) {
  return NextResponse.next()
}

// Configurar quais caminhos o middleware deve ser executado
// Reduzido para evitar bloqueios desnecessários
export const config = {
  matcher: [],
}

