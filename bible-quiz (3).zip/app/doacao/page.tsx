import Header from "@/components/header"
import Footer from "@/components/footer"
import Image from "next/image"
import { CreditCard, Landmark, QrCode, Heart, DollarSign, Calendar, ArrowRight } from "lucide-react"

export default function DoacaoPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      {/* Banner */}
      <section className="bg-blue-800 text-white py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-4">Contribua com Nossa Missão</h1>
          <p className="text-xl text-blue-100 max-w-3xl">
            Sua doação ajuda a manter os trabalhos da igreja e a expandir o Reino de Deus.
          </p>
        </div>
      </section>

      {/* Introdução */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <div className="flex items-center mb-4">
                <Heart className="h-8 w-8 text-blue-600 mr-3" />
                <h2 className="text-3xl font-bold text-blue-800">Por Que Contribuir?</h2>
              </div>
              <p className="text-gray-700 mb-4">
                Na Igreja Presbiteriana Renovada da Iputinga, acreditamos que contribuir financeiramente é um ato de
                adoração e gratidão a Deus. Suas doações são fundamentais para mantermos e expandirmos os ministérios da
                igreja.
              </p>
              <p className="text-gray-700 mb-4">Com sua contribuição, podemos:</p>
              <ul className="space-y-2 text-gray-700 mb-4">
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Manter e melhorar nossas instalações</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Apoiar projetos missionários no Brasil e no exterior</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Desenvolver programas de assistência social na comunidade</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Investir em materiais e recursos para nossos ministérios</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Promover eventos evangelísticos e de edificação</span>
                </li>
              </ul>
              <p className="text-gray-700">
                Agradecemos sua generosidade e compromisso com a obra de Deus. Todas as doações são administradas com
                transparência e responsabilidade.
              </p>
            </div>
            <div className="md:w-1/2">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Contribuindo com a obra"
                width={600}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Formas de Contribuição */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-blue-800 mb-4">Formas de Contribuir</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Oferecemos diversas opções para que você possa contribuir da maneira mais conveniente.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-blue-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
                <Landmark className="h-7 w-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-blue-800 mb-3">Transferência Bancária</h3>
              <p className="text-gray-600 mb-4">
                Você pode fazer uma transferência ou depósito diretamente na conta da igreja.
              </p>
              <div className="bg-gray-50 p-4 rounded-md">
                <p className="text-gray-700 font-medium">Banco: Banco do Brasil</p>
                <p className="text-gray-700 font-medium">Agência: 1234-5</p>
                <p className="text-gray-700 font-medium">Conta: 12345-6</p>
                <p className="text-gray-700 font-medium">CNPJ: 12.345.678/0001-90</p>
                <p className="text-gray-700 font-medium">Igreja Presbiteriana Renovada da Iputinga</p>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-blue-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
                <QrCode className="h-7 w-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-blue-800 mb-3">PIX</h3>
              <p className="text-gray-600 mb-4">Faça sua contribuição de forma rápida e segura utilizando o PIX.</p>
              <div className="bg-gray-50 p-4 rounded-md">
                <p className="text-gray-700 font-medium">Chave PIX (CNPJ):</p>
                <p className="text-gray-700 font-medium">12.345.678/0001-90</p>
                <div className="mt-4 flex justify-center">
                  <div className="bg-white p-2 border border-gray-200 rounded-md">
                    <Image src="/placeholder.svg?height=150&width=150" alt="QR Code PIX" width={150} height={150} />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-blue-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
                <CreditCard className="h-7 w-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-blue-800 mb-3">Cartão de Crédito</h3>
              <p className="text-gray-600 mb-4">Contribua online utilizando seu cartão de crédito de forma segura.</p>
              <div className="mt-4">
                <button className="w-full bg-blue-600 text-white py-3 px-4 rounded-md font-medium hover:bg-blue-700 transition-colors flex items-center justify-center">
                  <DollarSign className="h-5 w-5 mr-2" />
                  Doar com Cartão
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contribuição Recorrente */}
      <section className="py-16 px-4 bg-blue-700 text-white">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <div className="flex items-center mb-4">
                <Calendar className="h-8 w-8 text-blue-300 mr-3" />
                <h2 className="text-3xl font-bold">Contribuição Recorrente</h2>
              </div>
              <p className="text-blue-100 mb-4">
                Torne-se um mantenedor da obra com uma contribuição mensal. Isso nos ajuda a planejar melhor nossas
                ações e projetos a longo prazo.
              </p>
              <p className="text-blue-100 mb-6">
                Você pode configurar uma transferência automática mensal ou utilizar nosso sistema de doações
                recorrentes por cartão de crédito.
              </p>
              <button className="bg-white text-blue-700 py-3 px-6 rounded-md font-bold hover:bg-blue-50 transition-colors">
                Tornar-se um Mantenedor
              </button>
            </div>
            <div className="md:w-1/2">
              <Image
                src="/placeholder.svg?height=300&width=500"
                alt="Contribuição Recorrente"
                width={500}
                height={300}
                className="rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Projetos */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-blue-800 mb-4">Projetos Atuais</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Conheça os projetos específicos que estamos desenvolvendo e contribua diretamente para eles.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image
                  src="/placeholder.svg?height=300&width=500"
                  alt="Reforma do Templo"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-800 mb-2">Reforma do Templo</h3>
                <p className="text-gray-600 mb-4">
                  Projeto para ampliação e reforma do nosso templo para melhor acomodar a congregação.
                </p>
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Arrecadado: R$ 45.000</span>
                    <span className="text-gray-600">Meta: R$ 80.000</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "56%" }}></div>
                  </div>
                </div>
                <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-md font-medium hover:bg-blue-700 transition-colors">
                  Contribuir para este Projeto
                </button>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image
                  src="/placeholder.svg?height=300&width=500"
                  alt="Projeto Missionário"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-800 mb-2">Projeto Missionário</h3>
                <p className="text-gray-600 mb-4">
                  Apoio a missionários que atuam em regiões carentes do Nordeste brasileiro.
                </p>
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Arrecadado: R$ 12.000</span>
                    <span className="text-gray-600">Meta: R$ 30.000</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "40%" }}></div>
                  </div>
                </div>
                <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-md font-medium hover:bg-blue-700 transition-colors">
                  Contribuir para este Projeto
                </button>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image src="/placeholder.svg?height=300&width=500" alt="Ação Social" fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-800 mb-2">Ação Social</h3>
                <p className="text-gray-600 mb-4">
                  Projeto de assistência às famílias carentes da comunidade com alimentos e necessidades básicas.
                </p>
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Arrecadado: R$ 8.500</span>
                    <span className="text-gray-600">Meta: R$ 15.000</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "57%" }}></div>
                  </div>
                </div>
                <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-md font-medium hover:bg-blue-700 transition-colors">
                  Contribuir para este Projeto
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Prestação de Contas */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-blue-800 mb-4">Transparência</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Valorizamos a transparência na administração dos recursos. Todos os membros têm acesso à prestação de
              contas mensal.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-8">
            <p className="text-gray-700 mb-6">
              A prestação de contas detalhada é apresentada mensalmente nas reuniões administrativas e está disponível
              para consulta de todos os membros. Além disso, anualmente realizamos uma auditoria externa para garantir a
              correta aplicação dos recursos.
            </p>
            <div className="flex justify-center">
              <button className="bg-blue-600 text-white py-3 px-6 rounded-md font-medium hover:bg-blue-700 transition-colors">
                Acessar Relatórios Financeiros
              </button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

