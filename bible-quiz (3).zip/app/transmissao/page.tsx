import Header from "@/components/header"
import Footer from "@/components/footer"

export default function TransmissaoPage() {
  // Estado da transmissão (ao vivo ou não)
  const isLive = false

  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-3xl font-bold text-center mb-12 text-blue-800">Transmissão ao Vivo</h1>

          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            {isLive ? (
              <div className="aspect-video bg-black">
                {/* Aqui você pode incorporar o iframe do YouTube ou outra plataforma de streaming */}
                <div className="w-full h-full flex items-center justify-center text-white">
                  <p>Transmissão ao vivo</p>
                </div>
              </div>
            ) : (
              <div className="aspect-video bg-gray-800 flex flex-col items-center justify-center text-white p-8 text-center">
                <h2 className="text-2xl font-bold mb-4">Não estamos ao vivo no momento</h2>
                <p className="text-gray-300 max-w-2xl">
                  Nossa próxima transmissão será no domingo às 18:00. Enquanto isso, você pode assistir às nossas
                  gravações anteriores abaixo.
                </p>
              </div>
            )}
          </div>

          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6 text-blue-800">Transmissões Anteriores</h2>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Exemplo de transmissões anteriores */}
              {[1, 2, 3].map((item) => (
                <div key={item} className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden">
                  <div className="aspect-video bg-gray-200 relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <p className="text-gray-500">Miniatura do vídeo</p>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-lg mb-1">Culto de Adoração - {item}/03/2024</h3>
                    <p className="text-gray-600 text-sm">Pr. João Silva</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

