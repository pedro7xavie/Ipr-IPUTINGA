import Header from "@/components/header"
import Footer from "@/components/footer"
import Link from "next/link"
import Image from "next/image"
import { Calendar, Clock, MapPin, Filter, Search } from "lucide-react"

export default function EventosPage() {
  // Dados de exemplo para eventos
  const eventos = [
    {
      id: 1,
      titulo: "Culto de Adoração",
      data: "10 de Março, 2024",
      hora: "18:00",
      local: "Templo Principal",
      descricao: "Venha adorar ao Senhor conosco em nosso culto dominical.",
      imagem: "/placeholder.svg?height=300&width=500",
      destaque: true,
    },
    {
      id: 2,
      titulo: "Estudo Bíblico",
      data: "13 de Março, 2024",
      hora: "19:30",
      local: "Sala de Estudos",
      descricao: "Aprofunde seu conhecimento na Palavra de Deus.",
      imagem: "/placeholder.svg?height=300&width=500",
      destaque: false,
    },
    {
      id: 3,
      titulo: "Culto de Jovens",
      data: "16 de Março, 2024",
      hora: "19:00",
      local: "Templo Principal",
      descricao: "Um momento especial para nossa juventude.",
      imagem: "/placeholder.svg?height=300&width=500",
      destaque: false,
    },
    {
      id: 4,
      titulo: "Encontro de Casais",
      data: "23 de Março, 2024",
      hora: "19:00",
      local: "Salão Social",
      descricao: "Uma noite especial para fortalecer os casamentos.",
      imagem: "/placeholder.svg?height=300&width=500",
      destaque: true,
    },
    {
      id: 5,
      titulo: "Café da Manhã das Mulheres",
      data: "30 de Março, 2024",
      hora: "08:00",
      local: "Salão Social",
      descricao: "Momento de comunhão e edificação para as mulheres da igreja.",
      imagem: "/placeholder.svg?height=300&width=500",
      destaque: false,
    },
    {
      id: 6,
      titulo: "Conferência de Missões",
      data: "5-7 de Abril, 2024",
      hora: "19:00",
      local: "Templo Principal",
      descricao: "Três dias de palestras e testemunhos sobre o campo missionário.",
      imagem: "/placeholder.svg?height=300&width=500",
      destaque: true,
    },
  ]

  // Eventos em destaque
  const eventosDestaque = eventos.filter((evento) => evento.destaque)
  // Eventos regulares
  const eventosRegulares = eventos.filter((evento) => !evento.destaque)

  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      {/* Banner */}
      <section className="bg-blue-800 text-white py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-4">Eventos</h1>
          <p className="text-xl text-blue-100 max-w-3xl">
            Confira nossa agenda de eventos e participe das atividades da nossa igreja.
          </p>
        </div>
      </section>

      {/* Filtros e Busca */}
      <section className="py-8 px-4 bg-white border-b">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center">
              <Filter className="h-5 w-5 text-gray-500 mr-2" />
              <span className="text-gray-700 font-medium mr-3">Filtrar por:</span>
              <div className="flex flex-wrap gap-2">
                <button className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-blue-200 transition-colors">
                  Todos
                </button>
                <button className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors">
                  Cultos
                </button>
                <button className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors">
                  Estudos
                </button>
                <button className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors">
                  Especiais
                </button>
              </div>
            </div>

            <div className="relative w-full md:w-64">
              <input
                type="text"
                placeholder="Buscar eventos..."
                className="w-full border border-gray-300 rounded-md py-2 pl-10 pr-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            </div>
          </div>
        </div>
      </section>

      {/* Eventos em Destaque */}
      <section className="py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-2xl font-bold text-blue-800 mb-6">Eventos em Destaque</h2>

          <div className="grid md:grid-cols-2 gap-8">
            {eventosDestaque.map((evento) => (
              <div key={evento.id} className="bg-white rounded-lg shadow-md overflow-hidden flex flex-col md:flex-row">
                <div className="md:w-2/5 h-48 md:h-auto relative">
                  <Image src={evento.imagem || "/placeholder.svg"} alt={evento.titulo} fill className="object-cover" />
                </div>
                <div className="p-6 md:w-3/5">
                  <div className="bg-blue-100 text-blue-800 text-xs font-bold px-2 py-1 rounded-full inline-block mb-2">
                    Destaque
                  </div>
                  <h3 className="text-xl font-bold text-blue-800 mb-2">{evento.titulo}</h3>

                  <div className="flex items-center text-gray-600 mb-1">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>{evento.data}</span>
                  </div>

                  <div className="flex items-center text-gray-600 mb-1">
                    <Clock className="h-4 w-4 mr-2" />
                    <span>{evento.hora}</span>
                  </div>

                  <div className="flex items-center text-gray-600 mb-3">
                    <MapPin className="h-4 w-4 mr-2" />
                    <span>{evento.local}</span>
                  </div>

                  <p className="text-gray-600 mb-4">{evento.descricao}</p>

                  <Link
                    href={`/eventos/${evento.id}`}
                    className="inline-block bg-blue-600 text-white py-2 px-4 rounded-md font-medium hover:bg-blue-700 transition-colors"
                  >
                    Ver Detalhes
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Eventos Regulares */}
      <section className="py-12 px-4 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-2xl font-bold text-blue-800 mb-6">Próximos Eventos</h2>

          <div className="grid md:grid-cols-3 gap-6">
            {eventosRegulares.map((evento) => (
              <div key={evento.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="h-48 relative">
                  <Image src={evento.imagem || "/placeholder.svg"} alt={evento.titulo} fill className="object-cover" />
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-bold text-blue-800 mb-2">{evento.titulo}</h3>

                  <div className="flex items-center text-gray-600 mb-1">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>{evento.data}</span>
                  </div>

                  <div className="flex items-center text-gray-600 mb-1">
                    <Clock className="h-4 w-4 mr-2" />
                    <span>{evento.hora}</span>
                  </div>

                  <div className="flex items-center text-gray-600 mb-3">
                    <MapPin className="h-4 w-4 mr-2" />
                    <span>{evento.local}</span>
                  </div>

                  <p className="text-gray-600 mb-4 line-clamp-2">{evento.descricao}</p>

                  <Link
                    href={`/eventos/${evento.id}`}
                    className="inline-block text-blue-600 font-medium hover:text-blue-800 transition-colors"
                  >
                    Ver Detalhes →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Calendário */}
      <section className="py-12 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-blue-800 mb-2">Calendário Completo</h2>
            <p className="text-gray-600">
              Veja todos os eventos programados em nosso calendário e planeje sua participação.
            </p>
          </div>

          <div className="flex justify-center">
            <Link
              href="/calendario"
              className="bg-blue-600 text-white py-3 px-6 rounded-md font-medium hover:bg-blue-700 transition-colors"
            >
              Ver Calendário
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

