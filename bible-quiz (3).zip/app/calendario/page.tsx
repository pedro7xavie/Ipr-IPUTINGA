import Header from "@/components/header"
import Footer from "@/components/footer"
import Link from "next/link"
import { CalendarIcon, ChevronLeft, ChevronRight, Filter } from "lucide-react"

export default function CalendarioPage() {
  // Mês atual (exemplo: Março 2024)
  const mesAtual = "Março 2024"

  // Dias da semana
  const diasSemana = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]

  // Exemplo de calendário para Março 2024
  // 0 representa dias que não pertencem ao mês atual
  const diasMes = [
    0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
    28, 29, 30, 31, 0, 0, 0, 0, 0, 0,
  ]

  // Eventos do mês (exemplo)
  const eventos = [
    { dia: 3, titulo: "Culto de Adoração", hora: "18:00", tipo: "culto" },
    { dia: 6, titulo: "Estudo Bíblico", hora: "19:30", tipo: "estudo" },
    { dia: 9, titulo: "Culto de Jovens", hora: "19:00", tipo: "jovens" },
    { dia: 10, titulo: "Culto de Adoração", hora: "18:00", tipo: "culto" },
    { dia: 13, titulo: "Estudo Bíblico", hora: "19:30", tipo: "estudo" },
    { dia: 16, titulo: "Culto de Jovens", hora: "19:00", tipo: "jovens" },
    { dia: 17, titulo: "Culto de Adoração", hora: "18:00", tipo: "culto" },
    { dia: 20, titulo: "Estudo Bíblico", hora: "19:30", tipo: "estudo" },
    { dia: 23, titulo: "Encontro de Casais", hora: "19:00", tipo: "especial" },
    { dia: 24, titulo: "Culto de Adoração", hora: "18:00", tipo: "culto" },
    { dia: 27, titulo: "Estudo Bíblico", hora: "19:30", tipo: "estudo" },
    { dia: 30, titulo: "Café da Manhã das Mulheres", hora: "08:00", tipo: "especial" },
    { dia: 31, titulo: "Culto de Adoração", hora: "18:00", tipo: "culto" },
  ]

  // Função para obter eventos de um dia específico
  const getEventosDia = (dia: number) => {
    return eventos.filter((evento) => evento.dia === dia)
  }

  // Função para obter a cor do tipo de evento
  const getCorTipoEvento = (tipo: string) => {
    switch (tipo) {
      case "culto":
        return "bg-blue-100 text-blue-800"
      case "estudo":
        return "bg-green-100 text-green-800"
      case "jovens":
        return "bg-purple-100 text-purple-800"
      case "especial":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      {/* Banner */}
      <section className="bg-blue-800 text-white py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-4">Calendário</h1>
          <p className="text-xl text-blue-100 max-w-3xl">Acompanhe todos os eventos e atividades da nossa igreja.</p>
        </div>
      </section>

      {/* Filtros */}
      <section className="py-8 px-4 bg-white border-b">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center">
              <Filter className="h-5 w-5 text-gray-500 mr-2" />
              <span className="text-gray-700 font-medium mr-3">Filtrar por:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <button className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-blue-200 transition-colors">
                Todos
              </button>
              <button className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors">
                Cultos
              </button>
              <button className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors">
                Estudos
              </button>
              <button className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors">
                Jovens
              </button>
              <button className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors">
                Especiais
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Calendário */}
      <section className="py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          {/* Navegação do Calendário */}
          <div className="flex justify-between items-center mb-8">
            <button className="p-2 rounded-full hover:bg-gray-200 transition-colors">
              <ChevronLeft className="h-5 w-5 text-gray-600" />
            </button>

            <h2 className="text-2xl font-bold text-blue-800 flex items-center">
              <CalendarIcon className="h-6 w-6 mr-2" />
              {mesAtual}
            </h2>

            <button className="p-2 rounded-full hover:bg-gray-200 transition-colors">
              <ChevronRight className="h-5 w-5 text-gray-600" />
            </button>
          </div>

          {/* Legenda */}
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
              <span className="text-sm text-gray-600">Cultos</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
              <span className="text-sm text-gray-600">Estudos</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-purple-500 mr-2"></div>
              <span className="text-sm text-gray-600">Jovens</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-orange-500 mr-2"></div>
              <span className="text-sm text-gray-600">Especiais</span>
            </div>
          </div>

          {/* Grade do Calendário */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            {/* Cabeçalho dos dias da semana */}
            <div className="grid grid-cols-7 bg-gray-100">
              {diasSemana.map((dia, index) => (
                <div key={index} className="py-3 text-center font-medium text-gray-700">
                  {dia}
                </div>
              ))}
            </div>

            {/* Dias do mês */}
            <div className="grid grid-cols-7">
              {diasMes.map((dia, index) => (
                <div
                  key={index}
                  className={`min-h-[120px] p-2 border border-gray-100 ${dia === 0 ? "bg-gray-50" : ""}`}
                >
                  {dia !== 0 && (
                    <>
                      <div className="text-right mb-1">
                        <span
                          className={`inline-block w-6 h-6 rounded-full text-center text-sm ${
                            dia === 10 ? "bg-blue-600 text-white" : "text-gray-700"
                          }`}
                        >
                          {dia}
                        </span>
                      </div>

                      <div className="space-y-1">
                        {getEventosDia(dia).map((evento, eventoIndex) => (
                          <Link
                            key={eventoIndex}
                            href={`/eventos/${eventoIndex + 1}`}
                            className={`block text-xs p-1 rounded ${getCorTipoEvento(evento.tipo)} truncate`}
                          >
                            {evento.hora} - {evento.titulo}
                          </Link>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Lista de Eventos do Mês */}
          <div className="mt-12">
            <h3 className="text-xl font-bold text-blue-800 mb-6">Eventos de {mesAtual}</h3>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="divide-y">
                {eventos.map((evento, index) => (
                  <div key={index} className="p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start">
                      <div className="bg-blue-100 text-blue-800 rounded-lg p-2 mr-4 text-center min-w-[60px]">
                        <span className="block text-2xl font-bold">{evento.dia}</span>
                        <span className="text-xs">Mar</span>
                      </div>

                      <div>
                        <h4 className="font-bold text-gray-900">{evento.titulo}</h4>
                        <p className="text-gray-600 text-sm">{evento.hora}</p>
                        <div className="mt-1">
                          <span className={`text-xs px-2 py-1 rounded-full ${getCorTipoEvento(evento.tipo)}`}>
                            {evento.tipo.charAt(0).toUpperCase() + evento.tipo.slice(1)}
                          </span>
                        </div>
                      </div>

                      <div className="ml-auto">
                        <Link
                          href={`/eventos/${index + 1}`}
                          className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                        >
                          Detalhes
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

