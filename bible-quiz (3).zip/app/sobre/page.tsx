import Header from "@/components/header"
import Footer from "@/components/footer"
import Image from "next/image"
import { Users, Clock, MapPin, BookOpen, Heart, History } from "lucide-react"

export default function SobrePage() {
  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      {/* Banner */}
      <section className="bg-blue-800 text-white py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-4">Sobre Nossa Igreja</h1>
          <p className="text-xl text-blue-100 max-w-3xl">
            Conheça a história, missão e valores da Igreja Presbiteriana Renovada da Iputinga.
          </p>
        </div>
      </section>

      {/* História */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <div className="flex items-center mb-4">
                <History className="h-8 w-8 text-blue-600 mr-3" />
                <h2 className="text-3xl font-bold text-blue-800">Nossa História</h2>
              </div>
              <p className="text-gray-700 mb-4">
                A Igreja Presbiteriana Renovada da Iputinga foi fundada em 1985 por um grupo de cristãos comprometidos
                com a Palavra de Deus e com o desejo de impactar a comunidade local com o Evangelho de Jesus Cristo.
              </p>
              <p className="text-gray-700 mb-4">
                Ao longo dos anos, nossa igreja cresceu e se desenvolveu, sempre mantendo o compromisso com os
                princípios bíblicos e com a renovação espiritual. Começamos com apenas 20 membros em um pequeno salão
                alugado e hoje contamos com uma comunidade vibrante de mais de 300 membros.
              </p>
              <p className="text-gray-700">
                Nossa jornada tem sido marcada por fé, perseverança e inúmeros testemunhos de vidas transformadas pelo
                poder de Deus. Continuamos avançando com a visão de ser uma igreja que adora a Deus em espírito e em
                verdade, edifica os crentes e alcança os perdidos.
              </p>
            </div>
            <div className="md:w-1/2">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="História da Igreja Presbiteriana Renovada da Iputinga"
                width={600}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Missão, Visão e Valores */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-blue-800 mb-4">Missão, Visão e Valores</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Nossos princípios fundamentais que orientam todas as nossas ações e ministérios.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-blue-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
                <BookOpen className="h-7 w-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-blue-800 mb-3">Missão</h3>
              <p className="text-gray-600">
                Adorar a Deus, edificar os crentes através do ensino da Palavra e alcançar os perdidos com o Evangelho
                de Jesus Cristo, sendo sal e luz na comunidade da Iputinga e além.
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-blue-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
                <Users className="h-7 w-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-blue-800 mb-3">Visão</h3>
              <p className="text-gray-600">
                Ser uma igreja bíblica, relevante e transformadora, que forma discípulos maduros e comprometidos com o
                Reino de Deus, impactando famílias e gerações através do poder do Espírito Santo.
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-blue-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
                <Heart className="h-7 w-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-blue-800 mb-3">Valores</h3>
              <ul className="text-gray-600 space-y-2">
                <li>• Fidelidade à Palavra de Deus</li>
                <li>• Dependência do Espírito Santo</li>
                <li>• Excelência na adoração</li>
                <li>• Comunhão e relacionamentos saudáveis</li>
                <li>• Compromisso com discipulado</li>
                <li>• Paixão evangelística</li>
                <li>• Serviço compassivo</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Liderança */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-blue-800 mb-4">Nossa Liderança</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Conheça os pastores e líderes que servem e cuidam da nossa comunidade.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="mb-4 mx-auto w-48 h-48 relative rounded-full overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Pastor João Silva"
                  fill
                  className="object-cover"
                />
              </div>
              <h3 className="text-xl font-bold text-blue-800">Pr. João Silva</h3>
              <p className="text-blue-600 mb-2">Pastor Titular</p>
              <p className="text-gray-600 max-w-xs mx-auto">
                Servindo como pastor há mais de 15 anos, com formação teológica e paixão pelo ensino da Palavra.
              </p>
            </div>

            <div className="text-center">
              <div className="mb-4 mx-auto w-48 h-48 relative rounded-full overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Pastor Pedro Oliveira"
                  fill
                  className="object-cover"
                />
              </div>
              <h3 className="text-xl font-bold text-blue-800">Pr. Pedro Oliveira</h3>
              <p className="text-blue-600 mb-2">Pastor Auxiliar</p>
              <p className="text-gray-600 max-w-xs mx-auto">
                Responsável pelo ministério de jovens e famílias, com coração para discipulado e aconselhamento.
              </p>
            </div>

            <div className="text-center">
              <div className="mb-4 mx-auto w-48 h-48 relative rounded-full overflow-hidden">
                <Image src="/placeholder.svg?height=200&width=200" alt="Maria Santos" fill className="object-cover" />
              </div>
              <h3 className="text-xl font-bold text-blue-800">Maria Santos</h3>
              <p className="text-blue-600 mb-2">Coordenadora de Ministérios</p>
              <p className="text-gray-600 max-w-xs mx-auto">
                Lidera os diversos ministérios da igreja, com experiência em administração e paixão por servir.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Informações */}
      <section className="py-16 px-4 bg-blue-700 text-white">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Informações Gerais</h2>
            <p className="text-blue-100 max-w-3xl mx-auto">
              Tudo o que você precisa saber para nos visitar e fazer parte da nossa comunidade.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-blue-800 p-8 rounded-lg">
              <div className="flex items-center mb-4">
                <Clock className="h-8 w-8 text-blue-300 mr-3" />
                <h3 className="text-xl font-bold">Horários</h3>
              </div>
              <ul className="space-y-3 text-blue-100">
                <li>
                  <p className="font-medium">Culto de Adoração</p>
                  <p>Domingo, 18:00</p>
                </li>
                <li>
                  <p className="font-medium">Estudo Bíblico</p>
                  <p>Quarta-feira, 19:30</p>
                </li>
                <li>
                  <p className="font-medium">Culto de Jovens</p>
                  <p>Sábado, 19:00</p>
                </li>
                <li>
                  <p className="font-medium">Escola Dominical</p>
                  <p>Domingo, 09:00</p>
                </li>
              </ul>
            </div>

            <div className="bg-blue-800 p-8 rounded-lg">
              <div className="flex items-center mb-4">
                <MapPin className="h-8 w-8 text-blue-300 mr-3" />
                <h3 className="text-xl font-bold">Localização</h3>
              </div>
              <p className="text-blue-100 mb-4">
                Rua da Iputinga, 123 - Iputinga
                <br />
                Recife - PE, 50000-000
              </p>
              <div className="h-48 bg-blue-900 rounded-lg flex items-center justify-center">
                <p className="text-blue-300">Mapa da localização</p>
              </div>
            </div>

            <div className="bg-blue-800 p-8 rounded-lg">
              <div className="flex items-center mb-4">
                <Users className="h-8 w-8 text-blue-300 mr-3" />
                <h3 className="text-xl font-bold">Faça Parte</h3>
              </div>
              <p className="text-blue-100 mb-4">
                Estamos sempre de braços abertos para receber novos membros em nossa comunidade. Venha nos visitar e
                conhecer mais sobre nossa igreja.
              </p>
              <p className="text-blue-100 mb-4">
                Para se tornar membro, oferecemos classes de novos membros regularmente, onde você aprenderá mais sobre
                nossa fé, história e visão.
              </p>
              <button className="bg-white text-blue-800 py-2 px-4 rounded-md font-bold hover:bg-blue-50 transition-colors w-full">
                Quero Fazer Parte
              </button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

