import Header from "@/components/header"
import Footer from "@/components/footer"
import Image from "next/image"
import Link from "next/link"
import { Music, Users, Heart, Baby, Home, Globe, BookOpen, ArrowRight } from "lucide-react"

export default function MinisteriosPage() {
  const ministerios = [
    {
      id: "louvor",
      title: "Ministério de Louvor",
      description: "Adoração através da música e artes para glorificar a Deus nos cultos e eventos da igreja.",
      icon: <Music className="h-8 w-8 text-blue-600" />,
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      id: "jovens",
      title: "Ministério de Jovens",
      description: "Discipulado, comunhão e evangelismo voltados para adolescentes e jovens adultos.",
      icon: <Users className="h-8 w-8 text-blue-600" />,
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      id: "criancas",
      title: "Ministério de Crianças",
      description: "Ensino bíblico e atividades para crianças de todas as idades, formando a próxima geração.",
      icon: <Baby className="h-8 w-8 text-blue-600" />,
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      id: "familia",
      title: "Ministério da Família",
      description: "Apoio, aconselhamento e eventos para fortalecer casamentos e famílias segundo princípios bíblicos.",
      icon: <Home className="h-8 w-8 text-blue-600" />,
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      id: "missoes",
      title: "Ministério de Missões",
      description: "Apoio a missionários e projetos de evangelização no Brasil e no exterior.",
      icon: <Globe className="h-8 w-8 text-blue-600" />,
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      id: "primeiros-passos",
      title: "Ministério Primeiros Passos",
      description: "Acompanhamento e discipulado para novos convertidos e pessoas interessadas na fé cristã.",
      icon: <BookOpen className="h-8 w-8 text-blue-600" />,
      image: "/placeholder.svg?height=300&width=400",
    },
  ]

  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      {/* Banner */}
      <section className="bg-blue-800 text-white py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-4">Nossos Ministérios</h1>
          <p className="text-xl text-blue-100 max-w-3xl">
            Conheça as diversas áreas de atuação da nossa igreja e descubra como você pode servir e se envolver.
          </p>
        </div>
      </section>

      {/* Introdução */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <div className="flex items-center mb-4">
                <Heart className="h-8 w-8 text-blue-600 mr-3" />
                <h2 className="text-3xl font-bold text-blue-800">Servindo com Propósito</h2>
              </div>
              <p className="text-gray-700 mb-4">
                Na Igreja Presbiteriana Renovada da Iputinga, acreditamos que cada membro tem dons e talentos únicos que
                podem ser usados para a glória de Deus e para edificação do Corpo de Cristo.
              </p>
              <p className="text-gray-700 mb-4">
                Nossos ministérios são áreas específicas de atuação onde você pode servir de acordo com seus dons,
                habilidades e chamado. Através deles, buscamos alcançar nossa comunidade, fortalecer nossa igreja e
                cumprir a missão que Deus nos confiou.
              </p>
              <p className="text-gray-700">
                Convidamos você a conhecer cada um dos nossos ministérios e a orar sobre como Deus pode usá-lo para
                fazer a diferença. Há um lugar para você servir!
              </p>
            </div>
            <div className="md:w-1/2">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Membros servindo nos ministérios"
                width={600}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Lista de Ministérios */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-blue-800 mb-4">Áreas de Atuação</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Explore nossos ministérios e descubra como você pode se envolver e servir.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {ministerios.map((ministerio) => (
              <div key={ministerio.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="h-48 relative">
                  <Image
                    src={ministerio.image || "/placeholder.svg"}
                    alt={ministerio.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="bg-blue-100 p-2 rounded-full mr-3">{ministerio.icon}</div>
                    <h3 className="text-xl font-bold text-blue-800">{ministerio.title}</h3>
                  </div>
                  <p className="text-gray-600 mb-4">{ministerio.description}</p>
                  <Link
                    href={`/ministerios/${ministerio.id}`}
                    className="inline-flex items-center text-blue-600 font-medium hover:text-blue-800"
                  >
                    Saiba mais <ArrowRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-700 mb-6">
              Quer saber mais sobre como se envolver em algum dos nossos ministérios?
            </p>
            <Link
              href="/contato"
              className="bg-blue-600 text-white py-3 px-6 rounded-md font-medium hover:bg-blue-700 transition-colors inline-block"
            >
              Entre em Contato
            </Link>
          </div>
        </div>
      </section>

      {/* Testemunhos */}
      <section className="py-16 px-4 bg-blue-700 text-white">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Testemunhos de Servos</h2>
            <p className="text-blue-100 max-w-3xl mx-auto">
              Ouça o que nossos voluntários têm a dizer sobre servir nos ministérios da igreja.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-blue-800/50 p-6 rounded-lg">
              <p className="italic text-blue-100 mb-4">
                "Servir no ministério de louvor tem sido uma bênção incrível. Usar meus dons musicais para adorar a Deus
                e conduzir a congregação na presença Dele é um privilégio que transformou minha vida espiritual."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-3">
                  <Image src="/placeholder.svg?height=100&width=100" alt="Carlos Mendes" width={100} height={100} />
                </div>
                <div>
                  <p className="font-bold">Carlos Mendes</p>
                  <p className="text-blue-300 text-sm">Ministério de Louvor</p>
                </div>
              </div>
            </div>

            <div className="bg-blue-800/50 p-6 rounded-lg">
              <p className="italic text-blue-100 mb-4">
                "Trabalhar com as crianças tem sido uma jornada de aprendizado constante. Ver o brilho nos olhos delas
                quando entendem uma história bíblica me faz lembrar das palavras de Jesus sobre o Reino pertencer aos
                pequeninos."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-3">
                  <Image src="/placeholder.svg?height=100&width=100" alt="Ana Beatriz" width={100} height={100} />
                </div>
                <div>
                  <p className="font-bold">Ana Beatriz</p>
                  <p className="text-blue-300 text-sm">Ministério de Crianças</p>
                </div>
              </div>
            </div>

            <div className="bg-blue-800/50 p-6 rounded-lg">
              <p className="italic text-blue-100 mb-4">
                "Participar do ministério de missões abriu meus olhos para as necessidades do mundo. Cada viagem
                missionária, cada projeto apoiado, cada oração feita tem impactado não só aqueles que servimos, mas
                principalmente a mim."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-3">
                  <Image src="/placeholder.svg?height=100&width=100" alt="Roberto Silva" width={100} height={100} />
                </div>
                <div>
                  <p className="font-bold">Roberto Silva</p>
                  <p className="text-blue-300 text-sm">Ministério de Missões</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

