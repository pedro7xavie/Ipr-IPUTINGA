"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { Calendar, Clock, MapPin, Users, ArrowRight, Mail, Phone } from "lucide-react"

// Tipos
interface MinistryMember {
  name: string
  role: string
  imageUrl: string
}

interface MinistryEvent {
  title: string
  date: string
  time: string
  location: string
  description: string
}

interface Ministry {
  id: string
  name: string
  description: string
  longDescription: string
  mission: string
  vision: string
  leader: string
  leaderMessage?: string
  foundedYear: number
  meetingDay?: string
  meetingTime?: string
  meetingLocation?: string
  members: MinistryMember[]
  events: MinistryEvent[]
  photos: string[]
  bannerImage: string
  icon: React.ReactNode
}

export default function MinisterioPage() {
  const params = useParams()
  const ministryId = params?.id as string
  const [ministry, setMinistry] = useState<Ministry | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simular carregamento de dados do ministério
    const loadMinistryData = () => {
      // Dados simulados - em uma aplicação real, estes viriam de uma API ou banco de dados
      const ministries: Record<string, Ministry> = {
        louvor: {
          id: "louvor",
          name: "Ministério de Louvor",
          description: "Adoração através da música e artes para glorificar a Deus nos cultos e eventos da igreja.",
          longDescription:
            "O Ministério de Louvor da Igreja Presbiteriana Renovada da Iputinga é dedicado a conduzir a congregação em momentos de adoração através da música. Nosso objetivo é criar um ambiente onde as pessoas possam se conectar com Deus de maneira profunda e significativa. Utilizamos diversos instrumentos e estilos musicais, sempre com o foco em exaltar o nome de Jesus.",
          mission:
            "Conduzir a igreja em adoração autêntica e inspiradora, criando um ambiente onde as pessoas possam experimentar a presença de Deus através da música.",
          vision:
            "Ser um ministério que não apenas executa músicas, mas que forma adoradores que vivem em intimidade com Deus dentro e fora dos cultos.",
          leader: "Carlos Mendes",
          leaderMessage:
            "A adoração é um estilo de vida. No Ministério de Louvor, buscamos não apenas cantar, mas viver o que cantamos, sendo exemplos de adoradores em espírito e em verdade.",
          foundedYear: 2010,
          meetingDay: "Terças e Sábados",
          meetingTime: "19:30",
          meetingLocation: "Sala de Música",
          members: [
            { name: "Carlos Mendes", role: "Líder/Vocal", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Mariana Silva", role: "Vocal", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Pedro Oliveira", role: "Guitarra", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Lucas Santos", role: "Bateria", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Juliana Costa", role: "Teclado", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Rafael Lima", role: "Baixo", imageUrl: "/placeholder.svg?height=150&width=150" },
          ],
          events: [
            {
              title: "Ensaio Geral",
              date: "Todos os sábados",
              time: "16:00",
              location: "Sala de Música",
              description: "Ensaio semanal para preparação dos louvores do culto de domingo.",
            },
            {
              title: "Workshop de Adoração",
              date: "15 de Abril, 2024",
              time: "09:00 - 17:00",
              location: "Templo Principal",
              description: "Um dia inteiro de aprendizado sobre adoração, técnica vocal e instrumental.",
            },
          ],
          photos: [
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
          ],
          bannerImage:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-j8oney9dcC5v0xvrkOnLC7RWdNSgUM.png",
          icon: <span>🎵</span>,
        },
        jovens: {
          id: "jovens",
          name: "Ministério de Jovens",
          description: "Discipulado, comunhão e evangelismo voltados para adolescentes e jovens adultos.",
          longDescription:
            "O Ministério de Jovens da Igreja Presbiteriana Renovada da Iputinga é um espaço dedicado ao crescimento espiritual, comunhão e desenvolvimento de liderança entre os adolescentes e jovens adultos. Promovemos encontros semanais, retiros, atividades sociais e projetos de evangelismo, sempre com o objetivo de formar uma geração comprometida com Cristo e Seus valores.",
          mission:
            "Formar jovens discípulos de Jesus Cristo, equipando-os para viverem sua fé de maneira relevante e impactante na sociedade atual.",
          vision:
            "Ser um ministério que transforma a vida dos jovens, preparando-os para serem líderes cristãos que influenciam positivamente sua geração.",
          leader: "André Lima",
          leaderMessage:
            "Acreditamos que os jovens não são apenas o futuro da igreja, mas são parte vital do presente. Nosso compromisso é criar um ambiente onde cada jovem possa descobrir seus dons, desenvolver sua fé e encontrar seu propósito em Cristo.",
          foundedYear: 2012,
          meetingDay: "Sábados",
          meetingTime: "19:00",
          meetingLocation: "Salão Social",
          members: [
            { name: "André Lima", role: "Líder", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Bianca Martins", role: "Vice-líder", imageUrl: "/placeholder.svg?height=150&width=150" },
            {
              name: "Gabriel Santos",
              role: "Coordenador de Louvor",
              imageUrl: "/placeholder.svg?height=150&width=150",
            },
            { name: "Camila Ferreira", role: "Secretária", imageUrl: "/placeholder.svg?height=150&width=150" },
          ],
          events: [
            {
              title: "Culto de Jovens",
              date: "Todos os sábados",
              time: "19:00",
              location: "Salão Social",
              description: "Encontro semanal com louvor, mensagem e comunhão.",
            },
            {
              title: "Retiro de Jovens",
              date: "21-23 de Julho, 2024",
              time: "Saída às 07:00",
              location: "Chácara Recanto da Paz",
              description: "Três dias de comunhão, edificação e diversão.",
            },
          ],
          photos: [
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
          ],
          bannerImage:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-j8oney9dcC5v0xvrkOnLC7RWdNSgUM.png",
          icon: <span>👥</span>,
        },
        criancas: {
          id: "criancas",
          name: "Ministério de Crianças",
          description: "Ensino bíblico e atividades para crianças de todas as idades, formando a próxima geração.",
          longDescription:
            "O Ministério de Crianças da Igreja Presbiteriana Renovada da Iputinga é dedicado a ensinar os princípios bíblicos de forma lúdica e adequada para cada faixa etária. Trabalhamos para que cada criança conheça Jesus de maneira pessoal e desenvolva uma base sólida de fé desde cedo. Nossas atividades incluem aulas bíblicas, brincadeiras, teatro, música e muito mais.",
          mission:
            "Apresentar Jesus Cristo às crianças de forma relevante e adequada à idade, ajudando-as a desenvolver um relacionamento pessoal com Deus.",
          vision:
            "Formar uma geração que ama a Deus, conhece Sua Palavra e vive os valores cristãos em todos os aspectos da vida.",
          leader: "Ana Beatriz",
          leaderMessage:
            "As crianças são preciosas para Deus e para nossa igreja. Nosso compromisso é criar um ambiente seguro, divertido e espiritualmente enriquecedor onde cada criança possa crescer na fé e no conhecimento de Jesus.",
          foundedYear: 2008,
          meetingDay: "Domingos",
          meetingTime: "09:00 e 18:00",
          meetingLocation: "Salas Infantis",
          members: [
            { name: "Ana Beatriz", role: "Coordenadora Geral", imageUrl: "/placeholder.svg?height=150&width=150" },
            {
              name: "Roberto Carlos",
              role: "Coordenador de Berçário",
              imageUrl: "/placeholder.svg?height=150&width=150",
            },
            { name: "Fernanda Lima", role: "Professora (3-5 anos)", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Marcelo Santos", role: "Professor (6-8 anos)", imageUrl: "/placeholder.svg?height=150&width=150" },
            {
              name: "Patrícia Oliveira",
              role: "Professora (9-11 anos)",
              imageUrl: "/placeholder.svg?height=150&width=150",
            },
          ],
          events: [
            {
              title: "Escola Bíblica Infantil",
              date: "Todos os domingos",
              time: "09:00",
              location: "Salas Infantis",
              description: "Aulas bíblicas divididas por faixas etárias.",
            },
            {
              title: "Festa do Dia das Crianças",
              date: "12 de Outubro, 2024",
              time: "14:00 - 18:00",
              location: "Salão Social",
              description: "Celebração especial com brincadeiras, lanches e apresentações.",
            },
          ],
          photos: [
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
          ],
          bannerImage:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-j8oney9dcC5v0xvrkOnLC7RWdNSgUM.png",
          icon: <span>👶</span>,
        },
        familia: {
          id: "familia",
          name: "Ministério da Família",
          description:
            "Apoio, aconselhamento e eventos para fortalecer casamentos e famílias segundo princípios bíblicos.",
          longDescription:
            "O Ministério da Família da Igreja Presbiteriana Renovada da Iputinga trabalha para fortalecer os laços familiares e promover relacionamentos saudáveis baseados nos princípios bíblicos. Oferecemos cursos para casais, aconselhamento familiar, palestras sobre educação de filhos e eventos que promovem a união familiar. Acreditamos que famílias fortes formam uma igreja forte e uma sociedade melhor.",
          mission:
            "Fortalecer as famílias da igreja e da comunidade através do ensino bíblico, aconselhamento e atividades que promovam relacionamentos saudáveis.",
          vision:
            "Ver famílias transformadas pelo evangelho, vivendo em harmonia e sendo testemunhas do amor de Cristo em seus lares e na sociedade.",
          leader: "Roberto e Marta Silva",
          leaderMessage:
            "A família é o projeto original de Deus para a humanidade. Em um mundo onde os valores familiares estão sendo constantemente atacados, nosso ministério está comprometido em equipar casais e pais para construírem lares que honram a Deus.",
          foundedYear: 2015,
          meetingDay: "Último sábado do mês",
          meetingTime: "19:30",
          meetingLocation: "Salão Social",
          members: [
            { name: "Roberto Silva", role: "Coordenador", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Marta Silva", role: "Coordenadora", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Paulo e Júlia Mendes", role: "Conselheiros", imageUrl: "/placeholder.svg?height=150&width=150" },
            {
              name: "Carlos e Beatriz Oliveira",
              role: "Equipe de Apoio",
              imageUrl: "/placeholder.svg?height=150&width=150",
            },
          ],
          events: [
            {
              title: "Encontro de Casais",
              date: "Último sábado do mês",
              time: "19:30",
              location: "Salão Social",
              description: "Encontro mensal com palestras, dinâmicas e momentos de comunhão para casais.",
            },
            {
              title: "Curso de Preparação para o Casamento",
              date: "Abril a Junho, 2024",
              time: "19:30 - 21:30",
              location: "Sala de Reuniões",
              description: "Curso de 8 semanas para noivos e recém-casados.",
            },
          ],
          photos: [
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
          ],
          bannerImage:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-j8oney9dcC5v0xvrkOnLC7RWdNSgUM.png",
          icon: <span>🏠</span>,
        },
        missoes: {
          id: "missoes",
          name: "Ministério de Missões",
          description: "Apoio a missionários e projetos de evangelização no Brasil e no exterior.",
          longDescription:
            "O Ministério de Missões da Igreja Presbiteriana Renovada da Iputinga tem como foco apoiar, enviar e cuidar de missionários que levam o evangelho a diferentes regiões do Brasil e do mundo. Trabalhamos para mobilizar a igreja para a obra missionária através de projetos, viagens missionárias, campanhas de arrecadação e conscientização sobre a importância de cumprir a Grande Comissão de Jesus.",
          mission:
            "Mobilizar a igreja para o cumprimento da Grande Comissão, apoiando missionários e projetos de evangelização em diferentes contextos culturais.",
          vision:
            "Ser uma igreja com visão missionária, onde cada membro entende seu papel na expansão do Reino de Deus e participa ativamente da obra missionária.",
          leader: "Paulo Santos",
          leaderMessage:
            "Missões não é apenas uma atividade da igreja, mas a razão pela qual ela existe. Nosso desejo é que cada membro da igreja entenda que é um missionário onde quer que esteja e que todos possamos contribuir para que o evangelho alcance os confins da terra.",
          foundedYear: 2013,
          meetingDay: "Primeira segunda-feira do mês",
          meetingTime: "19:30",
          meetingLocation: "Sala de Reuniões",
          members: [
            { name: "Paulo Santos", role: "Coordenador", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Raquel Lima", role: "Secretária", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "João Ferreira", role: "Tesoureiro", imageUrl: "/placeholder.svg?height=150&width=150" },
            {
              name: "Marcos e Débora Oliveira",
              role: "Missionários - Nordeste",
              imageUrl: "/placeholder.svg?height=150&width=150",
            },
            {
              name: "Ricardo Silva",
              role: "Missionário - Amazônia",
              imageUrl: "/placeholder.svg?height=150&width=150",
            },
          ],
          events: [
            {
              title: "Reunião de Oração por Missões",
              date: "Primeira segunda-feira do mês",
              time: "19:30",
              location: "Sala de Reuniões",
              description: "Momento de intercessão pelos missionários e campos missionários.",
            },
            {
              title: "Conferência Missionária Anual",
              date: "5-7 de Abril, 2024",
              time: "19:00",
              location: "Templo Principal",
              description: "Três dias de palestras e testemunhos sobre a obra missionária.",
            },
          ],
          photos: [
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
          ],
          bannerImage:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-j8oney9dcC5v0xvrkOnLC7RWdNSgUM.png",
          icon: <span>🌎</span>,
        },
        "primeiros-passos": {
          id: "primeiros-passos",
          name: "Ministério Primeiros Passos",
          description: "Acompanhamento e discipulado para novos convertidos e pessoas interessadas na fé cristã.",
          longDescription:
            "O Ministério Primeiros Passos da Igreja Presbiteriana Renovada da Iputinga é dedicado a acolher, integrar e discipular novos convertidos e pessoas que desejam conhecer melhor a fé cristã. Oferecemos cursos básicos sobre a Bíblia, doutrinas fundamentais da fé, vida cristã prática e a visão da nossa igreja. Nosso objetivo é ajudar cada pessoa a estabelecer uma base sólida para sua caminhada com Cristo.",
          mission:
            "Acolher e discipular novos convertidos e visitantes, ajudando-os a estabelecer fundamentos sólidos na fé cristã e a se integrarem à vida da igreja.",
          vision:
            "Ver cada novo membro crescendo em maturidade espiritual, descobrindo seus dons e se tornando um discípulo multiplicador.",
          leader: "Ricardo Oliveira",
          leaderMessage:
            "Os primeiros passos na fé são fundamentais para uma caminhada cristã saudável e duradoura. Estamos comprometidos em caminhar lado a lado com cada pessoa, oferecendo apoio, ensino e amizade nessa jornada de descoberta e crescimento espiritual.",
          foundedYear: 2016,
          meetingDay: "Domingos",
          meetingTime: "09:00",
          meetingLocation: "Sala 3",
          members: [
            { name: "Ricardo Oliveira", role: "Coordenador", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Fernanda Costa", role: "Vice-coordenadora", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Marcelo Lima", role: "Professor", imageUrl: "/placeholder.svg?height=150&width=150" },
            { name: "Juliana Santos", role: "Mentora", imageUrl: "/placeholder.svg?height=150&width=150" },
          ],
          events: [
            {
              title: "Curso Fundamentos da Fé",
              date: "Todos os domingos",
              time: "09:00",
              location: "Sala 3",
              description: "Curso básico de 12 semanas sobre os fundamentos da fé cristã.",
            },
            {
              title: "Encontro de Integração",
              date: "Primeiro sábado do mês",
              time: "16:00",
              location: "Salão Social",
              description: "Momento de comunhão e integração para novos membros e visitantes.",
            },
          ],
          photos: [
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
            "/placeholder.svg?height=400&width=600",
          ],
          bannerImage:
            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-j8oney9dcC5v0xvrkOnLC7RWdNSgUM.png",
          icon: <span>📚</span>,
        },
      }

      if (ministryId && ministries[ministryId]) {
        setMinistry(ministries[ministryId])
      }
      setLoading(false)
    }

    loadMinistryData()
  }, [ministryId])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-xl text-gray-600">Carregando...</p>
      </div>
    )
  }

  if (!ministry) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto max-w-6xl px-4 py-16">
          <h1 className="text-3xl font-bold text-center mb-6 text-red-600">Ministério não encontrado</h1>
          <p className="text-center text-gray-600 mb-8">
            O ministério que você está procurando não existe ou foi removido.
          </p>
          <div className="flex justify-center">
            <Link
              href="/ministerios"
              className="bg-blue-600 text-white py-2 px-6 rounded-md hover:bg-blue-700 transition-colors"
            >
              Ver todos os ministérios
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      {/* Banner */}
      <section className="relative bg-blue-900 text-white">
        {/* Overlay de fundo */}
        <div
          className="absolute inset-0 bg-gradient-to-r from-black/70 to-blue-900/50 z-10"
          style={{
            backgroundImage: `url('${ministry.bannerImage}')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            mixBlendMode: "normal",
          }}
        ></div>

        <div className="container mx-auto max-w-6xl px-4 py-20 md:py-28 relative z-20">
          <div className="max-w-3xl backdrop-blur-sm bg-black/30 p-6 rounded-lg">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">{ministry.name}</h1>
            <p className="text-xl text-blue-100 mb-4">{ministry.description}</p>
            <div className="flex items-center text-blue-200">
              <Users className="h-5 w-5 mr-2" />
              <span>
                Liderado por {ministry.leader} • Desde {ministry.foundedYear}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Coluna Principal */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-md p-8 mb-8">
                <h2 className="text-2xl font-bold text-blue-800 mb-6">Sobre o Ministério</h2>
                <p className="text-gray-700 mb-6">{ministry.longDescription}</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Missão</h3>
                    <p className="text-gray-700">{ministry.mission}</p>
                  </div>
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Visão</h3>
                    <p className="text-gray-700">{ministry.vision}</p>
                  </div>
                </div>

                {ministry.leaderMessage && (
                  <div className="border-l-4 border-blue-600 pl-4 py-2 mb-6">
                    <p className="text-gray-700 italic">{ministry.leaderMessage}</p>
                    <p className="text-blue-800 font-medium mt-2">— {ministry.leader}, Líder do Ministério</p>
                  </div>
                )}
              </div>

              {/* Equipe */}
              <div className="bg-white rounded-lg shadow-md p-8 mb-8">
                <h2 className="text-2xl font-bold text-blue-800 mb-6">Nossa Equipe</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                  {ministry.members.map((member, index) => (
                    <div key={index} className="text-center">
                      <div className="w-24 h-24 mx-auto rounded-full overflow-hidden mb-3 relative">
                        <Image
                          src={member.imageUrl || "/placeholder.svg"}
                          alt={member.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <h3 className="font-bold text-gray-900">{member.name}</h3>
                      <p className="text-sm text-gray-600">{member.role}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Eventos */}
              <div className="bg-white rounded-lg shadow-md p-8 mb-8">
                <h2 className="text-2xl font-bold text-blue-800 mb-6">Eventos e Atividades</h2>
                <div className="space-y-6">
                  {ministry.events.map((event, index) => (
                    <div key={index} className="border-b border-gray-100 pb-6 last:border-0 last:pb-0">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{event.title}</h3>
                      <div className="flex flex-wrap gap-y-2 gap-x-4 text-gray-600 mb-3">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1 text-blue-600" />
                          <span>{event.date}</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1 text-blue-600" />
                          <span>{event.time}</span>
                        </div>
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1 text-blue-600" />
                          <span>{event.location}</span>
                        </div>
                      </div>
                      <p className="text-gray-700">{event.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Galeria */}
              <div className="bg-white rounded-lg shadow-md p-8">
                <h2 className="text-2xl font-bold text-blue-800 mb-6">Galeria</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {ministry.photos.map((photo, index) => (
                    <div key={index} className="aspect-square relative rounded-lg overflow-hidden">
                      <Image
                        src={photo || "/placeholder.svg"}
                        alt={`Foto ${index + 1} do ${ministry.name}`}
                        fill
                        className="object-cover hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div>
              {/* Informações de Reuniões */}
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h3 className="text-xl font-bold text-blue-800 mb-4">Informações</h3>

                {ministry.meetingDay && (
                  <div className="mb-4">
                    <h4 className="font-bold text-gray-900 mb-2">Reuniões</h4>
                    <div className="flex items-start mb-1">
                      <Calendar className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-gray-700">{ministry.meetingDay}</p>
                      </div>
                    </div>
                    <div className="flex items-start mb-1">
                      <Clock className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-gray-700">{ministry.meetingTime}</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <MapPin className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-gray-700">{ministry.meetingLocation}</p>
                      </div>
                    </div>
                  </div>
                )}

                <div>
                  <h4 className="font-bold text-gray-900 mb-2">Contato</h4>
                  <div className="flex items-start mb-1">
                    <Mail className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-gray-700">ministerio.{ministry.id}@ipreiputinga.org</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Phone className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-gray-700">(81) 3333-4444</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Participar */}
              <div className="bg-blue-700 rounded-lg shadow-md p-6 text-white mb-6">
                <h3 className="text-xl font-bold mb-4">Faça Parte</h3>
                <p className="mb-4">
                  Quer participar do {ministry.name}? Preencha o formulário abaixo e entraremos em contato.
                </p>
                <form className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-blue-100 mb-1">
                      Nome
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="w-full px-3 py-2 bg-blue-600 border border-blue-500 rounded-md text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
                      placeholder="Seu nome completo"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-blue-100 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full px-3 py-2 bg-blue-600 border border-blue-500 rounded-md text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
                      placeholder="seu.email@exemplo.com"
                    />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-blue-100 mb-1">
                      Telefone
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      className="w-full px-3 py-2 bg-blue-600 border border-blue-500 rounded-md text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
                      placeholder="(00) 00000-0000"
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-blue-100 mb-1">
                      Mensagem
                    </label>
                    <textarea
                      id="message"
                      rows={3}
                      className="w-full px-3 py-2 bg-blue-600 border border-blue-500 rounded-md text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
                      placeholder="Conte-nos um pouco sobre você e seu interesse no ministério..."
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-white text-blue-700 font-bold py-2 px-4 rounded-md hover:bg-blue-50 transition-colors"
                  >
                    Enviar Mensagem
                  </button>
                </form>
              </div>

              {/* Outros Ministérios */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-xl font-bold text-blue-800 mb-4">Outros Ministérios</h3>
                <ul className="space-y-3">
                  <li>
                    <Link href="/ministerios/louvor" className="flex items-center text-gray-700 hover:text-blue-600">
                      <ArrowRight className="h-4 w-4 mr-2" />
                      <span>Ministério de Louvor</span>
                    </Link>
                  </li>
                  <li>
                    <Link href="/ministerios/jovens" className="flex items-center text-gray-700 hover:text-blue-600">
                      <ArrowRight className="h-4 w-4 mr-2" />
                      <span>Ministério de Jovens</span>
                    </Link>
                  </li>
                  <li>
                    <Link href="/ministerios/criancas" className="flex items-center text-gray-700 hover:text-blue-600">
                      <ArrowRight className="h-4 w-4 mr-2" />
                      <span>Ministério de Crianças</span>
                    </Link>
                  </li>
                  <li>
                    <Link href="/ministerios/familia" className="flex items-center text-gray-700 hover:text-blue-600">
                      <ArrowRight className="h-4 w-4 mr-2" />
                      <span>Ministério da Família</span>
                    </Link>
                  </li>
                  <li>
                    <Link href="/ministerios/missoes" className="flex items-center text-gray-700 hover:text-blue-600">
                      <ArrowRight className="h-4 w-4 mr-2" />
                      <span>Ministério de Missões</span>
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/ministerios/primeiros-passos"
                      className="flex items-center text-gray-700 hover:text-blue-600"
                    >
                      <ArrowRight className="h-4 w-4 mr-2" />
                      <span>Ministério Primeiros Passos</span>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

