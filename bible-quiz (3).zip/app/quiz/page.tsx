"use client"
import Link from "next/link"
import Image from "next/image"
import { Book, Clock, ChevronRight, Info } from "lucide-react"
import Header from "@/components/header"
import Footer from "@/components/footer"

export default function QuizPage() {
  // Níveis do quiz
  const levels = [
    { id: 1, name: "Iniciante", questions: 10, timeLimit: "5 minutos", unlocked: true },
    { id: 2, name: "Intermediário", questions: 15, timeLimit: "7 minutos", unlocked: true },
    { id: 3, name: "Avançado", questions: 20, timeLimit: "10 minutos", unlocked: true },
    { id: 4, name: "Especialista", questions: 25, timeLimit: "12 minutos", unlocked: true },
    { id: 5, name: "Mestre Bíblico", questions: 30, timeLimit: "15 minutos", unlocked: true },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Banner do Quiz */}
      <div className="bg-blue-800 text-white py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-8 md:mb-0 md:mr-8">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Quiz Bíblico</h1>
              <p className="text-blue-100 text-lg mb-6">
                Teste seus conhecimentos bíblicos e divirta-se aprendendo mais sobre a Palavra de Deus.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link
                  href="/quiz/1"
                  className="bg-white text-blue-800 px-6 py-3 rounded-md font-bold hover:bg-blue-50 transition-colors"
                >
                  Começar a Jogar
                </Link>
              </div>
            </div>
            <div className="w-full md:w-auto">
              <Image
                src="/placeholder.svg?height=200&width=300"
                alt="Quiz Bíblico"
                width={300}
                height={200}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Conteúdo Principal */}
      <div className="container mx-auto max-w-6xl py-12 px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Níveis */}
          <div className="md:col-span-2">
            <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
              <div className="bg-blue-700 text-white px-6 py-4">
                <h2 className="text-xl font-bold flex items-center">
                  <Book className="mr-2 h-5 w-5" />
                  Níveis do Quiz
                </h2>
              </div>
              <div className="p-6">
                <p className="text-gray-600 mb-6">
                  Escolha um nível para começar a jogar. Cada nível tem um número diferente de perguntas e um limite de
                  tempo.
                </p>

                <div className="space-y-4">
                  {levels.map((level) => (
                    <div
                      key={level.id}
                      className={`border rounded-lg p-4 transition-all ${
                        level.unlocked
                          ? "border-blue-200 hover:border-blue-500 hover:shadow-md cursor-pointer"
                          : "border-gray-200 bg-gray-50 opacity-70 cursor-not-allowed"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-bold text-lg text-blue-800">{level.name}</h3>
                          <div className="flex items-center text-sm text-gray-500 mt-1">
                            <div className="flex items-center mr-4">
                              <Book className="h-4 w-4 mr-1" />
                              {level.questions} perguntas
                            </div>
                            <div className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              {level.timeLimit}
                            </div>
                          </div>
                        </div>
                        {level.unlocked ? (
                          <Link
                            href={`/quiz/${level.id}`}
                            className="bg-blue-100 text-blue-700 p-2 rounded-full hover:bg-blue-200 transition-colors"
                          >
                            <ChevronRight className="h-5 w-5" />
                          </Link>
                        ) : (
                          <div className="bg-gray-100 text-gray-400 p-2 rounded-full">
                            <ChevronRight className="h-5 w-5" />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Estatísticas */}
          <div>
            <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
              <div className="bg-blue-700 text-white px-6 py-4">
                <h2 className="text-xl font-bold">Estatísticas</h2>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-blue-50 rounded-lg p-4 text-center">
                    <p className="text-sm text-blue-700 font-medium">Perguntas</p>
                    <p className="text-2xl font-bold text-blue-800 mt-1">230</p>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-4 text-center">
                    <p className="text-sm text-blue-700 font-medium">Categorias</p>
                    <p className="text-2xl font-bold text-blue-800 mt-1">12</p>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-4 text-center">
                    <p className="text-sm text-blue-700 font-medium">Níveis</p>
                    <p className="text-2xl font-bold text-blue-800 mt-1">5</p>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-4 text-center">
                    <p className="text-sm text-blue-700 font-medium">Dificuldade</p>
                    <p className="text-2xl font-bold text-blue-800 mt-1">Variada</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Como Jogar */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden mt-8">
          <div className="bg-blue-700 text-white px-6 py-4">
            <h2 className="text-xl font-bold flex items-center">
              <Info className="mr-2 h-5 w-5" />
              Como Jogar
            </h2>
          </div>
          <div className="p-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-blue-50 p-6 rounded-lg">
                <div className="flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 text-blue-800 font-bold text-xl mb-4 mx-auto">
                  1
                </div>
                <h3 className="text-lg font-medium text-gray-900 text-center mb-2">Escolha um nível</h3>
                <p className="text-gray-600 text-center">
                  Selecione o nível de dificuldade que deseja jogar. Níveis mais altos têm mais perguntas e são mais
                  desafiadores.
                </p>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg">
                <div className="flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 text-blue-800 font-bold text-xl mb-4 mx-auto">
                  2
                </div>
                <h3 className="text-lg font-medium text-gray-900 text-center mb-2">Responda às perguntas</h3>
                <p className="text-gray-600 text-center">
                  Leia cada pergunta com atenção e selecione a resposta que você acredita ser correta. Você tem um tempo
                  limitado para responder a todas as perguntas.
                </p>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg">
                <div className="flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 text-blue-800 font-bold text-xl mb-4 mx-auto">
                  3
                </div>
                <h3 className="text-lg font-medium text-gray-900 text-center mb-2">Veja sua pontuação</h3>
                <p className="text-gray-600 text-center">
                  Ao final do quiz, você verá sua pontuação e as respostas corretas para as perguntas que errou. Tente
                  novamente para melhorar seu desempenho!
                </p>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg">
                <div className="flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 text-blue-800 font-bold text-xl mb-4 mx-auto">
                  4
                </div>
                <h3 className="text-lg font-medium text-gray-900 text-center mb-2">Aprenda mais</h3>
                <p className="text-gray-600 text-center">
                  Cada pergunta vem com uma explicação após você responder, ajudando você a aprofundar seu conhecimento
                  bíblico.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}

