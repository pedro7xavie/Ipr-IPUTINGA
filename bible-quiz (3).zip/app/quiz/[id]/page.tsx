"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Clock, CheckCircle, XCircle, ChevronRight, ArrowLeft } from "lucide-react"
import Header from "@/components/header"
import Footer from "@/components/footer"

// Tipos
interface Question {
  id: number
  text: string
  options: string[]
  correctAnswer: number
  explanation?: string
}

interface QuizParams {
  params: {
    id: string
  }
}

export default function QuizQuestionPage({ params }: QuizParams) {
  const levelId = Number.parseInt(params.id)
  const router = useRouter()

  // Estados
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const [showResult, setShowResult] = useState(false)
  const [timeLeft, setTimeLeft] = useState(300) // 5 minutos em segundos
  const [answers, setAnswers] = useState<number[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Perguntas simuladas
  const questions: Question[] = [
    {
      id: 1,
      text: "Quem foi o primeiro rei de Israel?",
      options: ["Davi", "Saul", "Salomão", "Samuel"],
      correctAnswer: 1,
      explanation: "Saul foi o primeiro rei de Israel, ungido pelo profeta Samuel. Sua história é contada em 1 Samuel.",
    },
    {
      id: 2,
      text: "Quantos livros tem o Novo Testamento?",
      options: ["27", "39", "66", "12"],
      correctAnswer: 0,
      explanation: "O Novo Testamento contém 27 livros, desde Mateus até Apocalipse.",
    },
    {
      id: 3,
      text: "Quem escreveu a maior parte das epístolas no Novo Testamento?",
      options: ["Pedro", "João", "Paulo", "Tiago"],
      correctAnswer: 2,
      explanation:
        "O apóstolo Paulo escreveu 13 das 21 epístolas do Novo Testamento, sendo o autor que mais contribuiu para esta seção da Bíblia.",
    },
    {
      id: 4,
      text: "Qual profeta foi engolido por um grande peixe?",
      options: ["Elias", "Jonas", "Eliseu", "Jeremias"],
      correctAnswer: 1,
      explanation:
        "Jonas foi engolido por um grande peixe quando tentava fugir do chamado de Deus para pregar em Nínive.",
    },
    {
      id: 5,
      text: "Quem negou Jesus três vezes?",
      options: ["João", "Judas", "Pedro", "Tomé"],
      correctAnswer: 2,
      explanation:
        "Pedro negou conhecer Jesus três vezes antes do galo cantar, conforme Jesus havia predito durante a Última Ceia.",
    },
    {
      id: 6,
      text: "Qual foi o primeiro milagre de Jesus registrado na Bíblia?",
      options: ["Multiplicação dos pães", "Cura de um leproso", "Transformar água em vinho", "Ressuscitar Lázaro"],
      correctAnswer: 2,
      explanation:
        "O primeiro milagre de Jesus registrado foi transformar água em vinho nas Bodas de Caná, conforme relatado em João 2:1-11.",
    },
    {
      id: 7,
      text: "Quem foi o pai de Salomão?",
      options: ["Saul", "Davi", "Josias", "Roboão"],
      correctAnswer: 1,
      explanation:
        "Davi foi o pai de Salomão. Salomão era filho de Davi com Bate-Seba e se tornou o terceiro rei de Israel.",
    },
    {
      id: 8,
      text: "Qual livro da Bíblia contém os Dez Mandamentos?",
      options: ["Gênesis", "Êxodo", "Levítico", "Deuteronômio"],
      correctAnswer: 1,
      explanation:
        "Os Dez Mandamentos são encontrados primeiramente em Êxodo 20:1-17, e depois repetidos em Deuteronômio 5:6-21.",
    },
    {
      id: 9,
      text: "Quem foi lançado na cova dos leões?",
      options: ["Daniel", "Jeremias", "Ezequiel", "Isaías"],
      correctAnswer: 0,
      explanation:
        "Daniel foi lançado na cova dos leões por continuar orando a Deus, contrariando o decreto do rei Dario que proibia adorar qualquer deus ou homem exceto o próprio rei.",
    },
    {
      id: 10,
      text: "Qual discípulo duvidou da ressurreição de Jesus?",
      options: ["Pedro", "João", "Tomé", "Tiago"],
      correctAnswer: 2,
      explanation:
        "Tomé duvidou da ressurreição de Jesus e disse que só acreditaria se pudesse ver e tocar as marcas dos pregos em suas mãos. Jesus apareceu a ele e disse: 'Bem-aventurados os que não viram e creram'.",
    },
  ]

  // Configurações do nível
  const levelConfig = {
    1: { questions: 10, timeLimit: 300 }, // 5 minutos
    2: { questions: 10, timeLimit: 420 }, // 7 minutos
    3: { questions: 10, timeLimit: 600 }, // 10 minutos
    4: { questions: 10, timeLimit: 720 }, // 12 minutos
    5: { questions: 10, timeLimit: 900 }, // 15 minutos
  }

  // Inicializar temporizador
  useEffect(() => {
    // Definir tempo com base no nível
    const config = levelConfig[levelId as keyof typeof levelConfig] || levelConfig[1]
    setTimeLeft(config.timeLimit)

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          if (!showResult) {
            handleFinishQuiz()
          }
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [levelId, showResult])

  // Formatar tempo
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  // Calcular progresso
  const progress = ((currentQuestion + 1) / questions.length) * 100

  // Selecionar opção
  const handleSelectOption = (index: number) => {
    if (showResult) return
    setSelectedOption(index)
  }

  // Próxima pergunta
  const handleNextQuestion = () => {
    if (selectedOption === null) return

    // Salvar resposta
    const newAnswers = [...answers]
    newAnswers[currentQuestion] = selectedOption
    setAnswers(newAnswers)

    // Atualizar pontuação
    if (selectedOption === questions[currentQuestion].correctAnswer) {
      setScore((prev) => prev + 1)
    }

    // Próxima pergunta ou finalizar
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
      setSelectedOption(null)
    } else {
      handleFinishQuiz()
    }
  }

  // Finalizar quiz
  const handleFinishQuiz = () => {
    // Salvar última resposta se não foi salva
    if (!showResult && selectedOption !== null) {
      const newAnswers = [...answers]
      newAnswers[currentQuestion] = selectedOption
      setAnswers(newAnswers)

      if (selectedOption === questions[currentQuestion].correctAnswer) {
        setScore((prev) => prev + 1)
      }
    }

    setShowResult(true)
  }

  // Reiniciar quiz
  const handleRestartQuiz = () => {
    setCurrentQuestion(0)
    setSelectedOption(null)
    setScore(0)
    setShowResult(false)
    setAnswers([])
    setTimeLeft(levelConfig[levelId as keyof typeof levelConfig].timeLimit)
  }

  // Calcular porcentagem de acertos
  const percentage = Math.round((score / questions.length) * 100)

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <Header />
      <div className="container mx-auto max-w-3xl">
        {/* Cabeçalho */}
        <div className="mb-8">
          <Link href="/quiz" className="inline-flex items-center text-blue-700 hover:text-blue-800 mb-4">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Voltar para o Quiz
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">
            Nível {levelId}:{" "}
            {levelId === 1
              ? "Iniciante"
              : levelId === 2
                ? "Intermediário"
                : levelId === 3
                  ? "Avançado"
                  : levelId === 4
                    ? "Especialista"
                    : "Mestre Bíblico"}
          </h1>
        </div>

        {/* Conteúdo do Quiz */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          {/* Barra de Progresso e Tempo */}
          <div className="bg-blue-700 text-white px-6 py-4">
            {!showResult && (
              <div className="flex justify-between items-center">
                <div className="flex-1 mr-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Progresso</span>
                    <span>
                      {currentQuestion + 1}/{questions.length}
                    </span>
                  </div>
                  <div className="w-full bg-blue-600 rounded-full h-2.5">
                    <div className="bg-white h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                  </div>
                </div>
                <div className="flex items-center bg-blue-800 px-3 py-1 rounded-full">
                  <Clock className="h-4 w-4 mr-1" />
                  <span className="font-mono">{formatTime(timeLeft)}</span>
                </div>
              </div>
            )}
            {showResult && (
              <div className="text-center">
                <h2 className="text-xl font-bold">Resultado do Quiz</h2>
              </div>
            )}
          </div>

          {/* Conteúdo */}
          <div className="p-6">
            {/* Perguntas */}
            {!showResult && (
              <div>
                <h2 className="text-xl font-bold mb-4">
                  {currentQuestion + 1}. {questions[currentQuestion].text}
                </h2>

                <div className="space-y-3 mb-8">
                  {questions[currentQuestion].options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleSelectOption(index)}
                      className={`w-full text-left p-4 rounded-lg border transition-all ${
                        selectedOption === index
                          ? "border-blue-500 bg-blue-50 text-blue-700"
                          : "border-gray-200 hover:border-blue-300 hover:bg-blue-50"
                      }`}
                    >
                      <div className="flex items-center">
                        <div
                          className={`flex-shrink-0 h-5 w-5 mr-2 rounded-full border ${
                            selectedOption === index ? "border-blue-500 bg-blue-500" : "border-gray-300"
                          }`}
                        >
                          {selectedOption === index && (
                            <div className="h-full w-full flex items-center justify-center">
                              <div className="h-2 w-2 bg-white rounded-full"></div>
                            </div>
                          )}
                        </div>
                        <span>{option}</span>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleNextQuestion}
                    disabled={selectedOption === null}
                    className={`flex items-center px-6 py-2 rounded-md font-medium ${
                      selectedOption === null
                        ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                        : "bg-blue-600 text-white hover:bg-blue-700"
                    }`}
                  >
                    {currentQuestion < questions.length - 1 ? (
                      <>
                        Próxima
                        <ChevronRight className="h-5 w-5 ml-1" />
                      </>
                    ) : (
                      <>
                        Finalizar
                        <CheckCircle className="h-5 w-5 ml-1" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Resultados */}
            {showResult && (
              <div>
                <div className="text-center mb-8">
                  <div className="inline-flex items-center justify-center h-24 w-24 rounded-full bg-blue-100 text-blue-800 mb-4">
                    <span className="text-3xl font-bold">{percentage}%</span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">
                    Você acertou {score} de {questions.length} perguntas!
                  </h3>
                  <p className="text-gray-600 mt-1">
                    {percentage >= 80
                      ? "Excelente trabalho!"
                      : percentage >= 60
                        ? "Bom trabalho!"
                        : percentage >= 40
                          ? "Continue estudando!"
                          : "Não desanime, continue estudando!"}
                  </p>
                </div>

                {/* Revisão das Perguntas */}
                <div className="border-t border-gray-200 pt-6 mt-6">
                  <h3 className="text-lg font-bold mb-4">Revisão das Perguntas</h3>

                  <div className="space-y-6">
                    {questions.map((question, qIndex) => (
                      <div key={qIndex} className="border-b border-gray-100 pb-4 last:border-0">
                        <div className="flex items-start">
                          <div className="flex-shrink-0 mt-1">
                            {answers[qIndex] === question.correctAnswer ? (
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            ) : (
                              <XCircle className="h-5 w-5 text-red-500" />
                            )}
                          </div>
                          <div className="ml-3">
                            <p className="font-medium text-gray-900">
                              {qIndex + 1}. {question.text}
                            </p>
                            <div className="mt-2 space-y-2">
                              {question.options.map((option, oIndex) => (
                                <div
                                  key={oIndex}
                                  className={`text-sm p-2 rounded ${
                                    oIndex === question.correctAnswer
                                      ? "bg-green-50 text-green-800"
                                      : answers[qIndex] === oIndex && oIndex !== question.correctAnswer
                                        ? "bg-red-50 text-red-800"
                                        : "text-gray-600"
                                  }`}
                                >
                                  {option}
                                  {oIndex === question.correctAnswer && (
                                    <span className="ml-2 text-green-600 font-medium">(Resposta correta)</span>
                                  )}
                                </div>
                              ))}
                            </div>
                            {question.explanation && (
                              <div className="mt-3 bg-blue-50 p-3 rounded-md text-sm text-blue-800">
                                <p className="font-medium mb-1">Explicação:</p>
                                <p>{question.explanation}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Botões de Ação */}
                <div className="flex flex-col sm:flex-row justify-center gap-4 mt-8">
                  <button
                    onClick={handleRestartQuiz}
                    className="bg-blue-600 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-700 transition-colors"
                  >
                    Tentar Novamente
                  </button>
                  <Link
                    href="/quiz"
                    className="bg-white text-blue-700 border border-blue-300 px-6 py-2 rounded-md font-medium hover:bg-blue-50 transition-colors text-center"
                  >
                    Voltar para o Quiz
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="mt-12">
        <Footer />
      </div>
    </div>
  )
}

