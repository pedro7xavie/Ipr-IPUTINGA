import Header from "@/components/header"
import Footer from "@/components/footer"
import Image from "next/image"
import Link from "next/link"
import { Search, Filter, Play, Calendar, User, ChevronRight } from "lucide-react"

export default function SermoesPage() {
  // Dados de exemplo para sermões
  const sermoes = [
    {
      id: 1,
      titulo: "O Poder da Oração",
      pastor: "Pr. João Silva",
      data: "05/03/2024",
      descricao:
        "Neste sermão, exploramos o poder transformador da oração na vida do cristão e como desenvolver uma vida de oração eficaz.",
      imagem: "/placeholder.svg?height=200&width=300",
      videoUrl: "#",
      categoria: "Vida Cristã",
    },
    {
      id: 2,
      titulo: "Vivendo pela Fé",
      pastor: "Pr. João Silva",
      data: "28/02/2024",
      descricao: "Uma mensagem sobre como viver pela fé em um mundo de incertezas, baseada em Hebreus 11.",
      imagem: "/placeholder.svg?height=200&width=300",
      videoUrl: "#",
      categoria: "Fé",
    },
    {
      id: 3,
      titulo: "A Graça de Deus",
      pastor: "Pr. João Silva",
      data: "21/02/2024",
      descricao: "Um estudo profundo sobre a graça de Deus e como ela opera em nossas vidas.",
      imagem: "/placeholder.svg?height=200&width=300",
      videoUrl: "#",
      categoria: "Doutrina",
    },
    {
      id: 4,
      titulo: "Família Segundo o Coração de Deus",
      pastor: "Pr. Pedro Oliveira",
      data: "14/02/2024",
      descricao:
        "Princípios bíblicos para construir uma família saudável e centrada em Deus, abordando o papel de cada membro.",
      imagem: "/placeholder.svg?height=200&width=300",
      videoUrl: "#",
      categoria: "Família",
    },
    {
      id: 5,
      titulo: "O Fruto do Espírito",
      pastor: "Pr. João Silva",
      data: "07/02/2024",
      descricao: "Uma análise detalhada do fruto do Espírito em Gálatas 5 e como cultivá-lo em nossa vida diária.",
      imagem: "/placeholder.svg?height=200&width=300",
      videoUrl: "#",
      categoria: "Espírito Santo",
    },
    {
      id: 6,
      titulo: "Vencendo as Tentações",
      pastor: "Pr. Pedro Oliveira",
      data: "31/01/2024",
      descricao: "Estratégias bíblicas para identificar e vencer as tentações que enfrentamos no dia a dia.",
      imagem: "/placeholder.svg?height=200&width=300",
      videoUrl: "#",
      categoria: "Vida Cristã",
    },
  ]

  // Categorias de sermões
  const categorias = ["Todos", "Vida Cristã", "Fé", "Doutrina", "Família", "Espírito Santo", "Evangelismo", "Missões"]

  // Pastores
  const pastores = ["Todos", "Pr. João Silva", "Pr. Pedro Oliveira"]

  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      {/* Banner */}
      <section className="bg-blue-800 text-white py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-4">Sermões</h1>
          <p className="text-xl text-blue-100 max-w-3xl">
            Ouça e assista nossas mensagens para crescer na fé e no conhecimento da Palavra de Deus.
          </p>
        </div>
      </section>

      {/* Filtros e Busca */}
      <section className="py-8 px-4 bg-white border-b">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="flex flex-col w-full md:w-auto gap-4">
              <div className="flex items-center">
                <Filter className="h-5 w-5 text-gray-500 mr-2" />
                <span className="text-gray-700 font-medium mr-3">Categorias:</span>
                <select className="border border-gray-300 rounded-md py-1 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                  {categorias.map((categoria, index) => (
                    <option key={index} value={categoria}>
                      {categoria}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center">
                <User className="h-5 w-5 text-gray-500 mr-2" />
                <span className="text-gray-700 font-medium mr-3">Pregador:</span>
                <select className="border border-gray-300 rounded-md py-1 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                  {pastores.map((pastor, index) => (
                    <option key={index} value={pastor}>
                      {pastor}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="relative w-full md:w-64">
              <input
                type="text"
                placeholder="Buscar sermões..."
                className="w-full border border-gray-300 rounded-md py-2 pl-10 pr-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            </div>
          </div>
        </div>
      </section>

      {/* Lista de Sermões */}
      <section className="py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-2xl font-bold text-blue-800 mb-6">Sermões Recentes</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sermoes.map((sermao) => (
              <div key={sermao.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <Image
                    src={sermao.imagem || "/placeholder.svg"}
                    alt={sermao.titulo}
                    width={300}
                    height={200}
                    className="w-full h-48 object-cover"
                  />
                  <Link
                    href={sermao.videoUrl}
                    className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 hover:opacity-100 transition-opacity"
                  >
                    <div className="bg-blue-600 rounded-full p-3">
                      <Play className="w-8 h-8 text-white" />
                    </div>
                  </Link>
                  <div className="absolute top-2 right-2 bg-blue-100 text-blue-800 text-xs font-bold px-2 py-1 rounded">
                    {sermao.categoria}
                  </div>
                </div>

                <div className="p-5">
                  <h3 className="text-lg font-bold text-blue-800 mb-2">{sermao.titulo}</h3>

                  <div className="flex items-center text-gray-600 mb-1">
                    <User className="h-4 w-4 mr-2" />
                    <span>{sermao.pastor}</span>
                  </div>

                  <div className="flex items-center text-gray-600 mb-3">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>{sermao.data}</span>
                  </div>

                  <p className="text-gray-600 mb-4 line-clamp-2">{sermao.descricao}</p>

                  <Link
                    href={`/sermoes/${sermao.id}`}
                    className="inline-flex items-center text-blue-600 font-medium hover:text-blue-800"
                  >
                    Ver Detalhes <ChevronRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
              </div>
            ))}
          </div>

          {/* Paginação */}
          <div className="mt-12 flex justify-center">
            <nav className="inline-flex rounded-md shadow">
              <a
                href="#"
                className="py-2 px-4 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
              >
                Anterior
              </a>
              <a
                href="#"
                className="py-2 px-4 border border-gray-300 bg-blue-50 text-sm font-medium text-blue-600 hover:bg-blue-100"
              >
                1
              </a>
              <a
                href="#"
                className="py-2 px-4 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
              >
                2
              </a>
              <a
                href="#"
                className="py-2 px-4 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
              >
                3
              </a>
              <a
                href="#"
                className="py-2 px-4 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
              >
                Próxima
              </a>
            </nav>
          </div>
        </div>
      </section>

      {/* Séries de Sermões */}
      <section className="py-12 px-4 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-2xl font-bold text-blue-800 mb-6">Séries de Sermões</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { titulo: "Frutos do Espírito", quantidade: 9, imagem: "/placeholder.svg?height=200&width=300" },
              { titulo: "Vida de Oração", quantidade: 6, imagem: "/placeholder.svg?height=200&width=300" },
              { titulo: "Família Cristã", quantidade: 5, imagem: "/placeholder.svg?height=200&width=300" },
              { titulo: "Evangelismo Prático", quantidade: 4, imagem: "/placeholder.svg?height=200&width=300" },
            ].map((serie, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="h-40 relative">
                  <Image src={serie.imagem || "/placeholder.svg"} alt={serie.titulo} fill className="object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                    <div className="p-4 text-white">
                      <h3 className="font-bold text-lg">{serie.titulo}</h3>
                      <p className="text-sm">{serie.quantidade} sermões</p>
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <Link
                    href={`/sermoes/series/${index + 1}`}
                    className="w-full block text-center bg-blue-600 text-white py-2 rounded-md font-medium hover:bg-blue-700 transition-colors"
                  >
                    Ver Série
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Inscrição */}
      <section className="py-12 px-4 bg-blue-700 text-white">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Receba Novos Sermões</h2>
            <p className="text-blue-100 max-w-2xl mx-auto mb-8">
              Inscreva-se para receber notificações quando novos sermões forem publicados.
            </p>

            <div className="max-w-md mx-auto flex">
              <input
                type="email"
                placeholder="Seu e-mail"
                className="flex-1 py-3 px-4 rounded-l-md focus:outline-none text-gray-900"
              />
              <button className="bg-blue-900 hover:bg-blue-800 text-white py-3 px-6 rounded-r-md font-medium transition-colors">
                Inscrever
              </button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

