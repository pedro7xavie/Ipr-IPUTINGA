import Image from "next/image"
import Link from "next/link"
import { Calendar, Clock, MapPin } from "lucide-react"

import Header from "@/components/header"
import Footer from "@/components/footer"
import HeroSection from "@/components/hero-section"
import EventCard from "@/components/event-card"
import SermonCard from "@/components/sermon-card"
import TestimonyCard from "@/components/testimony-card"
import LiveBanner from "@/components/live-banner"

export default function HomePage() {
  // Dados de exemplo para a igreja
  const isLive = false // Altere para true quando houver transmissão ao vivo
  const events = [
    {
      id: 1,
      title: "Culto de Adoração",
      date: "Domingo, 10 de Março",
      time: "18:00",
      description: "Venha adorar ao Senhor conosco em nosso culto dominical.",
    },
    {
      id: 2,
      title: "Estudo Bíblico",
      date: "Quarta-feira, 13 de Março",
      time: "19:30",
      description: "Aprofunde seu conhecimento na Palavra de Deus.",
    },
    {
      id: 3,
      title: "Culto de Jovens",
      date: "Sábado, 16 de Março",
      time: "19:00",
      description: "Um momento especial para nossa juventude.",
    },
  ]

  const sermons = [
    {
      id: 1,
      title: "O Poder da Oração",
      pastor: "Pr. João Silva",
      date: "05/03/2024",
      imageUrl: "/placeholder.svg?height=200&width=300",
      videoUrl: "#",
    },
    {
      id: 2,
      title: "Vivendo pela Fé",
      pastor: "Pr. João Silva",
      date: "28/02/2024",
      imageUrl: "/placeholder.svg?height=200&width=300",
      videoUrl: "#",
    },
    {
      id: 3,
      title: "A Graça de Deus",
      pastor: "Pr. João Silva",
      date: "21/02/2024",
      imageUrl: "/placeholder.svg?height=200&width=300",
      videoUrl: "#",
    },
  ]

  const testimonies = [
    {
      id: 1,
      name: "Maria Santos",
      testimony:
        "Deus transformou minha vida através do ministério desta igreja. Sou muito grata por fazer parte desta família.",
      imageUrl: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 2,
      name: "Pedro Oliveira",
      testimony: "Encontrei acolhimento e direção espiritual nesta comunidade. Minha família tem sido abençoada.",
      imageUrl: "/placeholder.svg?height=100&width=100",
    },
  ]

  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      {isLive && <LiveBanner />}

      <HeroSection />

      {/* Sobre a Igreja */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-8 text-blue-800">
            Bem-vindo à Igreja Presbiteriana Renovada da Iputinga
          </h2>

          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <p className="text-lg mb-4">
                Somos uma comunidade cristã comprometida com a Palavra de Deus e com a transformação de vidas através do
                evangelho de Jesus Cristo.
              </p>
              <p className="text-lg mb-4">
                Nossa missão é adorar a Deus, edificar os crentes e alcançar os perdidos, sendo sal e luz na comunidade
                da Iputinga e além.
              </p>
              <p className="text-lg mb-6">Venha nos conhecer e fazer parte desta família. Todos são bem-vindos!</p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/sobre"
                  className="bg-blue-600 text-white py-3 px-6 rounded-md font-medium hover:bg-blue-700 transition-colors text-center"
                >
                  Conheça Nossa História
                </Link>
                <Link
                  href="/contato"
                  className="bg-gray-200 text-gray-800 py-3 px-6 rounded-md font-medium hover:bg-gray-300 transition-colors text-center"
                >
                  Entre em Contato
                </Link>
              </div>
            </div>

            <div className="rounded-lg overflow-hidden shadow-lg">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Igreja Presbiteriana Renovada da Iputinga"
                width={600}
                height={400}
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Horários e Localização */}
      <section className="py-16 px-4 bg-gray-100">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-12 text-blue-800">Horários e Localização</h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold mb-6 text-blue-700">Nossos Cultos</h3>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-blue-100 p-3 rounded-full">
                    <Calendar className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">Culto de Adoração</h4>
                    <p className="text-gray-600 flex items-center gap-1 mt-1">
                      <span>Domingo</span> • <Clock className="w-4 h-4" /> <span>18:00</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-blue-100 p-3 rounded-full">
                    <Calendar className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">Estudo Bíblico</h4>
                    <p className="text-gray-600 flex items-center gap-1 mt-1">
                      <span>Quarta-feira</span> • <Clock className="w-4 h-4" /> <span>19:30</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-blue-100 p-3 rounded-full">
                    <Calendar className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">Culto de Jovens</h4>
                    <p className="text-gray-600 flex items-center gap-1 mt-1">
                      <span>Sábado</span> • <Clock className="w-4 h-4" /> <span>19:00</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold mb-6 text-blue-700">Nossa Localização</h3>

              <div className="flex items-start gap-4 mb-6">
                <div className="bg-blue-100 p-3 rounded-full">
                  <MapPin className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Endereço</h4>
                  <p className="text-gray-600 mt-1">
                    Rua da Iputinga, 123 - Iputinga
                    <br />
                    Recife - PE, 50000-000
                  </p>
                </div>
              </div>

              <div className="rounded-lg overflow-hidden h-64 bg-gray-200">
                {/* Aqui você pode adicionar um mapa do Google Maps */}
                <div className="w-full h-full flex items-center justify-center">
                  <p className="text-gray-500">Mapa da localização</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Próximos Eventos */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-12 text-blue-800">Próximos Eventos</h2>

          <div className="grid md:grid-cols-3 gap-6">
            {events.map((event) => (
              <EventCard
                key={event.id}
                title={event.title}
                date={event.date}
                time={event.time}
                description={event.description}
              />
            ))}
          </div>

          <div className="text-center mt-10">
            <Link
              href="/eventos"
              className="inline-block bg-blue-600 text-white py-3 px-6 rounded-md font-medium hover:bg-blue-700 transition-colors"
            >
              Ver Todos os Eventos
            </Link>
          </div>
        </div>
      </section>

      {/* Sermões Recentes */}
      <section className="py-16 px-4 bg-gray-100">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-12 text-blue-800">Sermões Recentes</h2>

          <div className="grid md:grid-cols-3 gap-6">
            {sermons.map((sermon) => (
              <SermonCard
                key={sermon.id}
                title={sermon.title}
                pastor={sermon.pastor}
                date={sermon.date}
                imageUrl={sermon.imageUrl}
                videoUrl={sermon.videoUrl}
              />
            ))}
          </div>

          <div className="text-center mt-10">
            <Link
              href="/sermoes"
              className="inline-block bg-blue-600 text-white py-3 px-6 rounded-md font-medium hover:bg-blue-700 transition-colors"
            >
              Ver Todos os Sermões
            </Link>
          </div>
        </div>
      </section>

      {/* Testemunhos */}
      <section className="py-16 px-4 bg-blue-700 text-white">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-12">Testemunhos</h2>

          <div className="grid md:grid-cols-2 gap-8">
            {testimonies.map((testimony) => (
              <TestimonyCard
                key={testimony.id}
                name={testimony.name}
                testimony={testimony.testimony}
                imageUrl={testimony.imageUrl}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Chamada para Ação */}
      <section className="py-20 px-4 bg-blue-900 text-white text-center">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-4xl font-bold mb-6">Venha nos Visitar</h2>
          <p className="text-xl mb-10 max-w-2xl mx-auto">
            Estamos ansiosos para receber você e sua família em nossa comunidade. Venha experimentar o amor de Deus
            conosco!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/contato"
              className="bg-white text-blue-900 py-3 px-8 rounded-md font-bold hover:bg-gray-100 transition-colors"
            >
              Entre em Contato
            </Link>
            <Link
              href="/transmissao"
              className="bg-transparent border-2 border-white text-white py-3 px-8 rounded-md font-bold hover:bg-blue-800 transition-colors"
            >
              Assista Online
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

