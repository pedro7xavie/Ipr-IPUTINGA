"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"
import { Video, Save, LinkIcon, Calendar, Clock, AlertCircle, ToggleLeft, ToggleRight } from "lucide-react"

export default function LiveStreamPage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const [isSaving, setIsSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState("")

  // Estados para os campos do formulário
  const [isLive, setIsLive] = useState(false)
  const [streamUrl, setStreamUrl] = useState("")
  const [embedCode, setEmbedCode] = useState("")
  const [nextStreamDate, setNextStreamDate] = useState("")
  const [nextStreamTime, setNextStreamTime] = useState("")
  const [nextStreamTitle, setNextStreamTitle] = useState("")
  const [showBanner, setShowBanner] = useState(false)
  const [bannerText, setBannerText] = useState("Estamos ao vivo agora!")

  useEffect(() => {
    // Verificar se o usuário está logado
    const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"
    const authToken = localStorage.getItem("authToken")

    if (!isLoggedIn || !authToken) {
      router.push("/admin/login")
      return
    }

    // Carregar configurações salvas
    const loadStreamSettings = () => {
      const settingsJSON = localStorage.getItem("liveStreamSettings")
      if (settingsJSON) {
        try {
          const settings = JSON.parse(settingsJSON)
          setIsLive(settings.isLive || false)
          setStreamUrl(settings.streamUrl || "")
          setEmbedCode(settings.embedCode || "")
          setNextStreamDate(settings.nextStreamDate || "")
          setNextStreamTime(settings.nextStreamTime || "")
          setNextStreamTitle(settings.nextStreamTitle || "")
          setShowBanner(settings.showBanner || false)
          setBannerText(settings.bannerText || "Estamos ao vivo agora!")
        } catch (error) {
          console.error("Erro ao carregar configurações de transmissão:", error)
        }
      }
      setIsLoading(false)
    }

    loadStreamSettings()
  }, [router])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    // Criar objeto com as configurações
    const streamSettings = {
      isLive,
      streamUrl,
      embedCode,
      nextStreamDate,
      nextStreamTime,
      nextStreamTitle,
      showBanner,
      bannerText,
      updatedAt: new Date().toISOString(),
    }

    // Salvar no localStorage
    localStorage.setItem("liveStreamSettings", JSON.stringify(streamSettings))

    // Simular atraso de rede
    setTimeout(() => {
      setIsSaving(false)
      setSaveMessage("Configurações salvas com sucesso!")

      // Limpar a mensagem após 3 segundos
      setTimeout(() => {
        setSaveMessage("")
      }, 3000)
    }, 1000)
  }

  const toggleLiveStatus = () => {
    setIsLive(!isLive)
    if (!isLive) {
      setShowBanner(true) // Ativar banner automaticamente quando ativar transmissão
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <h1 className="text-2xl font-bold mb-6">Gerenciar Transmissão ao Vivo</h1>

          {saveMessage && (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
              {saveMessage}
            </div>
          )}

          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center">
                <div
                  className={`mr-3 h-4 w-4 rounded-full ${isLive ? "bg-red-500 animate-pulse" : "bg-gray-400"}`}
                ></div>
                <h2 className="text-lg font-semibold">Status da Transmissão: {isLive ? "Ao Vivo" : "Offline"}</h2>
              </div>
              <button
                type="button"
                onClick={toggleLiveStatus}
                className={`flex items-center px-4 py-2 rounded-md ${
                  isLive ? "bg-red-100 text-red-700 hover:bg-red-200" : "bg-green-100 text-green-700 hover:bg-green-200"
                } transition-colors`}
              >
                {isLive ? (
                  <>
                    <ToggleRight className="h-5 w-5 mr-2" />
                    Encerrar Transmissão
                  </>
                ) : (
                  <>
                    <ToggleLeft className="h-5 w-5 mr-2" />
                    Iniciar Transmissão
                  </>
                )}
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="mb-4">
                    <label htmlFor="streamUrl" className="block text-gray-700 font-medium mb-2">
                      URL da Transmissão
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <LinkIcon className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="streamUrl"
                        type="text"
                        value={streamUrl}
                        onChange={(e) => setStreamUrl(e.target.value)}
                        className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        placeholder="Ex: https://youtube.com/watch?v=..."
                      />
                    </div>
                    <p className="text-sm text-gray-500 mt-1">URL do YouTube, Vimeo ou outra plataforma</p>
                  </div>

                  <div className="mb-4">
                    <label htmlFor="embedCode" className="block text-gray-700 font-medium mb-2">
                      Código de Incorporação (Embed)
                    </label>
                    <textarea
                      id="embedCode"
                      value={embedCode}
                      onChange={(e) => setEmbedCode(e.target.value)}
                      rows={4}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      placeholder="<iframe src='...' width='560' height='315' frameborder='0' allowfullscreen></iframe>"
                    />
                    <p className="text-sm text-gray-500 mt-1">Código HTML fornecido pela plataforma de streaming</p>
                  </div>

                  <div className="mb-4">
                    <h3 className="text-md font-semibold mb-3">Próxima Transmissão</h3>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <label htmlFor="nextStreamDate" className="block text-gray-700 font-medium mb-2">
                          Data
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Calendar className="h-5 w-5 text-gray-400" />
                          </div>
                          <input
                            id="nextStreamDate"
                            type="date"
                            value={nextStreamDate}
                            onChange={(e) => setNextStreamDate(e.target.value)}
                            className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                          />
                        </div>
                      </div>
                      <div>
                        <label htmlFor="nextStreamTime" className="block text-gray-700 font-medium mb-2">
                          Horário
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Clock className="h-5 w-5 text-gray-400" />
                          </div>
                          <input
                            id="nextStreamTime"
                            type="time"
                            value={nextStreamTime}
                            onChange={(e) => setNextStreamTime(e.target.value)}
                            className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <label htmlFor="nextStreamTitle" className="block text-gray-700 font-medium mb-2">
                        Título
                      </label>
                      <input
                        id="nextStreamTitle"
                        type="text"
                        value={nextStreamTitle}
                        onChange={(e) => setNextStreamTitle(e.target.value)}
                        className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        placeholder="Ex: Culto de Adoração"
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <h3 className="text-md font-semibold mb-3">Banner de Notificação</h3>

                    <div className="flex items-center mb-4">
                      <input
                        id="showBanner"
                        type="checkbox"
                        checked={showBanner}
                        onChange={(e) => setShowBanner(e.target.checked)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor="showBanner" className="ml-2 block text-gray-700 font-medium">
                        Mostrar banner de "Ao Vivo" no site
                      </label>
                    </div>

                    <div className="mb-4">
                      <label htmlFor="bannerText" className="block text-gray-700 font-medium mb-2">
                        Texto do Banner
                      </label>
                      <input
                        id="bannerText"
                        type="text"
                        value={bannerText}
                        onChange={(e) => setBannerText(e.target.value)}
                        className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        placeholder="Ex: Estamos ao vivo agora!"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-semibold mb-4">Pré-visualização</h2>

                  {showBanner && (
                    <div className="bg-red-600 text-white py-3 px-4 rounded-md mb-4">
                      <div className="flex items-center justify-center">
                        <AlertCircle className="w-5 h-5 mr-2 animate-pulse" />
                        <p className="font-medium mr-4">{bannerText}</p>
                        <button className="bg-white text-red-600 px-4 py-1 rounded-md text-sm font-bold hover:bg-gray-100 transition-colors">
                          Assistir
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden mb-4">
                    <div className="aspect-video bg-gray-800 flex flex-col items-center justify-center text-white p-8 text-center">
                      {isLive ? (
                        <div className="w-full h-full flex items-center justify-center">
                          <div className="flex flex-col items-center">
                            <Video className="h-16 w-16 mb-4 text-red-500" />
                            <div className="flex items-center mb-2">
                              <div className="h-3 w-3 bg-red-500 rounded-full animate-pulse mr-2"></div>
                              <span className="font-bold">AO VIVO</span>
                            </div>
                            <p>Transmissão ao vivo em andamento</p>
                          </div>
                        </div>
                      ) : (
                        <>
                          <h2 className="text-2xl font-bold mb-4">Não estamos ao vivo no momento</h2>
                          <p className="text-gray-300 max-w-2xl">
                            {nextStreamDate && nextStreamTime ? (
                              <>
                                Nossa próxima transmissão será{" "}
                                {new Date(nextStreamDate).toLocaleDateString("pt-BR", {
                                  day: "numeric",
                                  month: "long",
                                })}{" "}
                                às {nextStreamTime}.{nextStreamTitle && <> {nextStreamTitle}</>}
                              </>
                            ) : (
                              "Configure a próxima transmissão para exibir informações aqui."
                            )}
                          </p>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-lg shadow-md p-4">
                    <h3 className="font-semibold mb-2">Instruções</h3>
                    <ul className="text-sm text-gray-600 space-y-2">
                      <li>• Para iniciar uma transmissão, ative o botão "Iniciar Transmissão" no topo.</li>
                      <li>• Adicione a URL da transmissão ou o código de incorporação fornecido pela plataforma.</li>
                      <li>
                        • O banner "Ao Vivo" será exibido automaticamente no site quando a transmissão estiver ativa.
                      </li>
                      <li>• Configure a próxima transmissão para informar os visitantes quando não estiver ao vivo.</li>
                    </ul>
                  </div>

                  <div className="mt-6">
                    <button
                      type="submit"
                      className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center"
                      disabled={isSaving}
                    >
                      {isSaving ? (
                        <>
                          <svg
                            className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                            ></circle>
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            ></path>
                          </svg>
                          Salvando...
                        </>
                      ) : (
                        <>
                          <Save className="h-5 w-5 mr-2" />
                          Salvar Configurações
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  )
}

