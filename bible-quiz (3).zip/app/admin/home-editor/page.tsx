"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"
import Link from "next/link"
import { Edit, Eye } from "lucide-react"

export default function HomeEditorPage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Verificar se o usuário está logado
    const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"

    if (!isLoggedIn) {
      router.push("/admin/login")
    } else {
      setIsLoading(false)
    }
  }, [router])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  const sections = [
    {
      id: "banner",
      title: "Banner Principal",
      description: "Edite o banner principal da página inicial, incluindo título, subtítulo e imagem de fundo.",
      href: "/admin/home-editor/banner",
    },
    {
      id: "about",
      title: "Sobre a Igreja",
      description: "Atualize a seção 'Sobre a Igreja' com texto e imagem.",
      href: "/admin/home-editor/about",
    },
    {
      id: "featured-events",
      title: "Eventos Destacados",
      description: "Selecione quais eventos serão exibidos na página inicial.",
      href: "/admin/home-editor/featured-events",
    },
    {
      id: "recent-sermons",
      title: "Sermões Recentes",
      description: "Escolha quais sermões serão exibidos na seção de sermões recentes.",
      href: "/admin/home-editor/recent-sermons",
    },
    {
      id: "testimonials",
      title: "Testemunhos",
      description: "Gerencie os testemunhos exibidos na página inicial.",
      href: "/admin/home-editor/testimonials",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Editor da Página Inicial</h1>

            <div className="flex space-x-3">
              <Link
                href="/"
                target="_blank"
                className="flex items-center text-gray-600 hover:text-gray-800 bg-white px-4 py-2 rounded-md shadow-sm border border-gray-200"
              >
                <Eye className="h-4 w-4 mr-2" />
                Visualizar Site
              </Link>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <p className="text-gray-600 mb-4">
              Selecione uma seção abaixo para editar o conteúdo da página inicial. As alterações serão refletidas
              imediatamente no site.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sections.map((section) => (
              <div key={section.id} className="bg-white rounded-lg shadow overflow-hidden">
                <div className="p-6">
                  <h2 className="text-lg font-semibold mb-2">{section.title}</h2>
                  <p className="text-gray-600 mb-4">{section.description}</p>
                  <Link href={section.href} className="inline-flex items-center text-blue-600 hover:text-blue-800">
                    <Edit className="h-4 w-4 mr-1" />
                    Editar Seção
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}

