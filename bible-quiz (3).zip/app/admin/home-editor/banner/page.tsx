"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"
import Link from "next/link"
import { ArrowLeft, Save, Upload } from "lucide-react"

export default function BannerEditorPage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Estados para os campos do formulário
  const [title, setTitle] = useState("Igreja Presbiteriana Renovada da Iputinga")
  const [subtitle, setSubtitle] = useState('"Adorando a Deus, edificando vidas e alcançando os perdidos."')
  const [backgroundImage, setBackgroundImage] = useState("/placeholder.svg?height=800&width=1600")
  const [buttonText1, setButtonText1] = useState("Conheça-nos")
  const [buttonLink1, setButtonLink1] = useState("/sobre")
  const [buttonText2, setButtonText2] = useState("Assista ao Vivo")
  const [buttonLink2, setButtonLink2] = useState("/transmissao")
  const [nextServiceTitle, setNextServiceTitle] = useState("Próximo Culto")
  const [nextServiceInfo, setNextServiceInfo] = useState("Domingo, 18:00 - Culto de Adoração")
  const [nextServiceDescription, setNextServiceDescription] = useState("Venha adorar ao Senhor conosco!")

  const [isSaving, setIsSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState("")

  useEffect(() => {
    // Verificar se o usuário está logado
    const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"

    if (!isLoggedIn) {
      router.push("/admin/login")
    } else {
      setIsLoading(false)
    }
  }, [router])

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    // Criar objeto com os dados do banner
    const bannerData = {
      title,
      subtitle,
      backgroundImage,
      buttonText1,
      buttonLink1,
      buttonText2,
      buttonLink2,
      nextServiceTitle,
      nextServiceInfo,
      nextServiceDescription,
      lastUpdated: new Date().toISOString(),
    }

    // Salvar no localStorage (em produção seria enviado para um servidor)
    try {
      localStorage.setItem("bannerData", JSON.stringify(bannerData))

      setTimeout(() => {
        setIsSaving(false)
        setSaveMessage("Banner atualizado com sucesso!")

        // Limpar a mensagem após 3 segundos
        setTimeout(() => {
          setSaveMessage("")
        }, 3000)
      }, 1000)
    } catch (error) {
      setIsSaving(false)
      setSaveMessage("Erro ao salvar as alterações. Tente novamente.")
    }
  }

  useEffect(() => {
    // Carregar dados salvos do banner
    const loadBannerData = () => {
      const savedData = localStorage.getItem("bannerData")
      if (savedData) {
        try {
          const data = JSON.parse(savedData)
          setTitle(data.title || title)
          setSubtitle(data.subtitle || subtitle)
          setBackgroundImage(data.backgroundImage || backgroundImage)
          setButtonText1(data.buttonText1 || buttonText1)
          setButtonLink1(data.buttonLink1 || buttonLink1)
          setButtonText2(data.buttonText2 || buttonText2)
          setButtonLink2(data.buttonLink2 || buttonLink2)
          setNextServiceTitle(data.nextServiceTitle || nextServiceTitle)
          setNextServiceInfo(data.nextServiceInfo || nextServiceInfo)
          setNextServiceDescription(data.nextServiceDescription || nextServiceDescription)
        } catch (error) {
          console.error("Erro ao carregar dados do banner:", error)
        }
      }
    }

    if (!isLoading) {
      loadBannerData()
    }
  }, [isLoading])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <div className="flex items-center mb-6">
            <Link href="/admin/home-editor" className="mr-4 text-gray-600 hover:text-gray-800">
              <ArrowLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-2xl font-bold">Editar Banner Principal</h1>
          </div>

          {saveMessage && (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
              {saveMessage}
            </div>
          )}

          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <form onSubmit={handleSave}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h2 className="text-lg font-semibold mb-4">Conteúdo do Banner</h2>

                  <div className="mb-4">
                    <label htmlFor="title" className="block text-gray-700 font-medium mb-2">
                      Título
                    </label>
                    <input
                      id="title"
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      required
                    />
                  </div>

                  <div className="mb-4">
                    <label htmlFor="subtitle" className="block text-gray-700 font-medium mb-2">
                      Subtítulo
                    </label>
                    <textarea
                      id="subtitle"
                      value={subtitle}
                      onChange={(e) => setSubtitle(e.target.value)}
                      rows={2}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                    />
                  </div>

                  <div className="mb-4">
                    <label htmlFor="backgroundImage" className="block text-gray-700 font-medium mb-2">
                      Imagem de Fundo
                    </label>
                    <div className="flex items-center">
                      <input
                        id="backgroundImage"
                        type="text"
                        value={backgroundImage}
                        onChange={(e) => setBackgroundImage(e.target.value)}
                        className="flex-1 border border-gray-300 rounded-l-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      />
                      <button
                        type="button"
                        className="bg-gray-200 text-gray-700 py-2 px-4 rounded-r-md hover:bg-gray-300 transition-colors"
                      >
                        <Upload className="h-5 w-5" />
                      </button>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">URL da imagem ou clique no botão para fazer upload</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor="buttonText1" className="block text-gray-700 font-medium mb-2">
                        Texto do Botão 1
                      </label>
                      <input
                        id="buttonText1"
                        type="text"
                        value={buttonText1}
                        onChange={(e) => setButtonText1(e.target.value)}
                        className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      />
                    </div>
                    <div>
                      <label htmlFor="buttonLink1" className="block text-gray-700 font-medium mb-2">
                        Link do Botão 1
                      </label>
                      <input
                        id="buttonLink1"
                        type="text"
                        value={buttonLink1}
                        onChange={(e) => setButtonLink1(e.target.value)}
                        className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor="buttonText2" className="block text-gray-700 font-medium mb-2">
                        Texto do Botão 2
                      </label>
                      <input
                        id="buttonText2"
                        type="text"
                        value={buttonText2}
                        onChange={(e) => setButtonText2(e.target.value)}
                        className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      />
                    </div>
                    <div>
                      <label htmlFor="buttonLink2" className="block text-gray-700 font-medium mb-2">
                        Link do Botão 2
                      </label>
                      <input
                        id="buttonLink2"
                        type="text"
                        value={buttonLink2}
                        onChange={(e) => setButtonLink2(e.target.value)}
                        className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      />
                    </div>
                  </div>

                  <h3 className="text-md font-semibold mb-3 mt-6">Informações do Próximo Culto</h3>

                  <div className="mb-4">
                    <label htmlFor="nextServiceTitle" className="block text-gray-700 font-medium mb-2">
                      Título
                    </label>
                    <input
                      id="nextServiceTitle"
                      type="text"
                      value={nextServiceTitle}
                      onChange={(e) => setNextServiceTitle(e.target.value)}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                    />
                  </div>

                  <div className="mb-4">
                    <label htmlFor="nextServiceInfo" className="block text-gray-700 font-medium mb-2">
                      Informações
                    </label>
                    <input
                      id="nextServiceInfo"
                      type="text"
                      value={nextServiceInfo}
                      onChange={(e) => setNextServiceInfo(e.target.value)}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                    />
                  </div>

                  <div className="mb-4">
                    <label htmlFor="nextServiceDescription" className="block text-gray-700 font-medium mb-2">
                      Descrição
                    </label>
                    <input
                      id="nextServiceDescription"
                      type="text"
                      value={nextServiceDescription}
                      onChange={(e) => setNextServiceDescription(e.target.value)}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                    />
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-semibold mb-4">Pré-visualização</h2>

                  <div className="relative bg-blue-900 text-white rounded-lg overflow-hidden">
                    <div
                      className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-blue-800/80 z-10"
                      style={{
                        backgroundImage: `url('${backgroundImage}')}`,
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                        mixBlendMode: "overlay",
                      }}
                    ></div>

                    <div className="relative z-20 p-6">
                      <div className="max-w-md">
                        <h1 className="text-xl font-bold mb-3">{title}</h1>

                        <p className="text-sm mb-4 text-blue-100">{subtitle}</p>

                        <div className="flex flex-col sm:flex-row gap-2">
                          <button className="bg-white text-blue-900 py-1 px-3 rounded-md font-bold text-sm">
                            {buttonText1}
                          </button>
                          <button className="bg-transparent border border-white text-white py-1 px-3 rounded-md font-bold text-sm">
                            {buttonText2}
                          </button>
                        </div>

                        <div className="mt-4 bg-blue-800/70 p-3 rounded-lg">
                          <h2 className="text-sm font-bold mb-1">{nextServiceTitle}</h2>
                          <p className="text-blue-100 text-xs">{nextServiceInfo}</p>
                          <p className="mt-1 text-blue-100 text-xs">{nextServiceDescription}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <p className="text-sm text-gray-500 mt-2">
                    Esta é uma pré-visualização simplificada. O resultado final pode variar ligeiramente.
                  </p>

                  <div className="mt-6">
                    <button
                      type="submit"
                      className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors flex items-center justify-center"
                      disabled={isSaving}
                    >
                      {isSaving ? (
                        <>
                          <svg
                            className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                            ></circle>
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            ></path>
                          </svg>
                          Salvando...
                        </>
                      ) : (
                        <>
                          <Save className="h-5 w-5 mr-2" />
                          Salvar Alterações
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  )
}

