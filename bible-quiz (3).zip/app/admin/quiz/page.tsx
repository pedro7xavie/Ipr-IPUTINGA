// Criar uma página básica de gerenciamento do Quiz Bíblico

\`\`\`typescript
"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"
import Link from "next/link"
import { Plus, Search, Filter, Edit, Trash, Book, BarChart } from "lucide-react"

export default function QuizAdminPage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("questions")
  const [questions, setQuestions] = useState([
    {
      id: 1,
      text: "Quem foi o primeiro rei de Israel?",
      level: "Iniciante",
      category: "Antigo Testamento",
    },
    {
      id: 2,
      text: "Quantos livros tem o Novo Testamento?",
      level: "Iniciante",
      category: "Geral",
    },
    {
      id: 3,
      text: "Quem escreveu a maior parte das epístolas no Novo Testamento?",
      level: "Intermediário",
      category: "Novo Testamento",
    },
    {
      id: 4,
      text: "Qual profeta foi engolido por um grande peixe?",
      level: "Iniciante",
      category: "Antigo Testamento",
    },
  ])

  useEffect(() => {
    // Verificar se o usuário está logado
    const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"
    const authToken = localStorage.getItem("authToken")

    if (!isLoggedIn || !authToken) {
      router.push("/admin/login")
    } else {
      setIsLoading(false)
    }
  }, [router])

  const handleDeleteQuestion = (id: number) => {
    if (confirm("Tem certeza que deseja excluir esta pergunta?")) {
      setQuestions(questions.filter((question) => question.id !== id))
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Gerenciar Quiz Bíblico</h1>

            <div className="flex space-x-2">
              <Link
                href="/admin/quiz/questions/new"
                className="bg-blue-600 text-white px-4 py-2 rounded-md flex items-center hover:bg-blue-700 transition-colors"
              >
                <Plus className="h-4 w-4 mr-2" />
                Nova Pergunta
              </Link>
            </div>
          </div>

          {/* Tabs */}
          <div className="bg-white rounded-lg shadow mb-6">
            <div className="border-b border-gray-200">
              <nav className="flex -mb-px">
                <button
                  onClick={() => setActiveTab("questions")}
                  className={`py-4 px-6 text-center border-b-2 font-medium text-sm ${
                    activeTab === "questions"
                      ? "border-blue-500 text-blue-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  <Book className="h-5 w-5 inline-block mr-1" />
                  Perguntas
                </button>
                <button
                  onClick={() => setActiveTab("statistics")}
                  className={`py-4 px-6 text-center border-b-2 font-medium text-sm ${
                    activeTab === "statistics"
                      ? "border-blue-500 text-blue-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  <BarChart className="h-5 w-5 inline-block mr-1" />
                  Estatísticas
                </button>
              </nav>
            </div>
          </div>

          {/* Conteúdo da Tab */}
          {activeTab === "questions" && (
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div className="flex items-center">
                  <Filter className="h-5 w-5 text-gray-500 mr-2" />
                  <span className="text-gray-700 font-medium mr-3">Filtrar por:</span>
                  <select className="border border-gray-300 rounded-md py-1 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium">
                    <option value="all">Todos os níveis</option>
                    <option value="iniciante">Iniciante</option>
                    <option value="intermediario">Intermediário</option>
                    <option value="avancado">Avançado</option>
                    <option value="especialista">Especialista</option>
                  </select>
                </div>

                <div className="relative w-full md:w-64">
                  <input
                    type="text"
                    placeholder="Buscar perguntas..."
                    className="w-full border border-gray-300 rounded-md py-2 pl-10 pr-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Pergunta
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Nível
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Categoria
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Ações
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {questions.map((question) => (
                      <tr key={question.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="text-sm font-medium text-gray-900">{question.text}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              question.level === "Iniciante"
                                ? "bg-green-100 text-green-800"
                                : question.level === "Intermediário"
                                  ? "bg-blue-100 text-blue-800"
                                  : "bg-purple-100 text-purple-800"
                            }`}
                          >
                            {question.level}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{question.category}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex justify-end space-x-2">
                            <Link
                              href={`/admin/quiz/questions/edit/${question.id}`}
                              className="text-blue-600 hover:text-blue-900"
                            >
                              <Edit className="h-5 w-5" />
                            </Link>
                            <button
                              onClick={() => handleDeleteQuestion(question.id)}
                              className="text-red-600 hover:text-red-900"
                            >
                              <Trash className="h-5 w-5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "statistics" && (
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-lg font-semibold mb-4">Estatísticas do Quiz</h2>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-blue-50 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-blue-700 mb-2">Total de Perguntas</h3>
                  <p className="text-3xl font-bold text-blue-800">230</p>
                </div>
                <div className="bg-green-50 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-green-700 mb-2">Jogadores Ativos</h3>
                  <p className="text-3xl font-bold text-green-800">156</p>
                </div>
                <div className="bg-purple-50 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-purple-700 mb-2">Jogos Realizados</h3>
                  <p className="text-3xl font-bold text-purple-800">1,248</p>
                </div>
              </div>

              <p className="text-gray-600 mb-4">
                Aqui você pode visualizar estatísticas detalhadas sobre o uso do Quiz Bíblico. Em uma implementação
                completa, seriam exibidos gráficos e dados mais detalhados.
              </p>

              <div className="text-center py-8">
                <p className="text-gray-500">Gráficos e estatísticas detalhadas serão implementados em breve.</p>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
\`\`\`

