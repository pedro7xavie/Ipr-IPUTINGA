"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"
import Link from "next/link"
import { ArrowLeft, Save, HelpCircle, BookOpen } from "lucide-react"

export default function NewQuestionPage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const [isSaving, setIsSaving] = useState(false)

  // Estados para os campos do formulário
  const [questionText, setQuestionText] = useState("")
  const [options, setOptions] = useState(["", "", "", ""])
  const [correctAnswer, setCorrectAnswer] = useState<number | null>(null)
  const [explanation, setExplanation] = useState("")
  const [level, setLevel] = useState("")
  const [category, setCategory] = useState("")

  // Níveis e categorias disponíveis
  const levels = ["Iniciante", "Intermediário", "Avançado", "Especialista", "Mestre Bíblico"]
  const categories = [
    "Antigo Testamento",
    "Novo Testamento",
    "Evangelhos",
    "Epístolas",
    "Profetas",
    "História Bíblica",
    "Personagens Bíblicos",
    "Doutrinas",
    "Geral",
  ]

  useEffect(() => {
    // Verificar se o usuário está logado
    const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"
    const authToken = localStorage.getItem("authToken")

    if (!isLoggedIn || !authToken) {
      router.push("/admin/login")
    } else {
      setIsLoading(false)
    }
  }, [router])

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...options]
    newOptions[index] = value
    setOptions(newOptions)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (correctAnswer === null) {
      alert("Por favor, selecione a resposta correta.")
      return
    }

    setIsSaving(true)

    // Criar objeto com os dados da pergunta
    const questionData = {
      id: Date.now(), // Usar timestamp como ID temporário
      text: questionText,
      options,
      correctAnswer,
      explanation,
      level,
      category,
      createdAt: new Date().toISOString(),
    }

    // Recuperar perguntas existentes do localStorage
    const existingQuestionsJSON = localStorage.getItem("quizQuestions")
    const existingQuestions = existingQuestionsJSON ? JSON.parse(existingQuestionsJSON) : []

    // Adicionar nova pergunta
    const updatedQuestions = [...existingQuestions, questionData]

    // Salvar no localStorage
    localStorage.setItem("quizQuestions", JSON.stringify(updatedQuestions))

    // Simular atraso de rede
    setTimeout(() => {
      setIsSaving(false)
      router.push("/admin/quiz")
    }, 1000)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <div className="flex items-center mb-6">
            <Link href="/admin/quiz" className="mr-4 text-gray-600 hover:text-gray-800">
              <ArrowLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-2xl font-bold">Adicionar Nova Pergunta</h1>
          </div>

          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h2 className="text-lg font-semibold mb-4">Informações da Pergunta</h2>

                  <div className="mb-4">
                    <label htmlFor="questionText" className="block text-gray-700 font-medium mb-2">
                      Pergunta*
                    </label>
                    <textarea
                      id="questionText"
                      value={questionText}
                      onChange={(e) => setQuestionText(e.target.value)}
                      rows={2}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      placeholder="Digite a pergunta..."
                      required
                    />
                  </div>

                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium mb-2">Opções de Resposta*</label>
                    {options.map((option, index) => (
                      <div key={index} className="flex items-center mb-2">
                        <input
                          type="radio"
                          id={`correctAnswer-${index}`}
                          name="correctAnswer"
                          checked={correctAnswer === index}
                          onChange={() => setCorrectAnswer(index)}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                          required
                        />
                        <input
                          type="text"
                          value={option}
                          onChange={(e) => handleOptionChange(index, e.target.value)}
                          className="ml-2 flex-1 border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                          placeholder={`Opção ${index + 1}`}
                          required
                        />
                      </div>
                    ))}
                    <p className="text-sm text-gray-500 mt-1">Selecione a opção correta</p>
                  </div>

                  <div className="mb-4">
                    <label htmlFor="explanation" className="block text-gray-700 font-medium mb-2">
                      Explicação
                    </label>
                    <textarea
                      id="explanation"
                      value={explanation}
                      onChange={(e) => setExplanation(e.target.value)}
                      rows={3}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      placeholder="Explique por que esta é a resposta correta..."
                    />
                    <p className="text-sm text-gray-500 mt-1">Será mostrada após o usuário responder</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor="level" className="block text-gray-700 font-medium mb-2">
                        Nível de Dificuldade*
                      </label>
                      <select
                        id="level"
                        value={level}
                        onChange={(e) => setLevel(e.target.value)}
                        className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        required
                      >
                        <option value="">Selecione um nível</option>
                        {levels.map((lvl, index) => (
                          <option key={index} value={lvl}>
                            {lvl}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label htmlFor="category" className="block text-gray-700 font-medium mb-2">
                        Categoria*
                      </label>
                      <select
                        id="category"
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        required
                      >
                        <option value="">Selecione uma categoria</option>
                        {categories.map((cat, index) => (
                          <option key={index} value={cat}>
                            {cat}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-semibold mb-4">Pré-visualização</h2>

                  <div className="bg-white border border-gray-200 rounded-lg shadow-md p-6">
                    <div className="mb-6">
                      <h3 className="text-xl font-bold mb-4">{questionText || "Pergunta do Quiz"}</h3>

                      <div className="space-y-3 mb-6">
                        {options.map((option, index) => (
                          <div
                            key={index}
                            className={`p-4 rounded-lg border transition-all ${
                              correctAnswer === index
                                ? "border-blue-500 bg-blue-50 text-blue-700"
                                : "border-gray-200 hover:border-blue-300 hover:bg-blue-50"
                            }`}
                          >
                            <div className="flex items-center">
                              <div
                                className={`flex-shrink-0 h-5 w-5 mr-2 rounded-full border ${
                                  correctAnswer === index ? "border-blue-500 bg-blue-500" : "border-gray-300"
                                }`}
                              >
                                {correctAnswer === index && (
                                  <div className="h-full w-full flex items-center justify-center">
                                    <div className="h-2 w-2 bg-white rounded-full"></div>
                                  </div>
                                )}
                              </div>
                              <span>{option || `Opção ${index + 1}`}</span>
                            </div>
                          </div>
                        ))}
                      </div>

                      {explanation && (
                        <div className="mt-4 bg-blue-50 p-4 rounded-md">
                          <div className="flex items-start">
                            <HelpCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5" />
                            <div>
                              <p className="font-medium text-blue-700 mb-1">Explicação:</p>
                              <p className="text-blue-800">{explanation}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="flex justify-between items-center text-sm text-gray-500 border-t pt-4">
                      <div className="flex items-center">
                        <BookOpen className="h-4 w-4 mr-1" />
                        <span>{category || "Categoria"}</span>
                      </div>
                      <div>
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            level === "Iniciante"
                              ? "bg-green-100 text-green-800"
                              : level === "Intermediário"
                                ? "bg-blue-100 text-blue-800"
                                : level === "Avançado"
                                  ? "bg-purple-100 text-purple-800"
                                  : level === "Especialista"
                                    ? "bg-orange-100 text-orange-800"
                                    : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {level || "Nível"}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 flex justify-end space-x-3">
                    <Link
                      href="/admin/quiz"
                      className="bg-gray-200 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-300 transition-colors"
                    >
                      Cancelar
                    </Link>
                    <button
                      type="submit"
                      className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors flex items-center"
                      disabled={isSaving}
                    >
                      {isSaving ? (
                        <>
                          <svg
                            className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                            ></circle>
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            ></path>
                          </svg>
                          Salvando...
                        </>
                      ) : (
                        <>
                          <Save className="h-5 w-5 mr-2" />
                          Salvar Pergunta
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  )
}

