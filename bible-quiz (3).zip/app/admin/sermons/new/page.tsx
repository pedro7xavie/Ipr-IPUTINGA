"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"
import Link from "next/link"
import { ArrowLeft, Calendar, User, Tag, Video, Save, Upload } from "lucide-react"

export default function NewSermonPage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const [isSaving, setIsSaving] = useState(false)

  // Estados para os campos do formulário
  const [title, setTitle] = useState("")
  const [pastor, setPastor] = useState("")
  const [date, setDate] = useState("")
  const [category, setCategory] = useState("")
  const [description, setDescription] = useState("")
  const [videoUrl, setVideoUrl] = useState("")
  const [imageUrl, setImageUrl] = useState("/placeholder.svg?height=200&width=300")

  // Categorias disponíveis
  const categories = [
    "Vida Cristã",
    "Fé",
    "Doutrina",
    "Família",
    "Espírito Santo",
    "Evangelismo",
    "Missões",
    "Discipulado",
    "Adoração",
    "Profecia",
    "Estudo Bíblico",
  ]

  useEffect(() => {
    // Verificar se o usuário está logado
    const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"
    const authToken = localStorage.getItem("authToken")

    if (!isLoggedIn || !authToken) {
      router.push("/admin/login")
    } else {
      setIsLoading(false)
    }
  }, [router])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    // Criar objeto com os dados do sermão
    const sermonData = {
      id: Date.now(), // Usar timestamp como ID temporário
      title,
      pastor,
      date,
      category,
      description,
      videoUrl,
      imageUrl,
      createdAt: new Date().toISOString(),
    }

    // Recuperar sermões existentes do localStorage
    const existingSermonsJSON = localStorage.getItem("sermons")
    const existingSermons = existingSermonsJSON ? JSON.parse(existingSermonsJSON) : []

    // Adicionar novo sermão
    const updatedSermons = [...existingSermons, sermonData]

    // Salvar no localStorage
    localStorage.setItem("sermons", JSON.stringify(updatedSermons))

    // Simular atraso de rede
    setTimeout(() => {
      setIsSaving(false)
      router.push("/admin/sermons")
    }, 1000)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <div className="flex items-center mb-6">
            <Link href="/admin/sermons" className="mr-4 text-gray-600 hover:text-gray-800">
              <ArrowLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-2xl font-bold">Adicionar Novo Sermão</h1>
          </div>

          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h2 className="text-lg font-semibold mb-4">Informações do Sermão</h2>

                  <div className="mb-4">
                    <label htmlFor="title" className="block text-gray-700 font-medium mb-2">
                      Título*
                    </label>
                    <input
                      id="title"
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      required
                    />
                  </div>

                  <div className="mb-4">
                    <label htmlFor="pastor" className="block text-gray-700 font-medium mb-2">
                      Pregador*
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="pastor"
                        type="text"
                        value={pastor}
                        onChange={(e) => setPastor(e.target.value)}
                        className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        placeholder="Ex: Pr. João Silva"
                        required
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <label htmlFor="date" className="block text-gray-700 font-medium mb-2">
                      Data*
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="date"
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        required
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <label htmlFor="category" className="block text-gray-700 font-medium mb-2">
                      Categoria*
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Tag className="h-5 w-5 text-gray-400" />
                      </div>
                      <select
                        id="category"
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        required
                      >
                        <option value="">Selecione uma categoria</option>
                        {categories.map((cat, index) => (
                          <option key={index} value={cat}>
                            {cat}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="mb-4">
                    <label htmlFor="description" className="block text-gray-700 font-medium mb-2">
                      Descrição*
                    </label>
                    <textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={4}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      placeholder="Descreva o sermão..."
                      required
                    />
                  </div>

                  <div className="mb-4">
                    <label htmlFor="videoUrl" className="block text-gray-700 font-medium mb-2">
                      URL do Vídeo
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Video className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="videoUrl"
                        type="text"
                        value={videoUrl}
                        onChange={(e) => setVideoUrl(e.target.value)}
                        className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        placeholder="Ex: https://youtube.com/watch?v=..."
                      />
                    </div>
                    <p className="text-sm text-gray-500 mt-1">URL do YouTube, Vimeo ou outra plataforma</p>
                  </div>

                  <div className="mb-4">
                    <label htmlFor="imageUrl" className="block text-gray-700 font-medium mb-2">
                      Imagem de Capa
                    </label>
                    <div className="flex items-center">
                      <input
                        id="imageUrl"
                        type="text"
                        value={imageUrl}
                        onChange={(e) => setImageUrl(e.target.value)}
                        className="flex-1 border border-gray-300 rounded-l-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      />
                      <button
                        type="button"
                        className="bg-gray-200 text-gray-700 py-2 px-4 rounded-r-md hover:bg-gray-300 transition-colors"
                      >
                        <Upload className="h-5 w-5" />
                      </button>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">URL da imagem ou clique no botão para fazer upload</p>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-semibold mb-4">Pré-visualização</h2>

                  <div className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden">
                    <div className="h-48 bg-gray-200 relative">
                      <div className="absolute inset-0 flex items-center justify-center text-gray-500">
                        Imagem de capa do sermão
                      </div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="bg-blue-600/80 rounded-full p-3">
                          <Video className="w-8 h-8 text-white" />
                        </div>
                      </div>
                    </div>
                    <div className="p-5">
                      <div className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-bold rounded inline-block mb-2">
                        {category || "Categoria"}
                      </div>
                      <h3 className="text-lg font-bold text-blue-800 mb-2">{title || "Título do Sermão"}</h3>

                      <div className="flex items-center text-gray-600 mb-1">
                        <User className="h-4 w-4 mr-2" />
                        <span>{pastor || "Pregador"}</span>
                      </div>

                      <div className="flex items-center text-gray-600 mb-3">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span>{date ? new Date(date).toLocaleDateString("pt-BR") : "Data"}</span>
                      </div>

                      <p className="text-gray-600 mb-4 line-clamp-2">{description || "Descrição do sermão..."}</p>
                    </div>
                  </div>

                  <div className="mt-6 flex justify-end space-x-3">
                    <Link
                      href="/admin/sermons"
                      className="bg-gray-200 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-300 transition-colors"
                    >
                      Cancelar
                    </Link>
                    <button
                      type="submit"
                      className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors flex items-center"
                      disabled={isSaving}
                    >
                      {isSaving ? (
                        <>
                          <svg
                            className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                            ></circle>
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            ></path>
                          </svg>
                          Salvando...
                        </>
                      ) : (
                        <>
                          <Save className="h-5 w-5 mr-2" />
                          Salvar Sermão
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  )
}

