"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"

export default function AdminDashboardPage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Verificar se o usuário está logado
    const checkAuth = () => {
      const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"
      const authToken = localStorage.getItem("authToken")

      if (!isLoggedIn || !authToken) {
        router.push("/admin/login")
      } else {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [router])

  const handleEditItem = (type, id) => {
    switch (type) {
      case "event":
        router.push(`/admin/events/edit/${id}`)
        break
      case "sermon":
        router.push(`/admin/sermons/edit/${id}`)
        break
      case "player":
        router.push(`/admin/quiz/players/${id}`)
        break
      default:
        console.log(`Editar ${type} ${id}`)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <h1 className="text-2xl font-bold mb-6">Painel Administrativo</h1>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-2">Eventos</h2>
              <p className="text-3xl font-bold text-blue-600">12</p>
              <p className="text-gray-500 text-sm">Total de eventos cadastrados</p>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-2">Sermões</h2>
              <p className="text-3xl font-bold text-blue-600">48</p>
              <p className="text-gray-500 text-sm">Total de sermões publicados</p>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-2">Usuários</h2>
              <p className="text-3xl font-bold text-blue-600">156</p>
              <p className="text-gray-500 text-sm">Usuários do Quiz Bíblico</p>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-2">Perguntas</h2>
              <p className="text-3xl font-bold text-blue-600">230</p>
              <p className="text-gray-500 text-sm">Perguntas no Quiz Bíblico</p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <h2 className="text-lg font-semibold mb-4">Atividade Recente</h2>

            <div className="space-y-4">
              {[
                { action: "Novo sermão adicionado", user: "Admin", time: "Hoje, 14:30" },
                { action: "Evento atualizado", user: "Admin", time: "Hoje, 11:15" },
                { action: "Nova pergunta adicionada ao Quiz", user: "Admin", time: "Ontem, 16:45" },
                { action: "Banner da página inicial atualizado", user: "Admin", time: "Ontem, 10:20" },
                { action: "Novo testemunho publicado", user: "Admin", time: "23/02/2024, 09:30" },
              ].map((item, index) => (
                <div key={index} className="flex justify-between items-center border-b border-gray-100 pb-3">
                  <div>
                    <p className="font-medium">{item.action}</p>
                    <p className="text-sm text-gray-500">Por: {item.user}</p>
                  </div>
                  <span className="text-sm text-gray-500">{item.time}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-4">Próximos Eventos</h2>

              <div className="space-y-4">
                {[
                  { title: "Culto de Adoração", date: "Domingo, 10/03/2024", time: "18:00" },
                  { title: "Estudo Bíblico", date: "Quarta-feira, 13/03/2024", time: "19:30" },
                  { title: "Culto de Jovens", date: "Sábado, 16/03/2024", time: "19:00" },
                ].map((event, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">{event.title}</p>
                      <p className="text-sm text-gray-500">
                        {event.date} às {event.time}
                      </p>
                    </div>
                    <button
                      onClick={() => handleEditItem("event", index + 1)}
                      className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                    >
                      Editar
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-4">Top Jogadores do Quiz</h2>

              <div className="space-y-3">
                {[
                  { name: "João Silva", score: 950, level: "Avançado" },
                  { name: "Maria Santos", score: 920, level: "Avançado" },
                  { name: "Pedro Oliveira", score: 880, level: "Intermediário" },
                  { name: "Ana Costa", score: 850, level: "Avançado" },
                  { name: "Lucas Ferreira", score: 820, level: "Intermediário" },
                ].map((player, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <div className="flex items-center">
                      <span
                        className={`inline-flex items-center justify-center w-6 h-6 rounded-full ${
                          index === 0
                            ? "bg-yellow-100 text-yellow-800"
                            : index === 1
                              ? "bg-gray-100 text-gray-800"
                              : index === 2
                                ? "bg-orange-100 text-orange-800"
                                : "bg-blue-50 text-blue-800"
                        } font-bold text-sm mr-3`}
                      >
                        {index + 1}
                      </span>
                      <div>
                        <p className="font-medium">{player.name}</p>
                        <p className="text-sm text-gray-500">{player.level}</p>
                      </div>
                    </div>
                    <span className="font-bold text-blue-600">{player.score}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}

