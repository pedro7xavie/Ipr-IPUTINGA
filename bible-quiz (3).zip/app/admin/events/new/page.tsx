"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"
import Link from "next/link"
import { ArrowLeft, Calendar, Clock, MapPin, Save } from "lucide-react"

export default function NewEventPage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const [isSaving, setIsSaving] = useState(false)

  // Estados para os campos do formulário
  const [title, setTitle] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [location, setLocation] = useState("")
  const [description, setDescription] = useState("")
  const [featured, setFeatured] = useState(false)
  const [imageUrl, setImageUrl] = useState("/placeholder.svg?height=300&width=500")

  useEffect(() => {
    // Verificar se o usuário está logado
    const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"
    const authToken = localStorage.getItem("authToken")

    if (!isLoggedIn || !authToken) {
      router.push("/admin/login")
    } else {
      setIsLoading(false)
    }
  }, [router])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    // Criar objeto com os dados do evento
    const eventData = {
      id: Date.now(), // Usar timestamp como ID temporário
      title,
      date,
      time,
      location,
      description,
      featured,
      imageUrl,
      createdAt: new Date().toISOString(),
    }

    // Recuperar eventos existentes do localStorage
    const existingEventsJSON = localStorage.getItem("events")
    const existingEvents = existingEventsJSON ? JSON.parse(existingEventsJSON) : []

    // Adicionar novo evento
    const updatedEvents = [...existingEvents, eventData]

    // Salvar no localStorage
    localStorage.setItem("events", JSON.stringify(updatedEvents))

    // Simular atraso de rede
    setTimeout(() => {
      setIsSaving(false)
      router.push("/admin/events")
    }, 1000)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <div className="flex items-center mb-6">
            <Link href="/admin/events" className="mr-4 text-gray-600 hover:text-gray-800">
              <ArrowLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-2xl font-bold">Adicionar Novo Evento</h1>
          </div>

          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h2 className="text-lg font-semibold mb-4">Informações do Evento</h2>

                  <div className="mb-4">
                    <label htmlFor="title" className="block text-gray-700 font-medium mb-2">
                      Título do Evento*
                    </label>
                    <input
                      id="title"
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor="date" className="block text-gray-700 font-medium mb-2">
                        Data*
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Calendar className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          id="date"
                          type="date"
                          value={date}
                          onChange={(e) => setDate(e.target.value)}
                          className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <label htmlFor="time" className="block text-gray-700 font-medium mb-2">
                        Horário*
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Clock className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          id="time"
                          type="time"
                          value={time}
                          onChange={(e) => setTime(e.target.value)}
                          className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <label htmlFor="location" className="block text-gray-700 font-medium mb-2">
                      Local*
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <MapPin className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="location"
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        placeholder="Ex: Templo Principal"
                        required
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <label htmlFor="description" className="block text-gray-700 font-medium mb-2">
                      Descrição*
                    </label>
                    <textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={4}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      placeholder="Descreva o evento..."
                      required
                    />
                  </div>

                  <div className="mb-4">
                    <label htmlFor="imageUrl" className="block text-gray-700 font-medium mb-2">
                      URL da Imagem
                    </label>
                    <input
                      id="imageUrl"
                      type="text"
                      value={imageUrl}
                      onChange={(e) => setImageUrl(e.target.value)}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      placeholder="URL da imagem do evento"
                    />
                    <p className="text-sm text-gray-500 mt-1">Deixe em branco para usar a imagem padrão</p>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center">
                      <input
                        id="featured"
                        type="checkbox"
                        checked={featured}
                        onChange={(e) => setFeatured(e.target.checked)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor="featured" className="ml-2 block text-gray-700 font-medium">
                        Destacar na página inicial
                      </label>
                    </div>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-semibold mb-4">Pré-visualização</h2>

                  <div className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden">
                    <div className="h-48 bg-gray-200 relative">
                      <div className="absolute inset-0 flex items-center justify-center text-gray-500">
                        Imagem do evento
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold text-blue-800 mb-2">{title || "Título do Evento"}</h3>

                      <div className="flex items-center text-gray-600 mb-1">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span>
                          {date
                            ? new Date(date).toLocaleDateString("pt-BR", {
                                day: "numeric",
                                month: "long",
                                year: "numeric",
                              })
                            : "Data do evento"}
                        </span>
                      </div>

                      <div className="flex items-center text-gray-600 mb-1">
                        <Clock className="h-4 w-4 mr-2" />
                        <span>{time || "Horário"}</span>
                      </div>

                      <div className="flex items-center text-gray-600 mb-3">
                        <MapPin className="h-4 w-4 mr-2" />
                        <span>{location || "Local do evento"}</span>
                      </div>

                      <p className="text-gray-700 mb-4">{description || "Descrição do evento..."}</p>

                      {featured && (
                        <div className="mt-2">
                          <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                            Em destaque
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="mt-6 flex justify-end space-x-3">
                    <Link
                      href="/admin/events"
                      className="bg-gray-200 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-300 transition-colors"
                    >
                      Cancelar
                    </Link>
                    <button
                      type="submit"
                      className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors flex items-center"
                      disabled={isSaving}
                    >
                      {isSaving ? (
                        <>
                          <svg
                            className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                            ></circle>
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            ></path>
                          </svg>
                          Salvando...
                        </>
                      ) : (
                        <>
                          <Save className="h-5 w-5 mr-2" />
                          Salvar Evento
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  )
}

