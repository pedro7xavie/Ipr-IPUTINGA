"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"
import Link from "next/link"
import Image from "next/image"
import { Plus, Search, Edit, Trash, Eye, EyeOff } from "lucide-react"

export default function TestimonialsPage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const [testimonials, setTestimonials] = useState([
    {
      id: 1,
      name: "Maria Santos",
      testimony:
        "Deus transformou minha vida através do ministério desta igreja. Sou muito grata por fazer parte desta família.",
      imageUrl: "/placeholder.svg?height=100&width=100",
      active: true,
      featured: true,
    },
    {
      id: 2,
      name: "Pedro Oliveira",
      testimony: "Encontrei acolhimento e direção espiritual nesta comunidade. Minha família tem sido abençoada.",
      imageUrl: "/placeholder.svg?height=100&width=100",
      active: true,
      featured: false,
    },
    {
      id: 3,
      name: "Ana Costa",
      testimony:
        "Minha vida mudou completamente desde que comecei a frequentar esta igreja. O ensino da Palavra tem me fortalecido diariamente.",
      imageUrl: "/placeholder.svg?height=100&width=100",
      active: false,
      featured: false,
    },
  ])

  useEffect(() => {
    // Verificar se o usuário está logado
    const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"
    const authToken = localStorage.getItem("authToken")

    if (!isLoggedIn || !authToken) {
      router.push("/admin/login")
    } else {
      // Carregar testemunhos do localStorage se existirem
      const savedTestimonials = localStorage.getItem("testimonials")
      if (savedTestimonials) {
        try {
          setTestimonials(JSON.parse(savedTestimonials))
        } catch (error) {
          console.error("Erro ao carregar testemunhos:", error)
        }
      }
      setIsLoading(false)
    }
  }, [router])

  const handleDeleteTestimony = (id: number) => {
    if (confirm("Tem certeza que deseja excluir este testemunho?")) {
      const updatedTestimonials = testimonials.filter((testimony) => testimony.id !== id)
      setTestimonials(updatedTestimonials)
      localStorage.setItem("testimonials", JSON.stringify(updatedTestimonials))
    }
  }

  const toggleTestimonyStatus = (id: number) => {
    const updatedTestimonials = testimonials.map((testimony) =>
      testimony.id === id ? { ...testimony, active: !testimony.active } : testimony,
    )
    setTestimonials(updatedTestimonials)
    localStorage.setItem("testimonials", JSON.stringify(updatedTestimonials))
  }

  const toggleFeatured = (id: number) => {
    const updatedTestimonials = testimonials.map((testimony) =>
      testimony.id === id ? { ...testimony, featured: !testimony.featured } : testimony,
    )
    setTestimonials(updatedTestimonials)
    localStorage.setItem("testimonials", JSON.stringify(updatedTestimonials))
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Gerenciar Testemunhos</h1>

            <Link
              href="/admin/testimonials/new"
              className="bg-blue-600 text-white px-4 py-2 rounded-md flex items-center hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              Novo Testemunho
            </Link>
          </div>

          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <div className="flex justify-between items-center mb-6">
              <div className="text-sm text-gray-500">
                {testimonials.length} testemunhos • {testimonials.filter((t) => t.active).length} ativos
              </div>

              <div className="relative w-64">
                <input
                  type="text"
                  placeholder="Buscar testemunhos..."
                  className="w-full border border-gray-300 rounded-md py-2 pl-10 pr-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Pessoa
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Testemunho
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Status
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Destaque
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Ações
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {testimonials.map((testimony) => (
                    <tr key={testimony.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 relative">
                            <Image
                              src={testimony.imageUrl || "/placeholder.svg"}
                              alt={testimony.name}
                              fill
                              className="rounded-full object-cover"
                            />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{testimony.name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900 max-w-md truncate">{testimony.testimony}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <button
                          onClick={() => toggleTestimonyStatus(testimony.id)}
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            testimony.active
                              ? "bg-green-100 text-green-800 hover:bg-green-200"
                              : "bg-gray-100 text-gray-800 hover:bg-gray-200"
                          }`}
                        >
                          {testimony.active ? (
                            <>
                              <Eye className="h-3 w-3 mr-1" />
                              Ativo
                            </>
                          ) : (
                            <>
                              <EyeOff className="h-3 w-3 mr-1" />
                              Inativo
                            </>
                          )}
                        </button>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <button
                          onClick={() => toggleFeatured(testimony.id)}
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            testimony.featured
                              ? "bg-blue-100 text-blue-800 hover:bg-blue-200"
                              : "bg-gray-100 text-gray-800 hover:bg-gray-200"
                          }`}
                        >
                          {testimony.featured ? "Destacado" : "Normal"}
                        </button>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          <Link
                            href={`/admin/testimonials/edit/${testimony.id}`}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            <Edit className="h-5 w-5" />
                          </Link>
                          <button
                            onClick={() => handleDeleteTestimony(testimony.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash className="h-5 w-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {testimonials.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">Nenhum testemunho encontrado</p>
                <Link
                  href="/admin/testimonials/new"
                  className="bg-blue-600 text-white px-4 py-2 rounded-md inline-flex items-center hover:bg-blue-700 transition-colors"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Testemunho
                </Link>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  )
}

