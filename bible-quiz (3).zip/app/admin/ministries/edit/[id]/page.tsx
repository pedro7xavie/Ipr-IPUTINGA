"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"
import Link from "next/link"
import Image from "next/image"
import {
  ArrowLeft,
  Save,
  Upload,
  User,
  Calendar,
  Users,
  Music,
  BookOpen,
  Heart,
  Baby,
  Home,
  Globe,
  Trash,
} from "lucide-react"

interface MinistryEditParams {
  params: {
    id: string
  }
}

export default function EditMinistryPage({ params }: MinistryEditParams) {
  const ministryId = Number.parseInt(params.id)
  const [isLoading, setIsLoading] = useState(true)
  const [ministryNotFound, setMinistryNotFound] = useState(false)
  const router = useRouter()
  const [isSaving, setIsSaving] = useState(false)

  // Estados para os campos do formulário
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [leader, setLeader] = useState("")
  const [members, setMembers] = useState<number>(0)
  const [foundedYear, setFoundedYear] = useState<number>(new Date().getFullYear())
  const [icon, setIcon] = useState("Music")
  const [imageUrl, setImageUrl] = useState("/placeholder.svg?height=300&width=400")
  const [active, setActive] = useState(true)

  // Opções de ícones
  const iconOptions = [
    { value: "Music", label: "Louvor", icon: <Music className="h-5 w-5" /> },
    { value: "Users", label: "Jovens", icon: <Users className="h-5 w-5" /> },
    { value: "Baby", label: "Crianças", icon: <Baby className="h-5 w-5" /> },
    { value: "Home", label: "Família", icon: <Home className="h-5 w-5" /> },
    { value: "Globe", label: "Missões", icon: <Globe className="h-5 w-5" /> },
    { value: "BookOpen", label: "Ensino", icon: <BookOpen className="h-5 w-5" /> },
    { value: "Heart", label: "Ação Social", icon: <Heart className="h-5 w-5" /> },
  ]

  // Obter o componente de ícone atual
  const getIconComponent = () => {
    const found = iconOptions.find((opt) => opt.value === icon)
    return found ? found.icon : <Music className="h-5 w-5" />
  }

  useEffect(() => {
    // Verificar se o usuário está logado
    const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"
    const authToken = localStorage.getItem("authToken")

    if (!isLoggedIn || !authToken) {
      router.push("/admin/login")
      return
    }

    // Carregar dados do ministério
    const loadMinistryData = () => {
      const ministriesJSON = localStorage.getItem("ministries")
      if (ministriesJSON) {
        const ministries = JSON.parse(ministriesJSON)
        const ministry = ministries.find((m: any) => m.id === ministryId)

        if (ministry) {
          setName(ministry.name || "")
          setDescription(ministry.description || "")
          setLeader(ministry.leader || "")
          setMembers(ministry.members || 0)
          setFoundedYear(ministry.foundedYear || new Date().getFullYear())
          setIcon(ministry.icon || "Music")
          setImageUrl(ministry.imageUrl || "/placeholder.svg?height=300&width=400")
          setActive(ministry.active !== undefined ? ministry.active : true)
        } else {
          setMinistryNotFound(true)
        }
      }
      setIsLoading(false)
    }

    loadMinistryData()
  }, [ministryId, router])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    // Criar objeto com os dados atualizados do ministério
    const updatedMinistryData = {
      id: ministryId,
      name,
      description,
      leader,
      members,
      foundedYear,
      icon,
      imageUrl,
      active,
      updatedAt: new Date().toISOString(),
    }

    // Recuperar ministérios existentes do localStorage
    const ministriesJSON = localStorage.getItem("ministries")
    let ministries = ministriesJSON ? JSON.parse(ministriesJSON) : []

    // Atualizar o ministério específico
    ministries = ministries.map((ministry: any) =>
      ministry.id === ministryId ? { ...ministry, ...updatedMinistryData } : ministry,
    )

    // Salvar no localStorage
    localStorage.setItem("ministries", JSON.stringify(ministries))

    // Simular atraso de rede
    setTimeout(() => {
      setIsSaving(false)
      router.push("/admin/ministries")
    }, 1000)
  }

  const handleDelete = () => {
    if (confirm("Tem certeza que deseja excluir este ministério? Esta ação não pode ser desfeita.")) {
      // Recuperar ministérios existentes do localStorage
      const ministriesJSON = localStorage.getItem("ministries")
      if (ministriesJSON) {
        let ministries = JSON.parse(ministriesJSON)

        // Filtrar o ministério a ser excluído
        ministries = ministries.filter((ministry: any) => ministry.id !== ministryId)

        // Salvar no localStorage
        localStorage.setItem("ministries", JSON.stringify(ministries))
      }

      router.push("/admin/ministries")
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  if (ministryNotFound) {
    return (
      <div className="min-h-screen bg-gray-100">
        <AdminHeader />
        <div className="flex">
          <AdminSidebar />
          <main className="flex-1 p-6">
            <div className="flex items-center mb-6">
              <Link href="/admin/ministries" className="mr-4 text-gray-600 hover:text-gray-800">
                <ArrowLeft className="h-5 w-5" />
              </Link>
              <h1 className="text-2xl font-bold">Editar Ministério</h1>
            </div>

            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <div className="text-center py-8">
                <h2 className="text-xl font-bold text-gray-800 mb-2">Ministério não encontrado</h2>
                <p className="text-gray-600 mb-4">
                  O ministério que você está tentando editar não existe ou foi removido.
                </p>
                <Link
                  href="/admin/ministries"
                  className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
                >
                  Voltar para a lista de ministérios
                </Link>
              </div>
            </div>
          </main>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Link href="/admin/ministries" className="mr-4 text-gray-600 hover:text-gray-800">
                <ArrowLeft className="h-5 w-5" />
              </Link>
              <h1 className="text-2xl font-bold">Editar Ministério</h1>
            </div>

            <button
              onClick={handleDelete}
              className="bg-red-600 text-white px-4 py-2 rounded-md flex items-center hover:bg-red-700 transition-colors"
            >
              <Trash className="h-4 w-4 mr-2" />
              Excluir Ministério
            </button>
          </div>

          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h2 className="text-lg font-semibold mb-4">Informações do Ministério</h2>

                  <div className="mb-4">
                    <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                      Nome do Ministério*
                    </label>
                    <input
                      id="name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      placeholder="Ex: Ministério de Louvor"
                      required
                    />
                  </div>

                  <div className="mb-4">
                    <label htmlFor="description" className="block text-gray-700 font-medium mb-2">
                      Descrição*
                    </label>
                    <textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={3}
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                      placeholder="Descreva o objetivo e atividades deste ministério..."
                      required
                    />
                  </div>

                  <div className="mb-4">
                    <label htmlFor="leader" className="block text-gray-700 font-medium mb-2">
                      Líder(es)*
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="leader"
                        type="text"
                        value={leader}
                        onChange={(e) => setLeader(e.target.value)}
                        className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        placeholder="Ex: João Silva ou Carlos e Maria Souza"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor="members" className="block text-gray-700 font-medium mb-2">
                        Número de Membros
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Users className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          id="members"
                          type="number"
                          min="0"
                          value={members}
                          onChange={(e) => setMembers(Number.parseInt(e.target.value) || 0)}
                          className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        />
                      </div>
                    </div>
                    <div>
                      <label htmlFor="foundedYear" className="block text-gray-700 font-medium mb-2">
                        Ano de Fundação
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Calendar className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          id="foundedYear"
                          type="number"
                          min="1900"
                          max={new Date().getFullYear()}
                          value={foundedYear}
                          onChange={(e) => setFoundedYear(Number.parseInt(e.target.value) || new Date().getFullYear())}
                          className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <label htmlFor="icon" className="block text-gray-700 font-medium mb-2">
                      Ícone
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {iconOptions.map((option) => (
                        <button
                          key={option.value}
                          type="button"
                          className={`flex flex-col items-center justify-center p-3 rounded-lg border ${
                            icon === option.value
                              ? "border-blue-500 bg-blue-50"
                              : "border-gray-200 hover:border-blue-300 hover:bg-blue-50"
                          }`}
                          onClick={() => setIcon(option.value)}
                        >
                          {option.icon}
                          <span className="text-xs mt-1">{option.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="mb-4">
                    <label htmlFor="imageUrl" className="block text-gray-700 font-medium mb-2">
                      Imagem de Capa
                    </label>
                    <div className="flex items-center">
                      <input
                        id="imageUrl"
                        type="text"
                        value={imageUrl}
                        onChange={(e) => setImageUrl(e.target.value)}
                        className="flex-1 border border-gray-300 rounded-l-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                        placeholder="URL da imagem"
                      />
                      <button
                        type="button"
                        className="bg-gray-200 text-gray-700 py-2 px-4 rounded-r-md hover:bg-gray-300 transition-colors"
                      >
                        <Upload className="h-5 w-5" />
                      </button>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">URL da imagem ou clique no botão para fazer upload</p>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center">
                      <input
                        id="active"
                        type="checkbox"
                        checked={active}
                        onChange={(e) => setActive(e.target.checked)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor="active" className="ml-2 block text-gray-700 font-medium">
                        Ativo (visível no site)
                      </label>
                    </div>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-semibold mb-4">Pré-visualização</h2>

                  <div className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden">
                    <div className="h-60 relative">
                      <Image
                        src={imageUrl || "/placeholder.svg?height=300&width=400"}
                        alt={name}
                        fill
                        className="object-cover"
                      />
                      {!active && (
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                          <span className="bg-red-600 text-white px-3 py-1 rounded-md text-sm font-bold">Inativo</span>
                        </div>
                      )}
                    </div>
                    <div className="p-6">
                      <div className="flex items-center mb-4">
                        <div className="bg-blue-100 p-2 rounded-full mr-3">{getIconComponent()}</div>
                        <div>
                          <h3 className="text-xl font-bold text-blue-800">{name || "Nome do Ministério"}</h3>
                          <p className="text-gray-600 text-sm">Desde {foundedYear}</p>
                        </div>
                      </div>
                      <p className="text-gray-600 mb-4">{description || "Descrição do ministério..."}</p>
                      <div className="flex justify-between items-center text-sm text-gray-600">
                        <span>
                          <strong>Líder:</strong> {leader || "Nome do líder"}
                        </span>
                        <span>
                          <strong>{members}</strong> membros
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 flex justify-end space-x-3">
                    <Link
                      href="/admin/ministries"
                      className="bg-gray-200 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-300 transition-colors"
                    >
                      Cancelar
                    </Link>
                    <button
                      type="submit"
                      className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors flex items-center"
                      disabled={isSaving}
                    >
                      {isSaving ? (
                        <>
                          <svg
                            className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                            ></circle>
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            ></path>
                          </svg>
                          Salvando...
                        </>
                      ) : (
                        <>
                          <Save className="h-5 w-5 mr-2" />
                          Salvar Alterações
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  )
}

