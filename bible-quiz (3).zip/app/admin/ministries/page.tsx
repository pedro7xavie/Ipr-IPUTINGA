"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import AdminHeader from "@/components/admin/admin-header"
import AdminSidebar from "@/components/admin/admin-sidebar"
import Link from "next/link"
import Image from "next/image"
import { Plus, Search, Edit, Trash, Eye, EyeOff, Filter } from "lucide-react"

export default function MinistriesPage() {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [activeFilter, setActiveFilter] = useState("all")

  const [ministries, setMinistries] = useState([
    {
      id: 1,
      name: "Ministério de Louvor",
      description: "Adoração através da música e artes para glorificar a Deus nos cultos e eventos da igreja.",
      leader: "Carlos Mendes",
      members: 12,
      foundedYear: 2010,
      active: true,
      imageUrl: "/placeholder.svg?height=300&width=400",
    },
    {
      id: 2,
      name: "Ministério de Jovens",
      description: "Discipulado, comunhão e evangelismo voltados para adolescentes e jovens adultos.",
      leader: "André Lima",
      members: 25,
      foundedYear: 2012,
      active: true,
      imageUrl: "/placeholder.svg?height=300&width=400",
    },
    {
      id: 3,
      name: "Ministério de Crianças",
      description: "Ensino bíblico e atividades para crianças de todas as idades, formando a próxima geração.",
      leader: "Ana Beatriz",
      members: 8,
      foundedYear: 2008,
      active: true,
      imageUrl: "/placeholder.svg?height=300&width=400",
    },
    {
      id: 4,
      name: "Ministério da Família",
      description: "Apoio, aconselhamento e eventos para fortalecer casamentos e famílias segundo princípios bíblicos.",
      leader: "Roberto e Marta Silva",
      members: 6,
      foundedYear: 2015,
      active: true,
      imageUrl: "/placeholder.svg?height=300&width=400",
    },
    {
      id: 5,
      name: "Ministério de Missões",
      description: "Apoio a missionários e projetos de evangelização no Brasil e no exterior.",
      leader: "Paulo Santos",
      members: 10,
      foundedYear: 2013,
      active: false,
      imageUrl: "/placeholder.svg?height=300&width=400",
    },
  ])

  useEffect(() => {
    // Verificar se o usuário está logado
    const isLoggedIn = localStorage.getItem("adminLoggedIn") === "true"
    const authToken = localStorage.getItem("authToken")

    if (!isLoggedIn || !authToken) {
      router.push("/admin/login")
    } else {
      // Carregar ministérios do localStorage se existirem
      const savedMinistries = localStorage.getItem("ministries")
      if (savedMinistries) {
        try {
          setMinistries(JSON.parse(savedMinistries))
        } catch (error) {
          console.error("Erro ao carregar ministérios:", error)
        }
      } else {
        // Se não existirem, salvar os ministérios padrão
        localStorage.setItem("ministries", JSON.stringify(ministries))
      }
      setIsLoading(false)
    }
  }, [router])

  const handleDeleteMinistry = (id: number) => {
    if (confirm("Tem certeza que deseja excluir este ministério?")) {
      const updatedMinistries = ministries.filter((ministry) => ministry.id !== id)
      setMinistries(updatedMinistries)
      localStorage.setItem("ministries", JSON.stringify(updatedMinistries))
    }
  }

  const toggleMinistryStatus = (id: number) => {
    const updatedMinistries = ministries.map((ministry) =>
      ministry.id === id ? { ...ministry, active: !ministry.active } : ministry,
    )
    setMinistries(updatedMinistries)
    localStorage.setItem("ministries", JSON.stringify(updatedMinistries))
  }

  const filteredMinistries = ministries
    .filter(
      (ministry) =>
        ministry.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ministry.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ministry.leader.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    .filter((ministry) => {
      if (activeFilter === "all") return true
      if (activeFilter === "active") return ministry.active
      if (activeFilter === "inactive") return !ministry.active
      return true
    })

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />

      <div className="flex">
        <AdminSidebar />

        <main className="flex-1 p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Gerenciar Ministérios</h1>

            <Link
              href="/admin/ministries/new"
              className="bg-blue-600 text-white px-4 py-2 rounded-md flex items-center hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              Novo Ministério
            </Link>
          </div>

          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div className="flex items-center">
                <Filter className="h-5 w-5 text-gray-500 mr-2" />
                <span className="text-gray-700 font-medium mr-3">Filtrar:</span>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setActiveFilter("all")}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                      activeFilter === "all"
                        ? "bg-blue-100 text-blue-700 hover:bg-blue-200"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Todos
                  </button>
                  <button
                    onClick={() => setActiveFilter("active")}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                      activeFilter === "active"
                        ? "bg-green-100 text-green-700 hover:bg-green-200"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Ativos
                  </button>
                  <button
                    onClick={() => setActiveFilter("inactive")}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                      activeFilter === "inactive"
                        ? "bg-red-100 text-red-700 hover:bg-red-200"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Inativos
                  </button>
                </div>
              </div>

              <div className="relative w-full md:w-64">
                <input
                  type="text"
                  placeholder="Buscar ministérios..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full border border-gray-300 rounded-md py-2 pl-10 pr-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-900 font-medium"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMinistries.map((ministry) => (
                <div
                  key={ministry.id}
                  className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
                >
                  <div className="h-48 relative">
                    <Image
                      src={ministry.imageUrl || "/placeholder.svg?height=300&width=400"}
                      alt={ministry.name}
                      fill
                      className="object-cover"
                    />
                    {!ministry.active && (
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <span className="bg-red-600 text-white px-3 py-1 rounded-md text-sm font-bold">Inativo</span>
                      </div>
                    )}
                  </div>
                  <div className="p-5">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-lg font-bold text-gray-900 truncate">{ministry.name}</h3>
                      <span className="text-sm text-gray-500">Desde {ministry.foundedYear}</span>
                    </div>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">{ministry.description}</p>
                    <div className="flex items-center justify-between mb-4">
                      <div className="text-sm text-gray-600">
                        <span className="font-medium">Líder:</span> {ministry.leader}
                      </div>
                      <div className="text-sm text-gray-600">
                        <span className="font-medium">{ministry.members}</span> membros
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <button
                        onClick={() => toggleMinistryStatus(ministry.id)}
                        className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium ${
                          ministry.active
                            ? "bg-green-100 text-green-800 hover:bg-green-200"
                            : "bg-red-100 text-red-800 hover:bg-red-200"
                        }`}
                      >
                        {ministry.active ? (
                          <>
                            <Eye className="h-3 w-3 mr-1" />
                            Ativo
                          </>
                        ) : (
                          <>
                            <EyeOff className="h-3 w-3 mr-1" />
                            Inativo
                          </>
                        )}
                      </button>
                      <div className="flex space-x-2">
                        <Link
                          href={`/admin/ministries/edit/${ministry.id}`}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          <Edit className="h-5 w-5" />
                        </Link>
                        <button
                          onClick={() => handleDeleteMinistry(ministry.id)}
                          className="text-red-600 hover:text-red-900"
                        >
                          <Trash className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredMinistries.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">
                  {searchTerm
                    ? "Nenhum ministério encontrado para essa busca"
                    : activeFilter !== "all"
                      ? `Nenhum ministério ${activeFilter === "active" ? "ativo" : "inativo"} encontrado`
                      : "Nenhum ministério cadastrado"}
                </p>
                <Link
                  href="/admin/ministries/new"
                  className="bg-blue-600 text-white px-4 py-2 rounded-md inline-flex items-center hover:bg-blue-700 transition-colors"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Ministério
                </Link>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  )
}

