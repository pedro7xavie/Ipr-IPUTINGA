import Header from "@/components/header"
import Footer from "@/components/footer"
import { Mail, Phone, MapPin, Clock, Send, MessageSquare } from "lucide-react"

export default function ContatoPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      {/* Banner */}
      <section className="bg-blue-800 text-white py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-4xl font-bold mb-4">Entre em Contato</h1>
          <p className="text-xl text-blue-100 max-w-3xl">
            Estamos à disposição para responder suas dúvidas e receber seus comentários.
          </p>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Formulário de Contato */}
            <div>
              <h2 className="text-2xl font-bold text-blue-800 mb-6">Envie uma Mensagem</h2>

              <form className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="nome" className="block text-gray-700 font-medium mb-2">
                      Nome
                    </label>
                    <input
                      type="text"
                      id="nome"
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Seu nome"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Seu email"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="telefone" className="block text-gray-700 font-medium mb-2">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    id="telefone"
                    className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Seu telefone"
                  />
                </div>

                <div>
                  <label htmlFor="assunto" className="block text-gray-700 font-medium mb-2">
                    Assunto
                  </label>
                  <select
                    id="assunto"
                    className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  >
                    <option value="">Selecione um assunto</option>
                    <option value="informacoes">Informações Gerais</option>
                    <option value="visita">Quero Visitar a Igreja</option>
                    <option value="oracao">Pedido de Oração</option>
                    <option value="aconselhamento">Aconselhamento Pastoral</option>
                    <option value="outro">Outro Assunto</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="mensagem" className="block text-gray-700 font-medium mb-2">
                    Mensagem
                  </label>
                  <textarea
                    id="mensagem"
                    rows={5}
                    className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Sua mensagem"
                    required
                  ></textarea>
                </div>

                <div>
                  <button
                    type="submit"
                    className="bg-blue-600 text-white py-3 px-6 rounded-md font-medium hover:bg-blue-700 transition-colors flex items-center justify-center"
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Enviar Mensagem
                  </button>
                </div>
              </form>
            </div>

            {/* Informações de Contato */}
            <div>
              <h2 className="text-2xl font-bold text-blue-800 mb-6">Informações de Contato</h2>

              <div className="bg-white rounded-lg shadow-md p-6 mb-8">
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="bg-blue-100 p-3 rounded-full mr-4">
                      <MapPin className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900 mb-1">Endereço</h3>
                      <p className="text-gray-600">
                        Rua da Iputinga, 123 - Iputinga
                        <br />
                        Recife - PE, 50000-000
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="bg-blue-100 p-3 rounded-full mr-4">
                      <Phone className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900 mb-1">Telefone</h3>
                      <p className="text-gray-600">(81) 3333-4444</p>
                      <p className="text-gray-600">(81) 99999-8888 (WhatsApp)</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="bg-blue-100 p-3 rounded-full mr-4">
                      <Mail className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900 mb-1">Email</h3>
                      <p className="text-gray-600">contato@ipreiputinga.org</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="bg-blue-100 p-3 rounded-full mr-4">
                      <Clock className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900 mb-1">Horário de Funcionamento</h3>
                      <p className="text-gray-600">
                        Segunda a Sexta: 9h às 17h
                        <br />
                        Sábado: 9h às 12h
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Horários de Culto */}
              <div className="bg-blue-700 rounded-lg shadow-md p-6 text-white">
                <h3 className="font-bold text-xl mb-4">Horários de Culto</h3>

                <div className="space-y-4">
                  <div className="flex items-center">
                    <div className="bg-blue-600 p-2 rounded-full mr-3">
                      <MessageSquare className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="font-medium">Culto de Adoração</p>
                      <p className="text-blue-200">Domingo, 18:00</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="bg-blue-600 p-2 rounded-full mr-3">
                      <MessageSquare className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="font-medium">Estudo Bíblico</p>
                      <p className="text-blue-200">Quarta-feira, 19:30</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="bg-blue-600 p-2 rounded-full mr-3">
                      <MessageSquare className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="font-medium">Culto de Jovens</p>
                      <p className="text-blue-200">Sábado, 19:00</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="bg-blue-600 p-2 rounded-full mr-3">
                      <MessageSquare className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="font-medium">Escola Dominical</p>
                      <p className="text-blue-200">Domingo, 09:00</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mapa */}
      <section className="py-12 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-2xl font-bold text-blue-800 mb-6 text-center">Nossa Localização</h2>

          <div className="h-96 bg-gray-200 rounded-lg flex items-center justify-center">
            <p className="text-gray-500">Mapa da localização</p>
            {/* Aqui você pode adicionar um mapa do Google Maps */}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

