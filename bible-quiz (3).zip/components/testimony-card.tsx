import Image from "next/image"

interface TestimonyCardProps {
  name: string
  testimony: string
  imageUrl: string
}

const TestimonyCard = ({ name, testimony, imageUrl }: TestimonyCardProps) => {
  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
      <div className="flex items-center mb-4">
        <Image src={imageUrl || "/placeholder.svg"} alt={name} width={60} height={60} className="rounded-full mr-4" />
        <h3 className="text-xl font-bold">{name}</h3>
      </div>

      <p className="italic text-blue-100">"{testimony}"</p>
    </div>
  )
}

export default TestimonyCard

