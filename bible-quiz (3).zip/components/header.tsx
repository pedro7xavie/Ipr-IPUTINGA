"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, ChevronDown } from "lucide-react"
import ChurchLogo from "./church-logo"

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isMinisteriosOpen, setIsMinisteriosOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const toggleMinisterios = () => {
    setIsMinisteriosOpen(!isMinisteriosOpen)
  }

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto max-w-6xl px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <ChurchLogo size="small" />

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-4">
            <Link href="/" className="text-gray-700 hover:text-blue-600 font-medium px-2">
              Início
            </Link>
            <Link href="/sobre" className="text-gray-700 hover:text-blue-600 font-medium px-2">
              Sobre
            </Link>

            {/* Ministérios Dropdown */}
            <div className="relative group">
              <button
                className="flex items-center text-gray-700 hover:text-blue-600 font-medium px-2"
                onClick={() => setIsMinisteriosOpen(!isMinisteriosOpen)}
              >
                Ministérios
                <ChevronDown className="w-4 h-4 ml-1" />
              </button>

              <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 hidden group-hover:block">
                <Link href="/ministerios/louvor" className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50">
                  Louvor
                </Link>
                <Link href="/ministerios/jovens" className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50">
                  Jovens
                </Link>
                <Link href="/ministerios/criancas" className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50">
                  Crianças
                </Link>
                <Link href="/ministerios/familia" className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50">
                  Família
                </Link>
                <Link href="/ministerios/missoes" className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50">
                  Missões
                </Link>
                <Link
                  href="/ministerios/primeiros-passos"
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50"
                >
                  Primeiros Passos
                </Link>
              </div>
            </div>

            <Link href="/eventos" className="text-gray-700 hover:text-blue-600 font-medium px-2">
              Eventos
            </Link>
            <Link href="/calendario" className="text-gray-700 hover:text-blue-600 font-medium px-2">
              Calendário
            </Link>
            <Link href="/sermoes" className="text-gray-700 hover:text-blue-600 font-medium px-2">
              Sermões
            </Link>
            <Link href="/transmissao" className="text-gray-700 hover:text-blue-600 font-medium px-2">
              Transmissão
            </Link>
            <Link href="/quiz" className="text-gray-700 hover:text-blue-600 font-medium px-2">
              Quiz Bíblico
            </Link>
            <Link href="/contato" className="text-gray-700 hover:text-blue-600 font-medium px-2">
              Contato
            </Link>
            <Link
              href="/doacao"
              className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
            >
              Fazer uma Doação
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700 focus:outline-none"
            onClick={toggleMenu}
            aria-label={isMenuOpen ? "Fechar menu" : "Abrir menu"}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="container mx-auto px-4 py-3">
            <nav className="flex flex-col space-y-3">
              <Link
                href="/"
                className="text-gray-700 hover:text-blue-600 font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Início
              </Link>
              <Link
                href="/sobre"
                className="text-gray-700 hover:text-blue-600 font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Sobre
              </Link>

              {/* Ministérios Mobile Dropdown */}
              <div>
                <button
                  className="flex items-center justify-between w-full text-gray-700 hover:text-blue-600 font-medium py-2"
                  onClick={toggleMinisterios}
                >
                  <span>Ministérios</span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${isMinisteriosOpen ? "rotate-180" : ""}`} />
                </button>

                {isMinisteriosOpen && (
                  <div className="pl-4 mt-2 space-y-2 border-l-2 border-gray-200">
                    <Link
                      href="/ministerios/louvor"
                      className="block py-1 text-gray-700 hover:text-blue-600"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Louvor
                    </Link>
                    <Link
                      href="/ministerios/jovens"
                      className="block py-1 text-gray-700 hover:text-blue-600"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Jovens
                    </Link>
                    <Link
                      href="/ministerios/criancas"
                      className="block py-1 text-gray-700 hover:text-blue-600"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Crianças
                    </Link>
                    <Link
                      href="/ministerios/familia"
                      className="block py-1 text-gray-700 hover:text-blue-600"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Família
                    </Link>
                    <Link
                      href="/ministerios/missoes"
                      className="block py-1 text-gray-700 hover:text-blue-600"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Missões
                    </Link>
                    <Link
                      href="/ministerios/primeiros-passos"
                      className="block py-1 text-gray-700 hover:text-blue-600"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Primeiros Passos
                    </Link>
                  </div>
                )}
              </div>

              <Link
                href="/eventos"
                className="text-gray-700 hover:text-blue-600 font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Eventos
              </Link>
              <Link
                href="/calendario"
                className="text-gray-700 hover:text-blue-600 font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Calendário
              </Link>
              <Link
                href="/sermoes"
                className="text-gray-700 hover:text-blue-600 font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Sermões
              </Link>
              <Link
                href="/transmissao"
                className="text-gray-700 hover:text-blue-600 font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Transmissão
              </Link>
              <Link
                href="/quiz"
                className="text-gray-700 hover:text-blue-600 font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Quiz Bíblico
              </Link>
              <Link
                href="/contato"
                className="text-gray-700 hover:text-blue-600 font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Contato
              </Link>
              <Link
                href="/doacao"
                className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors inline-block w-fit"
                onClick={() => setIsMenuOpen(false)}
              >
                Fazer uma Doação
              </Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  )
}

export default Header

