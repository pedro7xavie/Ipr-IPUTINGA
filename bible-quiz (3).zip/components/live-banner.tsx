import Link from "next/link"
import { AlertCircle } from "lucide-react"

const LiveBanner = () => {
  return (
    <div className="bg-red-600 text-white py-3">
      <div className="container mx-auto max-w-6xl px-4">
        <div className="flex items-center justify-center">
          <AlertCircle className="w-5 h-5 mr-2 animate-pulse" />
          <p className="font-medium mr-4">Estamos ao vivo agora!</p>
          <Link
            href="/transmissao"
            className="bg-white text-red-600 px-4 py-1 rounded-md text-sm font-bold hover:bg-gray-100 transition-colors"
          >
            Assistir
          </Link>
        </div>
      </div>
    </div>
  )
}

export default LiveBanner

