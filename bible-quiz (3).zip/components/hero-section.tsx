import Link from "next/link"

const HeroSection = () => {
  return (
    <section className="relative bg-blue-900 text-white">
      {/* Overlay de fundo */}
      <div
        className="absolute inset-0 bg-gradient-to-r from-black/70 to-blue-900/50 z-10"
        style={{
          backgroundImage:
            "url('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-j8oney9dcC5v0xvrkOnLC7RWdNSgUM.png')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          mixBlendMode: "normal",
        }}
      ></div>

      <div className="container mx-auto max-w-6xl px-4 py-24 md:py-32 relative z-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="max-w-2xl backdrop-blur-sm bg-black/30 p-6 rounded-lg">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Igreja Presbiteriana Renovada da Iputinga</h1>

            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              "Adorando a Deus, edificando vidas e alcançando os perdidos."
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="/sobre"
                className="bg-white text-blue-900 py-3 px-8 rounded-md font-bold hover:bg-gray-100 transition-colors text-center"
              >
                Conheça-nos
              </Link>
              <Link
                href="/transmissao"
                className="bg-transparent border-2 border-white text-white py-3 px-8 rounded-md font-bold hover:bg-white/20 transition-colors text-center"
              >
                Assista ao Vivo
              </Link>
            </div>

            <div className="mt-12 bg-blue-900/70 backdrop-blur-sm p-6 rounded-lg">
              <h2 className="text-xl font-bold mb-3">Próximo Culto</h2>
              <p className="text-blue-100">Domingo, 18:00 - Culto de Adoração</p>
              <p className="mt-2 text-blue-100">Venha adorar ao Senhor conosco!</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default HeroSection

