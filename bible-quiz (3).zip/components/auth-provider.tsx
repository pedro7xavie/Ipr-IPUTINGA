"use client"

import { createContext, useContext, type ReactNode } from "react"

// Contexto simplificado sem funcionalidades de autenticação
interface AuthContextType {
  user: { name: string; role: string } | null
  loading: boolean
}

// Criar contexto
const AuthContext = createContext<AuthContextType>({
  user: { name: "Visitante", role: "guest" },
  loading: false,
})

// Hook para usar o contexto
export function useAuth() {
  return useContext(AuthContext)
}

// Provedor simplificado que sempre fornece um usuário visitante
export function AuthProvider({ children }: { children: ReactNode }) {
  // Valor do contexto
  const value = {
    user: { name: "Visitante", role: "guest" },
    loading: false,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

