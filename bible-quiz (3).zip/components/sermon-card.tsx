import Image from "next/image"
import Link from "next/link"
import { Play } from "lucide-react"

interface SermonCardProps {
  title: string
  pastor: string
  date: string
  imageUrl: string
  videoUrl: string
}

const SermonCard = ({ title, pastor, date, imageUrl, videoUrl }: SermonCardProps) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        <Image
          src={imageUrl || "/placeholder.svg"}
          alt={title}
          width={300}
          height={200}
          className="w-full h-48 object-cover"
        />

        <Link
          href={videoUrl}
          className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 hover:opacity-100 transition-opacity"
        >
          <div className="bg-blue-600 rounded-full p-3">
            <Play className="w-8 h-8 text-white" />
          </div>
        </Link>
      </div>

      <div className="p-5">
        <h3 className="text-lg font-bold text-blue-800 mb-2">{title}</h3>
        <p className="text-gray-600 mb-1">{pastor}</p>
        <p className="text-gray-500 text-sm mb-3">{date}</p>

        <Link href={videoUrl} className="inline-block text-blue-600 font-medium hover:text-blue-800 transition-colors">
          Assistir sermão →
        </Link>
      </div>
    </div>
  )
}

export default SermonCard

