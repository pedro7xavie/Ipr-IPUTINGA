import Link from "next/link"
import Image from "next/image"
import { Facebook, Instagram, Youtube, MapPin, Phone, Mail } from "lucide-react"

const Footer = () => {
  return (
    <footer className="bg-blue-900 text-white">
      <div className="container mx-auto max-w-6xl px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Coluna 1: Logo e Informações */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center">
              <Image
                src="/placeholder.svg?height=50&width=50"
                alt="Logo da Igreja Presbiteriana Renovada da Iputinga"
                width={50}
                height={50}
                className="mr-3"
              />
              <div>
                <h3 className="text-lg font-bold">IPR Iputinga</h3>
                <p className="text-sm text-blue-300">Igreja Presbiteriana Renovada</p>
              </div>
            </Link>

            <p className="text-blue-200 mt-4">
              Uma comunidade cristã comprometida com a Palavra de Deus e com a transformação de vidas.
            </p>

            <div className="flex space-x-4 mt-6">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                <Facebook className="w-6 h-6 text-blue-300 hover:text-white transition-colors" />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                <Instagram className="w-6 h-6 text-blue-300 hover:text-white transition-colors" />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" aria-label="Youtube">
                <Youtube className="w-6 h-6 text-blue-300 hover:text-white transition-colors" />
              </a>
            </div>
          </div>

          {/* Coluna 2: Links Rápidos */}
          <div>
            <h3 className="text-lg font-bold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-blue-300 hover:text-white transition-colors">
                  Início
                </Link>
              </li>
              <li>
                <Link href="/sobre" className="text-blue-300 hover:text-white transition-colors">
                  Sobre
                </Link>
              </li>
              <li>
                <Link href="/ministerios" className="text-blue-300 hover:text-white transition-colors">
                  Ministérios
                </Link>
              </li>
              <li>
                <Link href="/eventos" className="text-blue-300 hover:text-white transition-colors">
                  Eventos
                </Link>
              </li>
              <li>
                <Link href="/calendario" className="text-blue-300 hover:text-white transition-colors">
                  Calendário
                </Link>
              </li>
              <li>
                <Link href="/sermoes" className="text-blue-300 hover:text-white transition-colors">
                  Sermões
                </Link>
              </li>
              <li>
                <Link href="/quiz" className="text-blue-300 hover:text-white transition-colors">
                  Quiz Bíblico
                </Link>
              </li>
            </ul>
          </div>

          {/* Coluna 3: Horários */}
          <div>
            <h3 className="text-lg font-bold mb-4">Horários de Culto</h3>
            <ul className="space-y-3">
              <li>
                <p className="font-medium">Culto de Adoração</p>
                <p className="text-blue-300">Domingo, 18:00</p>
              </li>
              <li>
                <p className="font-medium">Estudo Bíblico</p>
                <p className="text-blue-300">Quarta-feira, 19:30</p>
              </li>
              <li>
                <p className="font-medium">Culto de Jovens</p>
                <p className="text-blue-300">Sábado, 19:00</p>
              </li>
            </ul>
          </div>

          {/* Coluna 4: Contato */}
          <div>
            <h3 className="text-lg font-bold mb-4">Contato</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="w-5 h-5 text-blue-300 mr-2 mt-0.5" />
                <span>
                  Rua da Iputinga, 123 - Iputinga
                  <br />
                  Recife - PE, 50000-000
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="w-5 h-5 text-blue-300 mr-2" />
                <span>(81) 3333-4444</span>
              </li>
              <li className="flex items-center">
                <Mail className="w-5 h-5 text-blue-300 mr-2" />
                <span>contato@ipreiputinga.org</span>
              </li>
            </ul>
          </div>
        </div>

        <hr className="border-blue-800 my-8" />

        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-blue-300 text-sm">
            &copy; {new Date().getFullYear()} Igreja Presbiteriana Renovada da Iputinga. Todos os direitos reservados.
          </p>

          <div className="mt-4 md:mt-0">
            <Link href="/admin/login" className="text-blue-300 hover:text-white transition-colors text-sm">
              Área Administrativa
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

