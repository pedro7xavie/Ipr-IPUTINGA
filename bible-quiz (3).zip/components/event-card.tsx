import { Calendar, Clock } from "lucide-react"
import Link from "next/link"

interface EventCardProps {
  title: string
  date: string
  time: string
  description: string
}

const EventCard = ({ title, date, time, description }: EventCardProps) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="p-6">
        <h3 className="text-xl font-bold text-blue-800 mb-3">{title}</h3>

        <div className="flex items-center text-gray-600 mb-2">
          <Calendar className="w-4 h-4 mr-2" />
          <span>{date}</span>
        </div>

        <div className="flex items-center text-gray-600 mb-4">
          <Clock className="w-4 h-4 mr-2" />
          <span>{time}</span>
        </div>

        <p className="text-gray-700 mb-4">{description}</p>

        <Link href="/eventos" className="inline-block text-blue-600 font-medium hover:text-blue-800 transition-colors">
          Mais detalhes →
        </Link>
      </div>
    </div>
  )
}

export default EventCard

