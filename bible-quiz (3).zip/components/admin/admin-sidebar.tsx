"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Calendar,
  Home,
  FileText,
  Users,
  Video,
  MessageSquare,
  Settings,
  HelpCircle,
  BookOpen,
  BarChart,
} from "lucide-react"

const AdminSidebar = () => {
  const pathname = usePathname()
  const [isHomeExpanded, setIsHomeExpanded] = useState(false)

  const menuItems = [
    {
      title: "Dashboard",
      href: "/admin/dashboard",
      icon: <Home className="h-5 w-5" />,
    },
    {
      title: "Página Inicial",
      href: "/admin/home-editor",
      icon: <FileText className="h-5 w-5" />,
      submenu: [
        { title: "Banner Principal", href: "/admin/home-editor/banner" },
        { title: "Sobre a Igreja", href: "/admin/home-editor/about" },
        { title: "Eventos Destacados", href: "/admin/home-editor/featured-events" },
        { title: "Sermões Recentes", href: "/admin/home-editor/recent-sermons" },
        { title: "Testemunhos", href: "/admin/home-editor/testimonials" },
      ],
    },
    {
      title: "Eventos",
      href: "/admin/events",
      icon: <Calendar className="h-5 w-5" />,
    },
    {
      title: "Sermões",
      href: "/admin/sermons",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      title: "Transmissão",
      href: "/admin/live-stream",
      icon: <Video className="h-5 w-5" />,
    },
    {
      title: "Ministérios",
      href: "/admin/ministries",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Quiz Bíblico",
      href: "/admin/quiz",
      icon: <BookOpen className="h-5 w-5" />,
    },
    {
      title: "Testemunhos",
      href: "/admin/testimonials",
      icon: <MessageSquare className="h-5 w-5" />,
    },
    {
      title: "Estatísticas",
      href: "/admin/statistics",
      icon: <BarChart className="h-5 w-5" />,
    },
    {
      title: "Configurações",
      href: "/admin/settings",
      icon: <Settings className="h-5 w-5" />,
    },
    {
      title: "Ajuda",
      href: "/admin/help",
      icon: <HelpCircle className="h-5 w-5" />,
    },
  ]

  return (
    <aside className="w-64 bg-white shadow-md hidden lg:block">
      <div className="h-full overflow-y-auto">
        <nav className="px-3 py-4">
          <ul className="space-y-1">
            {menuItems.map((item, index) => (
              <li key={index}>
                {item.submenu ? (
                  <div>
                    <button
                      className={`w-full flex items-center justify-between px-3 py-2 text-sm font-medium rounded-md ${
                        pathname.startsWith(item.href) ? "bg-blue-100 text-blue-800" : "text-gray-700 hover:bg-gray-100"
                      }`}
                      onClick={() => {
                        if (item.title === "Página Inicial") {
                          setIsHomeExpanded(!isHomeExpanded)
                        }
                      }}
                    >
                      <div className="flex items-center">
                        {item.icon}
                        <span className="ml-3">{item.title}</span>
                      </div>
                      <svg
                        className={`h-4 w-4 transition-transform ${
                          item.title === "Página Inicial" && isHomeExpanded ? "transform rotate-180" : ""
                        }`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>

                    {item.title === "Página Inicial" && isHomeExpanded && (
                      <ul className="mt-1 pl-8 space-y-1">
                        {item.submenu.map((subItem, subIndex) => (
                          <li key={subIndex}>
                            <Link
                              href={subItem.href}
                              className={`block px-3 py-2 text-sm font-medium rounded-md ${
                                pathname === subItem.href || pathname.startsWith(subItem.href + "/")
                                  ? "bg-blue-50 text-blue-700"
                                  : "text-gray-600 hover:bg-gray-50"
                              }`}
                            >
                              {subItem.title}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                ) : (
                  <Link
                    href={item.href}
                    className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                      pathname === item.href || pathname.startsWith(item.href + "/")
                        ? "bg-blue-100 text-blue-800"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    {item.icon}
                    <span className="ml-3">{item.title}</span>
                  </Link>
                )}
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </aside>
  )
}

export default AdminSidebar

