"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Bell, LogOut, Menu, User, X } from "lucide-react"
import { clearAuthData, getUsername } from "@/lib/storage-service"

const AdminHeader = () => {
  const [isProfileOpen, setIsProfileOpen] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const router = useRouter()
  const [adminUsername, setAdminUsername] = useState("Admin")

  useEffect(() => {
    // Obter nome do usuário do localStorage
    const username = getUsername()
    if (username) {
      setAdminUsername(username)
    }
  }, [])

  const handleLogout = () => {
    clearAuthData()
    router.push("/admin/login")
  }

  return (
    <header className="bg-white shadow-md">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo e Menu Mobile */}
          <div className="flex items-center">
            <button
              type="button"
              className="lg:hidden mr-2 text-gray-500 hover:text-gray-700"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>

            <Link href="/admin/dashboard" className="flex items-center">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="Logo da Igreja Presbiteriana Renovada da Iputinga"
                width={40}
                height={40}
                className="mr-2"
              />
              <div>
                <h1 className="text-sm font-bold text-blue-800">IPR Iputinga</h1>
                <p className="text-xs text-blue-600">Painel Admin</p>
              </div>
            </Link>
          </div>

          {/* Botões da Direita */}
          <div className="flex items-center">
            {/* Notificações */}
            <button
              type="button"
              className="p-2 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <span className="sr-only">Ver notificações</span>
              <Bell className="h-6 w-6" />
            </button>

            {/* Perfil */}
            <div className="ml-3 relative">
              <div>
                <button
                  type="button"
                  className="flex items-center max-w-xs rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                >
                  <span className="sr-only">Abrir menu do usuário</span>
                  <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-800">
                    <User className="h-5 w-5" />
                  </div>
                </button>
              </div>

              {isProfileOpen && (
                <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
                  <div className="py-1">
                    <div className="px-4 py-2 text-sm text-gray-700 border-b">
                      <p className="font-medium">{adminUsername}</p>
                      <p className="text-gray-500">admin@ipreiputinga.org</p>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Sair
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

export default AdminHeader

