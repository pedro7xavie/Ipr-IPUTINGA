import Image from "next/image"
import Link from "next/link"

interface ChurchLogoProps {
  size?: "small" | "medium" | "large"
  withText?: boolean
}

export default function ChurchLogo({ size = "medium", withText = true }: ChurchLogoProps) {
  // Definir dimensões com base no tamanho
  const dimensions = {
    small: { width: 40, height: 40 },
    medium: { width: 60, height: 60 },
    large: { width: 100, height: 100 },
  }

  const { width, height } = dimensions[size]

  return (
    <Link href="/" className="flex items-center">
      <div className="relative">
        <div className="bg-blue-700 rounded-full overflow-hidden flex items-center justify-center">
          <Image
            src="/placeholder.svg?height=200&width=200"
            alt="Logo da Igreja Presbiteriana Renovada da Iputinga"
            width={width}
            height={height}
            className="object-contain"
            priority
          />
        </div>
      </div>

      {withText && (
        <div className="ml-3">
          <h1
            className={`font-bold text-blue-800 ${size === "small" ? "text-sm" : size === "large" ? "text-xl" : "text-lg"}`}
          >
            IPR Iputinga
          </h1>
          <p className={`text-blue-600 ${size === "small" ? "text-xs" : size === "large" ? "text-base" : "text-sm"}`}>
            Igreja Presbiteriana Renovada
          </p>
        </div>
      )}
    </Link>
  )
}

